# ----- systemctl -----
cp -r vmifcmpush /etc/rc.d/init.d/
chmod +x /etc/rc.d/init.d/vmifcmpush

chkconfig --add /etc/rc.d/init.d/vmifcmpush
cd /etc/rc.d/init.d/
chkconfig vmifcmpush on