rpm -Uvh *.rpm
cp -r ssl.conf /etc/httpd/conf.d/