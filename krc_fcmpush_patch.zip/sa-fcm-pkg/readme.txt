# ----- nodejs -----
tar -xJf node-v16.20.2-linux-x64.tar.xz
sudo mv node-v16.20.2-linux-x64 /usr/local/node-v16.20.2
sudo ln -sf /usr/local/node-v16.20.2/bin/node   /usr/bin/node
sudo ln -sf /usr/local/node-v16.20.2/bin/npm    /usr/bin/npm
sudo ln -sf /usr/local/node-v16.20.2/bin/npx    /usr/bin/npx

mkdir -p ~/.nvm
tar xzf nvm-v0.39.5.tar.gz -C ~/.nvm
cat << 'EOF' >> ~/.bashrc
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
EOF
source ~/.bashrc

npm install ./winston-*.tgz
