# ----- node module -----
unzip node_modules.zip
npm install ./winston-*.tgz