// server.js
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { GoogleAuth } = require('google-auth-library');
const app = express();

app.use(express.json());
const cors = require('cors');
const logger = require('./logger');
app.use(cors());  // 모든 origin 허용

function logWithTimestamp(...args) {
  const now = new Date().toLocaleString('ko-KR', {
    timeZone: 'Asia/Seoul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).replace(/\.\s/g, '-').replace(' ', ' ');
  console.debug(`[${now}]`, ...args);
}

app.post('/fcmpush', async (req, res) => {
  try {
    const { message } = req.body;
    logWithTimestamp("message:", JSON.stringify(message, null, 2));
    //console.debug("message:", JSON.stringify(message, null, 2));

    if (!message || !message.token || !message.notification || !message.data) {
      return res.status(400).json({ error: "Missing required fields in 'message'" });
    }

    const SERVICE_ACCOUNT_FILE = '/vmi/fcmkey/fcm-demo-e5e1f-firebase-adminsdk-79wqi-08a484f278.json';
    const SCOPES = ['https://www.googleapis.com/auth/firebase.messaging'];

    const auth = new GoogleAuth({
      keyFile: SERVICE_ACCOUNT_FILE,
      scopes: SCOPES,
    });

    const client = await auth.getClient();
    const accessTokenResponse = await client.getAccessToken();
    const accessToken = accessTokenResponse.token || accessTokenResponse;

    const headers = {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    };

    const projectId = "fcm-demo-e5e1f";
    const projectUrl = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;

    // 서버는 받은 'message' 객체를 그대로 FCM 서버로 전달한다
    const fcmRequestBody = { message };

    const response = await axios.post(projectUrl, fcmRequestBody, { headers });

    if (response.status === 200) {
      return res.status(200).json({ message: "Notification sent successfully" });
    } else {
      return res.status(400).json({ error: "Failed to send notification" });
    }
  } catch (error) {
    console.debug(error.response ? JSON.stringify(error.response.data, null, 2) : error.message);
    return res.status(500).json({ error: "An unexpected error occurred: " + error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


