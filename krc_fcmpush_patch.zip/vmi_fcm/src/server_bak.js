// server.js
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const { GoogleAuth } = require('google-auth-library');
const app = express();

app.use(express.json());

app.post('/fcmpush', async (req, res) => {
  try {
    const { device_token, payload, package: packageName } = req.body;
    console.debug("device_token:", device_token);
    console.debug("payload:", payload);
    console.debug("package:", packageName);

    if (!device_token || !payload) {
      return res.status(400).json({ error: "Failure" });
    }

    // 서비스 계정 파일과 스코프 설정
    const SERVICE_ACCOUNT_FILE = '/vmi/fcmkey/fcm-demo-e5e1f-firebase-adminsdk-79wqi-08a484f278.json';
    const SCOPES = ['https://www.googleapis.com/auth/firebase.messaging'];

    // GoogleAuth 라이브러리를 사용해 인증 클라이언트 생성
    const auth = new GoogleAuth({
      keyFile: SERVICE_ACCOUNT_FILE,
      scopes: SCOPES,
    });

    const client = await auth.getClient();
    const accessTokenResponse = await client.getAccessToken();
    const accessToken = accessTokenResponse.token || accessTokenResponse; // 라이브러리 버전에 따라 달라질 수 있음

    // FCM HTTP v1 API 호출을 위한 헤더 설정
    const headers = {
      'Authorization': 'Bearer ' + accessToken,
      'Content-Type': 'application/json'
    };

    // FCM 메시지 payload 구성
    const content = {
      message: {
        token: device_token,
        notification: {
          title: packageName,
	  body: payload,
        },
        data: {
          body: payload,
        },
        apns: {
          headers: {
            "apns-priority": "5",
          },
          payload: {
            aps: {
              badge: 1,
              "multable-content": "1",
              sound: "1"
            }
          }
        },
        android: {
          priority: 'high'
        },
      }
    };

    // 프로젝트 ID (여기서는 fcm-demo-e5e1f를 사용)
    const projectId = "fcm-demo-e5e1f";
    const projectUrl = `https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`;

    // FCM API 호출
    const response = await axios.post(projectUrl, content, { headers });
    
    if (response.status === 200) {
      return res.status(200).json({ message: "Notification sent successfully" });
    } else {
      return res.status(400).json({ error: "Failure" });
    }
  } catch (error) {
    console.debug(error);
    return res.status(500).json({ error: "An unexpected error occurred: " + error.message });
  }
});

// 서버 실행
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
