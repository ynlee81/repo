#!/bin/sh

RUNSESSION=/opt/SECUREWORKS/3.0/bin/swipstat
AGENT_DIR=$1

while [ 1 ]
do
if [ ! -f $RUNSESSION ]; then
	echo "$RUNSESSION Not Found" > $AGENT_DIR/module/.sworks.session
	echo "$RUNSESSION Not Found"
	exit 0
fi

#$RUNSESSION | head -n 10 > ./module/.sworks.session
$RUNSESSION | head -n 10 |sed 's/^ *--/--/' > $AGENT_DIR/module/.sworks.session
sleep 10
done
