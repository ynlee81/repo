#!/bin/sh

PROGRAM=$0;
USER=$1;
PASSWD=$2;
TNS=$3;
MODE=$4;
ALIVE=$5;
AGENT_IP=$6;
MANAGER_IP=$7;

if [  $MODE == "R" ];
then
 AGENT_STATUS_FILES=`sqlplus ${USER}/${PASSWD}@${TNS} <<END
   set pagesize 999 linesize 999 feedback off verify off echo off head off	
   SELECT  '#' || ID || ','|| MGR_IP || ',' FROM AGENT_INFO_LIST  WHERE ALIVE = ${ALIVE} AND MGR_IP = '${MANAGER_IP}' ORDER BY ID;
   exit;
   END`

 echo "@USER:$USER"
 echo "@PASSWD:$PASSWD"
 echo "@TNS:$TNS"
 echo "@SELECT ID , ',', MGR_IP FROM AGENT_INFO_LIST WHERE ALIVE = 0 ORDER BY ID;"
 echo "@AGENT_STATUS_FILES:$AGENT_STATUS_FILES"
 echo "#END_OF_FILE"
 exit 0
fi

if [  $MODE == "S" ];
then
 AGENT_STATUS_FILES=`sqlplus ${USER}/${PASSWD}@${TNS} <<END
   set pagesize 999 linesize 999 feedback off verify off echo off head off	
   SELECT  '#' || ID || ','|| MGR_IP || ',' FROM AGENT_INFO_LIST  WHERE MGR_IP = '${MANAGER_IP}' ORDER BY ID;
   exit;
   END`

 echo "@USER:$USER"
 echo "@PASSWD:$PASSWD"
 echo "@TNS:$TNS"
 echo "@SELECT ID , ',', MGR_IP FROM AGENT_INFO_LIST ORDER BY ID;"
 echo "@AGENT_STATUS_FILES:$AGENT_STATUS_FILES"
 echo "#END_OF_FILE"
 exit 0
fi

if
 AGENT_STATUS_UPDATE=`sqlplus ${USER}/${PASSWD}@${TNS} <<END
   set pagesize 999 linesize 999 feedback off verify off echo off head off	
   UPDATE AGENT_INFO_LIST SET ALIVE = ${ALIVE} where ID = '${AGENT_IP}';
   commit;
   exit;
   END`
 exit 0 
fi
