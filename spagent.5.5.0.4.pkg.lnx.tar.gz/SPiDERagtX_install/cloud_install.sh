#!/bin/sh
#set -o xtrace

###########################################################
#                                                         #
#           SPiDER TM Agent Install Script                #
#                                                         #
###########################################################



#20090702 Multi Agent �߰�
###########################################################
#                   print usage                           #
###########################################################


NUM=$#
if [ $NUM != "1" ] && [ $NUM != "2" ] ; then
echo "[ Usage ] : $0 Install_Directory"
echo "[  ex   ] : $0 /opt"
echo "Shutdown $0"
exit 0
fi


if [ $NUM = "1" ] ;
then
    WORK_ROOT=$1/SPiDER"$MULTI_NAME"agtX
else
    exit 0
fi




#20081218 eldiko 
###########################################################
#                     check util                          #
###########################################################
if [ -f  /bin/wc ]; then WC_UTIL=/bin/wc
elif [ -f  /usr/bin/wc ]; then WC_UTIL=/usr/bin/wc
elif [ -f  /sbin/wc ];  then WC_UTIL=/sbin/wc
else 
    WC_UTIL=./util/wc.lnx24
    chmod 755 $WC_UTIL
fi

if [ -f  /bin/uname ]; then UNAME_UTIL=/bin/uname
elif [ -f  /usr/bin/uname ]; then UNAME_UTIL=/usr/bin/uname
elif [ -f  /sbin/uname ];  then UNAME_UTIL=/sbin/uname
else 
    UNAME_UTIL=./util/uname.lnx24
    chmod 755 $UNAME_UTIL
fi


if [ -d $WORK_ROOT ] ;
then
    echo ""
    echo "FAIL : $WORK_ROOT Directory exists."
    echo "done .."
    echo ""
    exit 2
else
    echo ""
    echo "Install Directory : $WORK_ROOT"
    echo ""
fi



CUR_DIR=.

#20090702 Multi Agent �߰�
if [ $NUM = "3" ]; 
then
    XMON_BOOT=xmon
    #XMON_MULTI_BOOT=xmon$MULTI_NAME
    XSPAGENT_BOOT=xagent
    XMON_BOOT_SW=xmon.sw
    #XMON_MULTI_BOOT_SW=xmon.sw$MULTI_NAME
    XSPAGENT_BOOT_SW=xagent.sw
    #RC3D_BOOT=S98xmon$MULTI_NAME
    #INITDDIR=/etc/rc.d/init.d
    #RC3DDIR=/etc/rc.d/rc3.d
else
    XMON_BOOT=xmon
    XSPAGENT_BOOT=xagent
    XMON_BOOT_SW=xmon.sw
    XSPAGENT_BOOT_SW=xagent.sw
    RC3D_BOOT=S98xmon
    INITDDIR=/etc/rc.d/init.d
    RC3DDIR=/etc/rc.d/rc3.d
fi
#20081021 STV �߰� dl0929

MODULE_DIR=$WORK_ROOT/module
CONF_DIR=$WORK_ROOT/conf
UTIL_DIR=$WORK_ROOT/util
#20110210 vuln2 add
VULN2_DIR=$WORK_ROOT/vuln2


#XSPAGENTD_NAME=Spagentd

if [  $NUM = "3" ];
then
sh pns.setup.sh $CUR_DIR/conf $MULTI_NAME
else
sh pns.setup.sh $CUR_DIR/conf 
fi



###########################################################
#                configure environment                    #
###########################################################


###########################################################
#                  create directory                       #
###########################################################
if [ ! -d $WORK_ROOT ]; then /bin/mkdir -p $WORK_ROOT; fi
if [ ! -d $MODULE_DIR ]; then /bin/mkdir -p $MODULE_DIR; fi
if [ ! -d $CONF_DIR ]; then /bin/mkdir -p $CONF_DIR; fi
if [ ! -d $UTIL_DIR ]; then /bin/mkdir -p $UTIL_DIR; fi
if [ ! -d $WORK_ROOT/log ]; then /bin/mkdir -p $WORK_ROOT/log; fi
if [ ! -d $WORK_ROOT/util ]; then /bin/mkdir -p $WORK_ROOT/util; fi

##20110210 vuln2 add
if [ ! -d $VULN2_DIR ]; then /bin/mkdir -p $VULN2_DIR; fi
if [ ! -d $VULN2_DIR/script ]; then /bin/mkdir -p $VULN2_DIR/script; fi
if [ ! -d $VULN2_DIR/result ]; then /bin/mkdir -p $VULN2_DIR/result; fi



###########################################################
#                  copy pkg files                         #
###########################################################

# bin/ copy
#	/bin/cp -rR $CUR_DIR/* $WORK_ROOT/




echo "# INSTALL_LANGUAGE (kor or eng, default:kor): "
echo "INSTALL_LANGUAGE : "
read INSTALL_LANGUAGE

if [ "X$INSTALL_LANGUAGE" != "X" ] 
then 
    :
else
    INSTALL_LANGUAGE="kor"
fi
echo " "


KVER=`$UNAME_UTIL -r`
SUB_KVER=`echo $KVER | cut -c 1-3`
PVER=`$UNAME_UTIL -m`
SW_VER=`$UNAME_UTIL -r | cut -d - -f2`

echo "SW_VER=$SW_VER"
echo "Version Check & Classes Define.."
echo "This Server Version is \"$KVER [$SUB_KVER]\""

if [ $SW_VER = "SWOS" ] ;
then
    KVERNAME="SWOS"
elif [ $SUB_KVER = "2.2" ] ;
then
    KVERNAME="LINUX22"
elif [ $SUB_KVER = "2.4" ] ||
     [ $SUB_KVER = "2.6" ] ;
then
    if [ "$PVER" = "ppc" ] ||
       [ "$PVER" = "ppc64" ] ;
    then
        KVERNAME="LINUXPPC"
    elif [ "$PVER" = "ia64" ]
    then
        KVERNAME="LINUXIA64"
    elif [ "$PVER" = "x86_64" ]
    then
        KVERNAME="LINUX24_64"
    else
        KVERNAME="LINUX24"
    fi
else
    KVERNAME="LINUX24"
fi


echo "This Server CLASSES is \"$KVERNAME\""


###########################################################
#              generate spiderkey.dat file                #
###########################################################
## Get Key
LOOP=1
while [ $LOOP -eq 1 ]
do
    echo ""
    echo "# Insert Secret Key(16 byte) : "
    read TMP_USER_KEY
    
    if test -z "$TMP_USER_KEY";
    then
        TMP_USER_KEY="IGLOO0123456789!"
    fi
    
    KEY_SIZE=`expr length $TMP_USER_KEY`
    
    if [ "$KEY_SIZE" -eq "16" ];
    then
        USER_KEY=$TMP_USER_KEY;
        LOOP=0
    else
        echo "Key Size is wrong(size:$KEY_SIZE)"
        echo "Key Size is 16 byte"
    fi
done

echo $USER_KEY > spiderkey.dat.tmp
MGR_IP=`cat $CUR_DIR/conf/managerip.conf`
rm -f $CUR_DIR/conf/managerip.conf

if [ $KVERNAME = "SWOS" ] ;
then 
	if test -f "./SplogConv.lnx24"
	then
	    /bin/cp $CUR_DIR/SplogConv.lnx24 $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
    	echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
    if test -f "$CUR_DIR/SpbinChk.lnx24"
    then
        /bin/cp $CUR_DIR/SpbinChk.lnx24 $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
        
    if test -f "$CUR_DIR/SpmkCert.lnx24"
    then
        /bin/cp $CUR_DIR/SpmkCert.lnx24 $CUR_DIR/SpmkCert
        ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
elif [ $KVERNAME = "LINUX22" ] ;
then 
	if test -f "./SplogConv.lnx22"
	then
	    /bin/cp $CUR_DIR/SplogConv.lnx22 $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
    	echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
	if test -f "$CUR_DIR/SpbinChk.lnx22"
    then
        /bin/cp $CUR_DIR/SpbinChk.lnx22 $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
    
    if test -f "$CUR_DIR/SpmkCert.lnx22"
    then
        /bin/cp $CUR_DIR/SpmkCert.lnx22 $CUR_DIR/SpmkCert
       ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
elif [ $KVERNAME = "LINUX24" ] ;
then 
	if test -f "./SplogConv.lnx24"
	then
	    /bin/cp $CUR_DIR/SplogConv.lnx24 $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
    	echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
	if test -f "$CUR_DIR/SpbinChk.lnx24"
    then
        /bin/cp $CUR_DIR/SpbinChk.lnx24 $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
    
    if test -f "$CUR_DIR/SpmkCert.lnx24"
    then
        /bin/cp $CUR_DIR/SpmkCert.lnx24 $CUR_DIR/SpmkCert
        ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
elif [ $KVERNAME = "LINUX24_64" ] ;
then 
	if test -f "./SplogConv.lnx24_64"
	then
	    /bin/cp $CUR_DIR/SplogConv.lnx24_64 $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
    	echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
	if test -f "$CUR_DIR/SpbinChk.lnx24_64"
    then
        /bin/cp $CUR_DIR/SpbinChk.lnx24_64 $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
    
    if test -f "$CUR_DIR/SpmkCert.lnx24_64"
    then
        /bin/cp $CUR_DIR/SpmkCert.lnx24_64 $CUR_DIR/SpmkCert
        ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
elif [ $KVERNAME = "LINUXPPC" ] ;
then 
	if test -f "./SplogConv.ppc"
	then
	    /bin/cp $CUR_DIR/SplogConv.ppc $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
        echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
	if test -f "$CUR_DIR/SpbinChk.ppc"
    then
        /bin/cp $CUR_DIR/SpbinChk.ppc $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
    
    if test -f "$CUR_DIR/SpmkCert.ppc"
    then
        /bin/cp $CUR_DIR/SpmkCert.ppc $CUR_DIR/SpmkCert
       ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
elif [ $KVERNAME = "LINUXIA64" ] ;
then 
	if test -f "./SplogConv.lnxia64"
	then
	    /bin/cp $CUR_DIR/SplogConv.lnxia64 $CUR_DIR/SplogConv
    	./SplogConv -K -i spiderkey.dat.tmp -o spiderkey.dat > /dev/null
    	rm -f spiderkey.dat.tmp
	else
    	echo "cannot make key file : key making program is not exist"
    	exit
	fi
	
	if test -f "$CUR_DIR/SpbinChk.lnxia64"
    then
        /bin/cp $CUR_DIR/SpbinChk.lnxia64 $CUR_DIR/SpbinChk
    else
        echo "SpbinChk file is not exist"
        exit
    fi
    
    if test -f "$CUR_DIR/SpmkCert.lnxia64"
    then
        /bin/cp $CUR_DIR/SpmkCert.lnxia64 $CUR_DIR/SpmkCert
        ./SpmkCert makec $MGR_IP $USER_KEY
    else
        echo "SpmkCert file is not exist"
        exit
    fi
fi



##optionf.conf.tmp monitor port ����
/bin/cp $CUR_DIR/conf/option.conf.tmp $CUR_DIR/conf/option.conf.tmp2 || exit 2
if [  $NUM = "3" ];
then
    /bin/sed -e "s|MONITOR_PORT=10001|MONITOR_PORT=$MONITORPORT|g" $CUR_DIR/conf/option.conf.tmp > /tmp/option.conf.tmp
    /bin/mv /tmp/option.conf.tmp $CUR_DIR/conf/option.conf.tmp || exit 2
else
    echo " "
fi




###########################################################
#                 encrypt config files                    #
###########################################################

echo ""
echo "Encryption.."
echo ""

./SplogConv -e -i $CUR_DIR/conf/manager.conf.tmp -o $CUR_DIR/conf/manager.conf > /dev/null


if [ $INSTALL_LANGUAGE = "kor" ]
then
    ./SplogConv -e -i $CUR_DIR/conf/module.conf.tmp -o $CUR_DIR/conf/module.conf > /dev/null
    ./SplogConv -e -i $CUR_DIR/conf/option.conf.tmp -o $CUR_DIR/conf/option.conf > /dev/null
elif [ $INSTALL_LANGUAGE = "eng" ]
then
    ./SplogConv -e -i $CUR_DIR/conf/module.conf.eng -o $CUR_DIR/conf/module.conf > /dev/null
    ./SplogConv -e -i $CUR_DIR/conf/option.conf.eng -o $CUR_DIR/conf/option.conf > /dev/null
else
    ./SplogConv -e -i $CUR_DIR/conf/module.conf.tmp -o $CUR_DIR/conf/module.conf > /dev/null
    ./SplogConv -e -i $CUR_DIR/conf/option.conf.tmp -o $CUR_DIR/conf/option.conf > /dev/null
fi


/bin/mv $CUR_DIR/conf/option.conf.tmp2 $CUR_DIR/conf/option.conf.tmp || exit 2

###########################################################
#                     copy pkg files                      #
###########################################################

## Version copy
echo ""
echo "File Copy.."
echo ""

for ESSENTIAL_FILE in $CUR_DIR/conf/manager.conf $CUR_DIR/conf/option.conf $CUR_DIR/conf/module.conf $CUR_DIR/xmon $CUR_DIR/xagent
do
    if [ ! -f $ESSENTIAL_FILE ] ;
    then
        echo "$ESSENTIAL_FILE File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
done

/bin/cp $CUR_DIR/conf/* $WORK_ROOT/conf/ 2> /dev/null
/bin/cp $CUR_DIR/spiderkey.dat $WORK_ROOT/ 2> /dev/null

#20090705 �߰� 
rm $WORK_ROOT/conf/manager.conf.tmp
rm $WORK_ROOT/conf/option.conf.tmp
rm $WORK_ROOT/conf/module.conf.tmp
rm $WORK_ROOT/conf/module.conf.xtox.tmp
#20090705 �߰� 

if [ $KVERNAME = "SWOS" ] ;
then
    if [ -f $CUR_DIR/spagentd.lnx24 ] && 
       [ -f $CUR_DIR/spmon.lnx24 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnx24 $WORK_ROOT/spagentd
        /bin/cp $CUR_DIR/spmon.lnx24 $WORK_ROOT/spmon
        /bin/cp $CUR_DIR/SpbinChk.lnx24 $WORK_ROOT/SpbinChk
        
        /bin/cp $CUR_DIR/Spsworks_session.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        
        /bin/cp $CUR_DIR/module/swasen.so.lnx24 $MODULE_DIR/swasen.so 2> /dev/null
        /bin/cp $CUR_DIR/util/echo.lnx24 $UTIL_DIR/echo 2> /dev/null
        /bin/cp $CUR_DIR/util/od.lnx24 $UTIL_DIR/od 2> /dev/null
        /bin/cp $CUR_DIR/util/sed.lnx24 $UTIL_DIR/sed 2> /dev/null
        /bin/cp $CUR_DIR/util/uname.lnx24 $UTIL_DIR/uname 2> /dev/null
        /bin/cp $CUR_DIR/util/wc.lnx24 $UTIL_DIR/wc 2> /dev/null
        /bin/cp $CUR_DIR/util/grep.lnx24 $UTIL_DIR/grep 2> /dev/null
        /bin/cp $CUR_DIR/util/xfind.lnx24 $UTIL_DIR/xfind 2> /dev/null
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUX22" ] ;
then
    if [ -f $CUR_DIR/spagentd.lnx22 ] && 
       [ -f $CUR_DIR/spmon.lnx22 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnx22 $WORK_ROOT/spagentd 
        /bin/cp $CUR_DIR/spmon.lnx22 $WORK_ROOT/spmon 
        /bin/cp $CUR_DIR/Spsworks_session.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        
        /bin/cp $CUR_DIR/libcpc++-libc6.1-2.so.3 $WORK_ROOT/
        /bin/cp $CUR_DIR/rcv_udp.lnx22 $WORK_ROOT/rcv_udp
        /bin/cp $CUR_DIR/snmptrapd.lnx22 $WORK_ROOT/snmptrapd
        /bin/cp $CUR_DIR/spcheck.lnx22 $WORK_ROOT/spcheck
        /bin/cp $CUR_DIR/SpbinChk.lnx22 $WORK_ROOT/SpbinChk
        #/bin/cp $CUR_DIR/SplogConv.lnx22 $WORK_ROOT/SplogConv
        /bin/cp $CUR_DIR/util/xfind.lnx22 $UTIL_DIR/xfind 2> /dev/null
        
        /bin/cp $CUR_DIR/opsec_putkey.lnx22 $WORK_ROOT/opsec_putkey 2> /dev/null
        /bin/cp $CUR_DIR/module/snmppoll.so.lnx22 $MODULE_DIR/snmppoll.so 2> /dev/null
        /bin/cp $CUR_DIR/module/checkpoint.so.lnx22 $MODULE_DIR/checkpoint.so 2> /dev/null
        /bin/cp $CUR_DIR/module/sphids.so.lnx22 $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/module/oracle9.so.lnx22 $MODULE_DIR/oracle9.so 2> /dev/null
        /bin/cp $CUR_DIR/module/mysql3.so.lnx22 $MODULE_DIR/mysql3.so 2> /dev/null
        /bin/cp $CUR_DIR/module/esa.so.lnx22 $MODULE_DIR/esa.so 2> /dev/null
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUX24" ];
then
    if [ -f $CUR_DIR/spagentd.lnx24 ] && 
       [ -f $CUR_DIR/spmon.lnx24 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnx24 $WORK_ROOT/spagentd
        /bin/cp $CUR_DIR/spmon.lnx24 $WORK_ROOT/spmon
        /bin/cp $CUR_DIR/Spsworks_session.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        
        /bin/cp $CUR_DIR/libcpc++-libc6.1-2.so.3 $WORK_ROOT/
        /bin/cp $CUR_DIR/libsnmp-0.4.2.5.so $WORK_ROOT/
        /bin/cp $CUR_DIR/rcv_udp.lnx24 $WORK_ROOT/rcv_udp
        /bin/cp $CUR_DIR/snmptrapd.lnx24 $WORK_ROOT/snmptrapd
        /bin/cp $CUR_DIR/spcheck.lnx24 $WORK_ROOT/spcheck
        
        /bin/cp $CUR_DIR/opsec_putkey.lnx24 $WORK_ROOT/opsec_putkey 2> /dev/null
        /bin/cp $CUR_DIR/module/snmppoll.so.lnx24 $MODULE_DIR/snmppoll.so 2> /dev/null
        /bin/cp $CUR_DIR/module/checkpoint.so.lnx24 $MODULE_DIR/checkpoint.so 2> /dev/null
        /bin/cp $CUR_DIR/module/sphids.so.lnx24 $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/module/oracle9.so.lnx24 $MODULE_DIR/oracle9.so 2> /dev/null
        
        /bin/cp $CUR_DIR/module/mysql3.so.lnx24 $MODULE_DIR/mysql3.so 2> /dev/null
        /bin/cp $CUR_DIR/module/esa.so.lnx24 $MODULE_DIR/esa.so 2> /dev/null
        /bin/cp $CUR_DIR/module/swasen.so.lnx24 $MODULE_DIR/swasen.so 2> /dev/null
        /bin/cp $CUR_DIR/module/mysql4.so.lnx24 $MODULE_DIR/mysql4.so 2> /dev/null
        /bin/cp $CUR_DIR/util/echo.lnx24 $UTIL_DIR/echo 2> /dev/null
        
        /bin/cp $CUR_DIR/util/od.lnx24 $UTIL_DIR/od 2> /dev/null
        /bin/cp $CUR_DIR/util/sed.lnx24 $UTIL_DIR/sed 2> /dev/null
        /bin/cp $CUR_DIR/util/uname.lnx24 $UTIL_DIR/uname 2> /dev/null
        /bin/cp $CUR_DIR/util/wc.lnx24 $UTIL_DIR/wc 2> /dev/null
        /bin/cp $CUR_DIR/util/grep.lnx24 $UTIL_DIR/grep 2> /dev/null
        
        /bin/cp $CUR_DIR/util/xfind.lnx24 $UTIL_DIR/xfind 2> /dev/null
        /bin/cp $CUR_DIR/SpbinChk.lnx24 $WORK_ROOT/SpbinChk
        #/bin/cp $CUR_DIR/SplogConv.lnx24 $WORK_ROOT/SplogConv
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUX24_64" ];
then
    if [ -f $CUR_DIR/spagentd.lnx24_64 ] && 
       [ -f $CUR_DIR/spmon.lnx24_64 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnx24_64 $WORK_ROOT/spagentd
        /bin/cp $CUR_DIR/spmon.lnx24_64 $WORK_ROOT/spmon
        /bin/cp $CUR_DIR/Spsworks_session.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        
        /bin/cp $CUR_DIR/libcpc++-libc6.1-2.so.3 $WORK_ROOT/
        /bin/cp $CUR_DIR/libsnmp-0.4.2.5.so $WORK_ROOT/
        /bin/cp $CUR_DIR/rcv_udp.lnx24 $WORK_ROOT/rcv_udp
        /bin/cp $CUR_DIR/snmptrapd.lnx24 $WORK_ROOT/snmptrapd
        /bin/cp $CUR_DIR/spcheck.lnx24_64 $WORK_ROOT/spcheck
        
        /bin/cp $CUR_DIR/opsec_putkey.lnx24 $WORK_ROOT/opsec_putkey 2> /dev/null
        /bin/cp $CUR_DIR/module/snmppoll.so.lnx24_64 $MODULE_DIR/snmppoll.so 2> /dev/null
        /bin/cp $CUR_DIR/module/checkpoint.so.lnx24_64 $MODULE_DIR/checkpoint.so 2> /dev/null
        /bin/cp $CUR_DIR/module/sphids.so.lnx24_64 $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/module/oracle9.so.lnx24_64 $MODULE_DIR/oracle9.so 2> /dev/null
        
        /bin/cp $CUR_DIR/module/mysql3.so.lnx24_64 $MODULE_DIR/mysql3.so 2> /dev/null
        /bin/cp $CUR_DIR/module/esa.so.lnx24_64 $MODULE_DIR/esa.so 2> /dev/null
        /bin/cp $CUR_DIR/module/swasen.so.lnx24_64 $MODULE_DIR/swasen.so 2> /dev/null
        /bin/cp $CUR_DIR/module/mysql4.so.lnx24_64 $MODULE_DIR/mysql4.so 2> /dev/null
        
        /bin/cp $CUR_DIR/util/echo.lnx24 $UTIL_DIR/echo 2> /dev/null
        /bin/cp $CUR_DIR/util/od.lnx24 $UTIL_DIR/od 2> /dev/null
        /bin/cp $CUR_DIR/util/sed.lnx24 $UTIL_DIR/sed 2> /dev/null
        /bin/cp $CUR_DIR/util/uname.lnx24 $UTIL_DIR/uname 2> /dev/null
        /bin/cp $CUR_DIR/util/wc.lnx24 $UTIL_DIR/wc 2> /dev/null
        /bin/cp $CUR_DIR/util/grep.lnx24 $UTIL_DIR/grep 2> /dev/null
        /bin/cp $CUR_DIR/util/xfind.lnx24 $UTIL_DIR/xfind 2> /dev/null
        
        /bin/cp $CUR_DIR/SpbinChk.lnx24_64 $WORK_ROOT/SpbinChk
        #/bin/cp $CUR_DIR/SplogConv.lnx24_64 $WORK_ROOT/SplogConv
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUX26" ];
then
    if [ -f $CUR_DIR/spagentd.lnx26 ] && 
       [ -f $CUR_DIR/spmon.lnx26 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnx24 $WORK_ROOT/spagentd
        /bin/cp $CUR_DIR/spmon.lnx24 $WORK_ROOT/spmon
        /bin/cp $CUR_DIR/Spsworks_session.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        
        /bin/cp $CUR_DIR/libsnmp-0.4.2.5.so $WORK_ROOT/
        /bin/cp $CUR_DIR/rcv_udp.lnx24 $WORK_ROOT/rcv_udp
        /bin/cp $CUR_DIR/snmptrapd.lnx26 $WORK_ROOT/snmptrapd
        /bin/cp $CUR_DIR/spcheck.lnx26 $WORK_ROOT/spcheck
        chmod 700 $WORK_ROOT/spagentd $WORK_ROOT/spmon
        
        /bin/cp $CUR_DIR/opsec_putkey $WORK_ROOT/ 2> /dev/null
        /bin/cp $CUR_DIR/genDKey $WORK_ROOT/ 2> /dev/null
        /bin/cp $CUR_DIR/module/snmppoll.so.lnx26 $MODULE_DIR/snmppoll.so 2> /dev/null
        /bin/cp $CUR_DIR/module/sphids.so.lnx26 $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/module/oracle9.so.lnx26 $MODULE_DIR/oracle9.so 2> /dev/null

        /bin/cp $CUR_DIR/module/mysql3.so.lnx26 $MODULE_DIR/mysql3.so 2> /dev/null
        /bin/cp $CUR_DIR/module/esa.so.lnx26 $MODULE_DIR/esa.so 2> /dev/null
        /bin/cp $CUR_DIR/util/echo.lnx24 $UTIL_DIR/echo 2> /dev/null
        /bin/cp $CUR_DIR/util/od.lnx24 $UTIL_DIR/od 2> /dev/null
        /bin/cp $CUR_DIR/util/sed.lnx24 $UTIL_DIR/sed 2> /dev/null

        /bin/cp $CUR_DIR/util/uname.lnx24 $UTIL_DIR/uname 2> /dev/null
        /bin/cp $CUR_DIR/util/wc.lnx24 $UTIL_DIR/wc 2> /dev/null
        /bin/cp $CUR_DIR/util/grep.lnx24 $UTIL_DIR/grep 2> /dev/null
        /bin/cp $CUR_DIR/util/xfind.lnx24 $UTIL_DIR/xfind 2> /dev/null
        /bin/cp $CUR_DIR/SpbinChk.lnx24 $WORK_ROOT/SpbinChk
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUXPPC" ];
then
    if [ -f $CUR_DIR/spagentd.ppc ] && 
       [ -f $CUR_DIR/spmon.ppc ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.ppc $WORK_ROOT/spagentd
        /bin/cp $CUR_DIR/spmon.ppc $WORK_ROOT/spmon
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/genDKey.ppc $WORK_ROOT/genDKey 2> /dev/null
        
        /bin/cp $CUR_DIR/module/snmppoll.so.ppc $MODULE_DIR/snmppoll.so 2> /dev/null
        /bin/cp $CUR_DIR/module/sphids.so.ppc $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/util/xfind.ppc $UTIL_DIR/xfind 2> /dev/null
        /bin/cp $CUR_DIR/SpbinChk.ppc $WORK_ROOT/SpbinChk
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
elif [ $KVERNAME = "LINUXIA64" ];
then
    if [ -f $CUR_DIR/spagentd.lnxia64 ] && 
       [ -f $CUR_DIR/spmon.lnxia64 ]    ;
    then
        /bin/cp $CUR_DIR/spagentd.lnxia64 $WORK_ROOT/spagentd 
        /bin/cp $CUR_DIR/spmon.lnxia64 $WORK_ROOT/spmon 
        /bin/cp $CUR_DIR/TB_Space.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/SpwatchX.sh $WORK_ROOT/
        /bin/cp $CUR_DIR/module/snmppoll.so.lnxia64 $MODULE_DIR/snmppoll.so 2> /dev/null
        
        /bin/cp $CUR_DIR/module/sphids.so.lnxia64 $MODULE_DIR/sphids.so 2> /dev/null
        /bin/cp $CUR_DIR/util/xfind.lnxia64 $UTIL_DIR/xfind 2> /dev/null
        /bin/cp $CUR_DIR/SpbinChk.lnxia64 $WORK_ROOT/SpbinChk
    else
        echo "Suitable Binary File is nonexistent"
        echo "SPiDER TM Agent Install is failed"
        exit 2
    fi
else
    echo "SPiDER TM Agent does not support this Linux Version $KVERNAME!!!"
    echo "SPiDER TM Agent Install is failed"
    exit 2
fi

##20110210 vuln2 add
/bin/sh vuln2.sh $VULN2_DIR > /dev/null



###########################################################
#                    add boot script                      #
###########################################################


## boot script
#	/bin/sed -e "s|SPXAGT_DIR=|SPXAGT_DIR=$WORK_ROOT|g" -e "s|LD_LIBRARY_PATH=|LD_LIBRARY_PATH=\$\{LD_LIBRARY_PATH\}\:$WORK_ROOT|g" $CUR_DIR/$XMON_BOOT > /tmp/$XMON_BOOT.new
#	/bin/mv /tmp/$XMON_BOOT.new $INITDDIR/$XMON_BOOT || exit 2
#	/bin/ln -s $INITDDIR/$XMON_BOOT $WORK_ROOT/$XMON_BOOT || exit 2
#	/bin/chmod 700 $INITDDIR/$XMON_BOOT

if [ $KVERNAME = "SWOS" ] ;then
	/bin/sed -e "s|SPXAGT_DIR=|SPXAGT_DIR=$WORK_ROOT|g" $CUR_DIR/$XSPAGENT_BOOT_SW > /tmp/$XSPAGENT_BOOT.new1
else
	/bin/sed -e "s|SPXAGT_DIR=|SPXAGT_DIR=$WORK_ROOT|g" $CUR_DIR/$XSPAGENT_BOOT > /tmp/$XSPAGENT_BOOT.new1
fi
	
/bin/mv /tmp/$XSPAGENT_BOOT.new1 $WORK_ROOT/$XSPAGENT_BOOT || exit 2

/bin/chmod 700 $WORK_ROOT/$XSPAGENT_BOOT

if [ $KVERNAME = "SWOS" ] ;then
	/bin/sed -e "s|SPXAGT_DIR=|SPXAGT_DIR=$WORK_ROOT|g" $CUR_DIR/$XMON_BOOT_SW > /tmp/$XMON_BOOT.new1
else
	/bin/sed -e "s|SPXAGT_DIR=|SPXAGT_DIR=$WORK_ROOT|g" $CUR_DIR/$XMON_BOOT > /tmp/$XMON_BOOT.new1
fi
	
/bin/mv /tmp/$XMON_BOOT.new1 $WORK_ROOT/$XMON_BOOT || exit 2

/bin/chmod 700 $WORK_ROOT/$XMON_BOOT

# for sniper
if [ -f /etc/init.d/rc.local ]; then
    echo "$WORK_ROOT/$XMON_BOOT start" >> /etc/init.d/rc.local || exit 2
# for secureworks (by. eldiko 20081218)
elif [ -f /conf/init.post ]; then
    echo "$WORK_ROOT/$XMON_BOOT start" >> /conf/init.post || exit 2
else
    if [ ! -f /etc/rc.d/rc.local ];
    then
        /bin/touch /etc/rc.d/rc.local
    fi
    
    echo "" >> /etc/rc.d/rc.local
    echo "$WORK_ROOT/$XMON_BOOT start" >> /etc/rc.d/rc.local || exit 2
fi

cd $WORK_ROOT
chmod 700 * 2> /dev/null
cd $CONF_DIR
chmod 600 * 2> /dev/null
rm -rf spidertm.key
cd $MODULE_DIR
chmod 700 *.so 2> /dev/null
cd $VULN2_DIR/script
chmod 700 * 2> /dev/null
cd $UTIL_DIR 2> /dev/null
chmod 700 * 2> /dev/null
cd $CUR_DIR


#	if [ ! -e $RC3DDIR/$RC3D_BOOT ]; then /bin/ln -s $INITDDIR/$XMON_BOOT $RC3DDIR/$RC3D_BOOT; fi

echo "	"
echo "SPiDER TM Agent Installation success!!!"
echo "done .."
echo "	"
exit 0
