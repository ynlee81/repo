#!/bin/ksh
################################################################################
# This is program that gathering in ESM Log Event and Drop Table with LogEvent Table
# Usage : ./TB_Space.sh oracle_home db_user db_passwd db_sid db_tablespace_name 
# ex) ./TB_Space.sh /home/oracle/OraHome1 adminx adminx SPIDERX SPIDERX 
#     ./TB_Space.sh /home/oracle/OraHome1 adminx adminx FILADB SPIDERX
#     adminx 50000 49953.6875 .09
################################################################################

#ORACLE_BASE=/home/oracle; export ORACLE_BASE
ORACLE_HOME=$1; export ORACLE_HOME
export NLS_LANG=American_America.UTF8

export TNS_ADMIN=$ORACLE_HOME/network/admin
export ORA_NLS33=$ORACLE_HOME/ocommon/nls/admin/data
export PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/ccs/bin:$ORACLE_HOME/bin:/usr/java14/bin:/usr/local/bin:
export LD_LIBRARY_PATH=$ORACLE_HOME/lib32:/lib:/usr/lib:$ORACLE_HOME/rdbms/lib:$LD_LIBRARY_PATH
export LIBPATH=$ORACLE_HOME/lib32:$LIBPATH
export SHLIB_PATH=$ORACLE_HOME/lib32:$SHLIB_PATH

PROGRAM=$0;

WDB_USR=$2;
WDB_PWD=$3;
WDB_SID=$4;
WDB_TBS=$5;
#WMGR_IP=$6;


WDATA_FILES=`sqlplus -S ${WDB_USR}/${WDB_PWD}@${WDB_SID} <<END
   set pagesize 0 feedback off verify off heading off echo off
   SELECT ltrim(SUM(BYTES)/1024/1024) FROM DBA_DATA_FILES WHERE TABLESPACE_NAME = '${WDB_TBS}';
   exit;
   END`

WFREE_SPACE=`sqlplus -S ${WDB_USR}/${WDB_PWD}@${WDB_SID} <<END
   set pagesize 0 feedback off verify off heading off echo off
   SELECT ltrim(SUM(BYTES)/1024/1024) FROM DBA_FREE_SPACE WHERE TABLESPACE_NAME = '${WDB_TBS}';
   exit;
   END`


WUSAGE=`sqlplus -S ${WDB_USR}/${WDB_PWD}@${WDB_SID} <<END
   set pagesize 0 feedback off verify off heading off echo off
   select ltrim(trunc ( (${WDATA_FILES} - ${WFREE_SPACE}) * 100 / ${WDATA_FILES}, 2)) from dual;
   exit;
   END`

echo "USER:$WDB_USR"
echo "TOTAL:$WDATA_FILES"
echo "FREE:$WFREE_SPACE"
echo "USAGE:$WUSAGE"

#V_TEXT="$WDB_TBS=$WUSAGE% (Total=$WDATA_FILES M / Free=$WFREE_SPACE M)"
#echo $V_TEXT

#INSERT_V=`sqlplus -S ${DB_USR}/${DB_PWD}@${DB_SID} <<END
#   set pagesize 0 feedback off verify off heading off echo off
#   INSERT INTO SPIDERX_SYSTEM_LOG 
#             ( SEQUENCE, MGR_TIME, MGR_IP, ORIGIN, TYPE, STATUS, CODE, TEXT ) 
#      Values ( 'sequence', sysdate, '${WMGR_IP}', '${WMGR_IP}', 0, 0, 0, '${V_TEXT}' );
#   exit;
#   END`
