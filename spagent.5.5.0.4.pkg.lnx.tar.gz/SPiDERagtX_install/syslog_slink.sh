#!/bin/sh
#
#

# need to modify
#SYSLOG_DIR=/opt/SECUREWORKS/4.0/logs/syslog
SYSLOG_DIR=/tmp

# if SPiDER TM 2.5, need to modify
#SPAGT_DIR=/opt/SPiDERagt
#SYSLOG_LOG=$SPAGT_DIR/log/syslog_slink.log

# if SPiDER TM 3.0, need to modify
SPAGTX_DIR=/opt/SPiDERagtX
SYSLOG_LOG=$SPAGTX_DIR/log/syslog_slink.log

SLEEP_TIME_SEC=30

echo "" >> $SYSLOG_LOG
echo "---------------------------------------------------------" >> $SYSLOG_LOG
echo "`date +%m%d` `date +%H%M%S` $0 START!!" >> $SYSLOG_LOG

SAVE_DATE="x"
while [ 1 ]
do
CURR_DATE="`date +%Y%m`"
CURR_TIME="`date +%m%d` `date +%H%M%S`"

echo "current : $CURR_DATE, save : $SAVE_DAY"

if [ $SAVE_DATE != $CURR_DATE ] &&
   [ -f syslog-$CURR_DATE.log ]  # need to modify (ex. syslog-$CURR_DATE.log)
then  

    # need to modify (ex. syslog-200803.log -> syslog)
    ln -s -f $SYSLOG_DIR/syslog-$CURR_DATE.log $SYSLOG_DIR/syslog.log

    echo "$CURR_TIME syslog link [ syslog-$CURR_DATE.log ] !!" >> $SYSLOG_LOG
    SAVE_DAY=$CURR_DATE

fi

sleep $SLEEP_TIME_SEC
done


