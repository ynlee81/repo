#!/bin/sh
#
#
# version 20081219 

SPXAGT_DIR=/mnt2/SPiDERagtX
export SPXAGT_DIR
SPWATCH_LOG=$SPXAGT_DIR/log/spwatch.log
SLEEP_TIME_SEC=30

if [ -f  /bin/wc ]; then WC_UTIL=/bin/wc
elif [ -f  /usr/bin/wc ]; then WC_UTIL=/usr/bin/wc
elif [ -f  /sbin/wc ];  then WC_UTIL=/sbin/wc
else 
    WC_UTIL=$SPXAGT_DIR/util/wc
fi

#killproc() {        # kill the named process(es)
#    pid=`/bin/ps -e |
#         /bin/grep $1 |
#         /bin/sed -e 's/^  *//' -e 's/ .*//'`
#    [ "$pid" != "" ] && kill -9 $pid
#}
killproc() {        # kill the named process(es)
    pid=`/bin/ps -ef |
         /bin/grep $1 | /bin/grep -v grep|
         /bin/sed -e 's/^ *//' -e 's/^root*//' -e 's/^ *//' -e 's/ .*//'`
    echo "killed $pid"
    [ "x$pid" != "x" ] && kill -9 $pid
}
echo "" >> $SPWATCH_LOG
echo "---------------------------------------------------------" >> $SPWATCH_LOG
echo "`date +%m%d` `date +%H%M%S` SPiDER TM $0 START!!" >> $SPWATCH_LOG


while [ 1 ]
do
CURR_TIME="`date +%m%d` `date +%H%M%S`"

if [ `/bin/ps -ef |/bin/grep spagentd | /bin/grep -v grep |$WC_UTIL -l` -eq "0" ]
then

    # When not exist
    echo "$CURR_TIME SPiDER TM Agent is not running." >> $SPWATCH_LOG
    cd $SPXAGT_DIR
    ./spagentd
    echo "$CURR_TIME SPiDER TM Agent START!!" >> $SPWATCH_LOG

elif [ `/bin/ps -ef |/bin/grep -w spagentd | /bin/grep 'defunct' | /bin/grep -v grep |$WC_UTIL -l` -ge "1" ] ||
     [ `/bin/ps -ef |/bin/grep -w spagentd | /bin/grep -v grep | /bin/grep ' 1 ' | $WC_UTIL -l` -ne "1" ] ||
     [ `/bin/ps -ef| /bin/grep '\[spagentd\]' | /bin/grep -v grep | $WC_UTIL -l` -ge "1" ]
then

    # When spagentd is defunct process
    echo "$CURR_TIME SPiDER TM Agent is Defunct process." >> $SPWATCH_LOG
    killproc spagentd
    sleep 5
fi

#    if [ -f $SPXAGT_DIR/Spsworks_session.sh ] &&
#       [ `/bin/ps -ef |/bin/grep Spsworks | /bin/grep -v grep |$WC_UTIL -l` -eq "0" ];
#    then
#            echo "SPiDER TM Agent SecureWorks Session Count shell started." >> $SPWATCH_LOG
#            $SPXAGT_DIR/Spsworks_session.sh &
#    fi

sleep $SLEEP_TIME_SEC
done

