#!/bin/ksh

if [ $# -lt "1" ]; then
echo "[ Usage ] : $0 conf_dir"
echo "[ Usage ] : $0 conf_dir multi_dir"
echo "Shutdown $0"
exit 0
fi


CONF_DIR=$1

if [ $# -gt 1 ]; then
MULTI_DIR=$2
fi

LIMIT=3
LIMIT10=10

i=0
while [ 1 ]
do
    if [ "$i" -eq "3" ]
    then 
        exit 0
    fi

    echo "# PNS IP : "
    read PNS_IP

    if [ "X$PNS_IP" != "X" ] 
    then 
        break
    else
        echo "sorry, invalid PNS IP. try again.."
        echo " "
        i=`expr $i + 1`
    fi

done

i=0
while [ 1 ]
do
    if [ "$i" -eq "3" ]
    then 
        exit 0
    fi

    echo "# PNS PORT : "
    read PNS_PORT

    if [ "X$PNS_PORT" != "X" ] 
    then 
        break
    else
        echo "sorry, invalid PNS PORT. try again.."
        echo " "
        i=`expr $i + 1`
    fi

done


i=0
while [ 1 ]
do
    if [ "$i" -eq "3" ]
    then 
        exit 0
    fi

    echo "# PNS REF KEY : "
    read PNS_REF_KEY

    if [ "X$PNS_REF_KEY" != "X" ] 
    then 
        break
    else
        echo "sorry, invalid PNS REF KEY. try again.."
        echo " "
        i=`expr $i + 1`
    fi

done


i=0
while [ 1 ] 
do
    if [ "$i" -eq "3" ]
    then 
        exit 0
    fi

    echo "# IP Mapping of 127.0.0.1 :"
    read IPMAP

    if [ "X$IPMAP" != "X" ] 
    then 
        break
    else
        echo "sorry, invalid IP mapping. try again.."
        echo " "
        i=`expr $i + 1`
    fi

done


echo "# ENCRYPT_MODE (OPENSSL or PLAIN , default:OPENSSL): "
read ENCRYPT_MODE
if [ "X$ENCRYPT_MODE" = "X" ] 
then 
    ENCRYPT_MODE=OPENSSL
fi
if [ "X$ENCRYPT_MODE" != "XOPENSSL" ] &&
   [ "X$ENCRYPT_MODE" != "XPLAIN" ] ;
then
    echo "sorry, invalid ENCRYPT_MODE."
    ENCRYPT_MODE=OPENSSL
fi



echo ""
echo "PNS_IP       : $PNS_IP"
echo "$PNS_IP" >  $CONF_DIR/managerip.conf
echo "PNS_PORT     : $PNS_PORT"
echo "PNS_REF_KEY  : $PNS_REF_KEY"
echo "IPMAP        : 127.0.0.1=$IPMAP"
echo "ENCRYPT_MODE : $ENCRYPT_MODE"
echo ""

echo "#" > $CONF_DIR/manager.conf.tmp
echo >> $CONF_DIR/manager.conf.tmp
echo "#manager.conf" >> $CONF_DIR/manager.conf.tmp
echo >> $CONF_DIR/manager.conf.tmp
#echo
echo "PNS_IP=$PNS_IP" >> $CONF_DIR/manager.conf.tmp
echo "PNS_PORT=$PNS_PORT" >> $CONF_DIR/manager.conf.tmp
echo "PNS_REF_KEY=$PNS_REF_KEY" >> $CONF_DIR/manager.conf.tmp
echo >> $CONF_DIR/manager.conf.tmp
echo "IP_MAP=127.0.0.1=$IPMAP" >> $CONF_DIR/manager.conf.tmp
echo >> $CONF_DIR/manager.conf.tmp
echo "ENCRYPT_MODE=$ENCRYPT_MODE" >> $CONF_DIR/manager.conf.tmp
echo >> $CONF_DIR/manager.conf.tmp


