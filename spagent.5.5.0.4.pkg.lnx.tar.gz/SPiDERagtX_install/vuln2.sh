#!/bin/sh

if [ $# != "1" ]; then
echo "[ Usage ] : $0 vuln2_dir"
echo "Shutdown $0"
exit 0
fi

VULN2_DIR=$1

if [ -f ./vuln2/script/vuln2_start.sh ];
then
./SplogConv -e -i ./vuln2/script/vuln2_start.sh -o $VULN2_DIR/script/vuln2_start.sh.enc > /dev/null
fi

if [ -f ./vuln2/script/vuln2_end.sh ];
then
./SplogConv -e -i ./vuln2/script/vuln2_end.sh -o $VULN2_DIR/script/vuln2_end.sh.enc > /dev/null
fi

echo $VULN2_DIR
i=1
while [ 1 ]
do
	if [ $i -gt 99 ]
	then
	    if [ -f ./vuln2/script/SC0$i.sh ];
               then	
 	       ./SplogConv -e -i ./vuln2/script/SC0$i.sh -o $VULN2_DIR/script/SC0$i.sh.enc > /dev/null
	    fi
	    if [ -f ./vuln2/script/SF0$i.sh ];
               then	
	       ./SplogConv -e -i ./vuln2/script/SF0$i.sh -o $VULN2_DIR/script/SF0$i.sh.enc > /dev/null
	    fi
	fi

	i=`expr $i + 1`
	if [ $i -gt 800 ]
        then
            exit
        fi
done

exit
