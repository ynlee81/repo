# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : Crontab ���� ������ ���� ����


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0214"

VULN_RESULT="0"

CHKFLAG="NO"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    #FILES="/etc/cronlog.conf /etc/crontab /etc/cron.daily/* /etc/cron.hourly/* /etc/cron.monthly/* /etc/cron.weekly/* /var/spool/cron/*"
    #FILES="/var/adm/cron/* /var/spool/cron/crontabs/* /var/adm/cron/cron.allow /var/adm/cron/cron.deny"
    FILES="/var/adm/cron/* /var/spool/cron/crontabs/*"
        
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	CHKFLAG="YES"
            fi
        fi
    done
    
    if [ $CHKFLAG = "NO" ]
    then
    	exit
    fi
    
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	echo "$file ( Permission :" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1		
            fi
        fi
    done
    	
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

elif [ $OS = "HP-UX" ]
then

    #FILES="/etc/cron /etc/crontab /etc/cron.daily/* /etc/cron.hourly/* /etc/cron.monthly/* /etc/cron.weekly/* /var/spool/cron/*"
    #FILES="/var/adm/cron/* /var/spool/cron/crontabs/* /var/adm/cron/cron.allow /var/adm/cron/cron.deny"
    FILES="/var/adm/cron/* /var/spool/cron/crontabs/*"

    for file in $FILES
    do
    	if [ -f $file ]
            then               
                if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
                then
                    :
                else
    		CHKFLAG="YES"
                fi
            fi
    done
    
    if [ $CHKFLAG = "NO" ]
    then
    	exit
    fi
    
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            #if [ `ls -alL $file | grep '........-.' | wc -l ` -eq 1 ]
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	#ls -alL $file >> $RESULT_FILE 2>&1		
    	    	echo "$file ( Permission :" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1		
            fi
        fi
    done
    	
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

elif [ $OS = "Linux" ]
then
    
    #FILES="/etc/crontab /etc/cron.daily/* /etc/cron.hourly/* /etc/cron.monthly/* /etc/cron.weekly/* /var/spool/cron/*"
    FILES="/etc/crontab /var/spool/cron/* /etc/cron.hourly/* /etc/cron.daily/* /etc/cron.weekly/* /etc/cron.monthly/* /etc/cron.allow /etc/cron.deny"
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	CHKFLAG="YES"
            fi
        fi
    done
    
    if [ $CHKFLAG = "NO" ]
    then
    	exit
    fi
    
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	#ls -alL $file >> $RESULT_FILE 2>&1		
    	    	echo "$file ( Permission :" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1		
            fi
        fi
    done
    	
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

elif [ $OS = "SunOS" ]
then
    
    #FILES="/etc/crontab /etc/cron.daily/* /etc/cron.hourly/* /etc/cron.monthly/* /etc/cron.weekly/* /var/spool/cron/*"
    FILES="/etc/cron.d/* /var/spool/cron/crontabs/* /etc/default/cron  /etc/cron.d/cron.allow, /etc/cron.d/cron.deny"
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	CHKFLAG="YES"
            fi
        fi
    done
    
    if [ $CHKFLAG = "NO" ]
    then
    	exit
    fi
    
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    for file in $FILES
    do
    	if [ -f $file ]
        then
            if [ `ls -alL $file | grep '^-.......-.' | wc -l ` -eq 1 ]
            then
                :
            else
    	    	#ls -alL $file >> $RESULT_FILE 2>&1		
    	    	echo "$file ( Permission :" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1		
            fi
        fi
    done
    	
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi




