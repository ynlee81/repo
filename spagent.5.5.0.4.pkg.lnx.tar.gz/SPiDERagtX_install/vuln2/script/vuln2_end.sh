#!/bin/sh
# $SPXAGT_DIR/assess/systemscript/S?????.sh ip id result_filename

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="S00001"
echo "<!--`date '+%Y/%m/%d %H:%M:%S'` -->" >> $RESULT_FILE 2>&1
echo "</RESULTS>" >> $RESULT_FILE 2>&1
exit
