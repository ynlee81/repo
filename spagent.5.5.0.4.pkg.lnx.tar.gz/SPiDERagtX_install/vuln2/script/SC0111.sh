# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : �н����� �ּ� ��� �Ⱓ ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0111"
VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"


OS=`uname -s`
if [ $OS = "AIX" ]
then
    PASS_MIN_DAYS_FILE="/etc/security/user"
    
    if [ -f "$PASS_MIN_DAYS_FILE" ]
    then
        if [ `grep -i "minage" $PASS_MIN_DAYS_FILE | grep -v "*" | awk '{print $3}' | wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        else
            if [ `grep -i "minage" $PASS_MIN_DAYS_FILE | grep -v "*" | awk '{print $3}'` -gt 0 ]
            then
        	    :
        	else
        	    CHKFLAG="NO"
            fi
        fi
    else
        CHKFLAG="NO"
    fi
    
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT> " >> $RESULT_FILE 2>&1
		
        #echo "�н����� �ּ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$PASS_MIN_DAYS_FILE" ]
      	then 
    		VULN_RESULT="1"
    		#echo "(������ �ּһ��Ⱓ:" `cat /etc/security/user | grep -i "minage" | grep -v "*"|awk '{print $3}'` " ��)" >> $RESULT_FILE 2>&1
    		echo "$PASS_MIN_DAYS_FILE ( Password Min Weeks :" `grep -i "minage" $PASS_MIN_DAYS_FILE | grep -v "*" | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ּ� ���ð� ���� $PASS_MIN_DAYS_FILE ������ �������� ����)" >> $RESULT_FILE 2>&1
    		echo "$PASS_MIN_DAYS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
elif [ $OS = "HP-UX" ]
then

    # /etc/default/security ������ ���� �ϴ� ���
    if [ -f "/etc/default/security" ]
    then
    
        # PASS_MIN_DAYS �� ���� �Ǿ� �ִ��� Ȯ��
    	if [ `grep -i "PASS_MIN_DAYS" /etc/default/security | grep -v "#"|awk '{print $2}' | wc -l` -eq 0 ]
      	then
      	    #���� �ȵǾ� ���� ���
    		CHKFLAG="NO"
      	else
      	    #PASS_MIN_DAYS�� 0���� ���� �Ǿ� �ִ� ���
      	    if [ `grep -i "PASS_MIN_DAYS" /etc/default/security | grep -v "#"|awk '{print $2}'` -eq 0 ]
      	    then
      	        CHKFLAG="NO"
      	    fi
      	    
        fi
    else
        # /etc/default/security ������ ���� ���� �ʴ� ���
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	
        #echo "�н����� �ּ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "/etc/default/security" ]
      	then 
    		VULN_RESULT="1"
    		# ������ �����ϳ� ������ �ȵǾ� �ִ� ���
    		if [ `grep -i "PASS_MIN_DAYS" /etc/default/security | grep -v "#"|awk '{print $2}' | wc -l` -eq 0 ]
      	    then
      	        echo "/etc/default/security (not setting)" >> $RESULT_FILE 2>&1
      	        
      	    # PASS_MIN_DAYS ������ 0���� �Ǿ� �ִ� ���
      	    elif [ `grep -i "PASS_MIN_DAYS" /etc/default/security | grep -v "#"|awk '{print $2}'` -eq 0 ]
    	    then
    		    echo "/etc/default/security ( Password Min Days :" `cat /etc/default/security | grep -i "PASS_MIN_DAYS" | grep -v "#"|awk '{print $2}'` " )" >> $RESULT_FILE 2>&1    		    
    		fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ּ� ���ð� ���� /etc/default/security ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found (/etc/default/security)" >> $RESULT_FILE 2>&1
    		echo "/etc/default/security ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
    exit
elif [ $OS = "Linux" ]
then

    if [ -f /etc/login.defs ]
    then
    	:
    else
    	CHKFLAG="NO"
    fi
    
    if [ `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" | grep -v "#"|awk '{print $2}'|wc -l` -eq 0 ]
    then
    	CHKFLAG="NO"
    else
    	if [ `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" |  grep -v "#"|awk '{print $2}'` -gt 0 ]
    	then
    		:
    	else
    		CHKFLAG="NO"
    	fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	
        #echo "�н����� �ּ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f /etc/login.defs ]
      	then 
    		VULN_RESULT="1"
    		
    		if [ `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" | grep -v "#"|awk '{print $2}'|wc -l` -eq 0 ]
            then
    		    echo "/etc/login.defs file (not setting)" >> $RESULT_FILE 2>&1
    		elif [ `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" |  grep -v "#"|awk '{print $2}'` -eq 0 ]
    	    then
    	        #echo "(������ �ּһ��Ⱓ:" `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" | grep -v "#"|awk '{print $2}'` " ��)" >> $RESULT_FILE 2>&1
    		    echo "/etc/login.defs ( Password Min Days : " `cat /etc/login.defs | grep -i "PASS_MIN_DAYS" | grep -v "#"|awk '{print $2}'` " )"  >> $RESULT_FILE 2>&1
    	    else
    	        :
    	    fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ּ� ���ð� ���� /etc/login.defs ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found (/etc/login.defs)" >> $RESULT_FILE 2>&1
    		echo "/etc/login.defs ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
elif [ $OS = "SunOS" ]
then

    if [ -f /etc/default/passwd ]
    then
    	:
    else
    	CHKFLAG="NO"
    fi
    
    if [ `cat /etc/default/passwd | grep -i 'MINWEEKS.*[0-9]'| grep -v "#" | wc -l ` -eq 0 ]
    then
    	CHKFLAG="NO"
    else
    	if [ `cat /etc/default/passwd | grep 'MINWEEKS.*[0-9]'| awk -F= '{print $2}'` -gt 0 ]
    	then
    		:
    	else
    		CHKFLAG="NO"
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	
        #echo "�н����� �ּ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f /etc/default/passwd ]
      	then 
    		VULN_RESULT="1"
    		
    		if [ `cat /etc/default/passwd | grep -i 'MINWEEKS.*[0-9]'| grep -v "#" | wc -l ` -eq 0 ]
    	    then
    		    echo "/etc/default/passwd (not setting)" >> $RESULT_FILE 2>&1
    		else
    		
        		if [ `cat /etc/default/passwd | grep 'MINWEEKS.*[0-9]'| awk -F= '{print $2}'` -eq 0 ]
        	    then
        		    #echo "(������ �ּһ��Ⱓ:" `cat /etc/default/passwd | grep 'MINWEEKS.*[0-9]'| awk -F= '{print $2}'` " ��)" >> $RESULT_FILE 2>&1
        		    echo "/etc/default/passwd ( Password Min Weeks :" `cat /etc/default/passwd | grep 'MINWEEKS.*[0-9]'| awk -F= '{print $2}'` " )" >> $RESULT_FILE 2>&1
        		    
        		else
        		    exit   #�Ұ����ѻ�Ȳ
        		fi
        	fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ּ� ���ð� ���� /etc/default/passwd ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found (/etc/default/passwd)" >> $RESULT_FILE 2>&1
    		echo "/etc/default/passwd ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi
exit 0
