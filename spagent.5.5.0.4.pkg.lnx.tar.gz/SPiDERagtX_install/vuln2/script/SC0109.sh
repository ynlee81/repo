# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : �н����� �ּ� ���� ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0109"
VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

OS=`uname -s`
if [ $OS = "AIX" ]
then
    MINLEN_FILE="/etc/security/user"

    if [ -f "$MINLEN_FILE" ]
    then
    
        if [ `grep -i "minlen" $MINLEN_FILE | grep -v "*" | awk '{print $3}'| wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        else
        
            if [ `grep -i "minlen" $MINLEN_FILE | grep -v "*" | awk '{print $3}'` -gt 7 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        
        fi

    else
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

        echo "	  <CONTENT> " >> $RESULT_FILE 2>&1
    	
        #echo "�н����� �ּұ��� ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$MINLEN_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		if [ `grep -i minlen $MINLEN_FILE | grep -v "*" | awk '{print $3}'| wc -l` -eq 0 ]
            then
                echo "$MINLEN_FILE (not setting)" >> $RESULT_FILE 2>&1
            else
                #echo "(������ �ּұ���:" `cat /etc/security/user | grep -i "minlen"|  grep -v "*" | awk '{print $3}'` "��)" >> $RESULT_FILE 2>&1
    		    echo "$MINLEN_FILE ( Password Min Length :" `grep -i "minlen" $MINLEN_FILE | grep -v "*" | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
    		fi
      	else
    		VULN_RESULT="1"
           	#echo "(�н����� �ּұ��� ���� /etc/security/user ������ �������� ����)"   >> $RESULT_FILE 2>&1
    		echo "$MINLEN_FILE ( File not found )"   >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
elif [ $OS = "HP-UX" ]
then
    MINLEN_FILE="/etc/default/security"
    
    if [ -f "$MINLEN_FILE" ]
    then
    	if [ `grep -i "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'| wc -l` -eq 0 ]
      	then
    		CHKFLAG="NO"
      	else
            if [ `grep -i "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'` -gt 7 ]
    		then
    			:
         	else
    			CHKFLAG="NO"
        	fi
    	fi
    else
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "	  <CONTENT> " >> $RESULT_FILE 2>&1
		
        #echo "�н����� �ּұ��� ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$MINLEN_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		if [ `grep -i "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'| wc -l` -eq 0 ]
      	    then
    		    echo "$MINLEN_FILE (not setting)" >> $RESULT_FILE 2>&1
            else
                #echo "(������ �ּұ���:" `cat /etc/default/security | grep -i "PASS_MIN_LEN"| grep -v "#" | awk '{print $2}'` "��)" >> $RESULT_FILE 2>&1
    		    echo "$MINLEN_FILE ( Password Min Length : " `cat /etc/default/security | grep -i "PASS_MIN_LEN"| grep -v "#" | awk '{print $2}'` ")" >> $RESULT_FILE 2>&1
    		fi
      	else
    		VULN_RESULT="1"
           	#echo "(�н����� �ּұ��� ���� $MINLEN_FILE ������ �������� ����)"   >> $RESULT_FILE 2>&1
    		echo "$MINLEN_FILE ( File not found )"   >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
   
	 	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
elif [ $OS = "Linux" ]
then
    MINLEN_FILE="/etc/login.defs"
    
    if [ -f "$MINLEN_FILE" ]
    then
    	:
    else
        CHKFLAG="NO"
    fi
    
    if [ `grep "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'| wc -l` -eq 0 ]
    then
    	CHKFLAG="NO"
    else
        if [ `grep "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'` -gt 7 ]
    	then
    		:
        else
    		CHKFLAG="NO"
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		
        #echo "�н����� �ּұ��� ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$MINLEN_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		if [ `grep "PASS_MIN_LEN" $MINLEN_FILE | grep -v "#" | awk '{print $2}'| wc -l` -eq 0 ]
            then
                echo "$MINLEN_FILE (not setting)" >> $RESULT_FILE 2>&1
            else
                
    		    #echo "(������ �ּұ���:" `cat /etc/login.defs | grep "PASS_MIN_LEN"| grep -v "#" | awk '{print $2}'` "��)" >> $RESULT_FILE 2>&1
    		    echo "$MINLEN_FILE ( Password Min Length : " `cat /etc/login.defs | grep "PASS_MIN_LEN"| grep -v "#" | awk '{print $2}'` ")" >> $RESULT_FILE 2>&1
    		fi
      	else
    		VULN_RESULT="1"
           	#echo "(�н����� �ּұ��� ���� $MINLEN_FILE ������ �������� ����)"   >> $RESULT_FILE 2>&1
    		echo "$MINLEN_FILE ( File not found )"   >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
elif [ $OS = "SunOS" ]
then
    MINLEN_FILE="/etc/default/passwd"

    if [ -f "$MINLEN_FILE" ]
    then
    	if [ `grep 'PASSLENGTH.*[0-9]' $MINLEN_FILE | grep -v "#" | wc -l` -eq 0 ]
      	then
    		CHKFLAG="NO"
      	else
        	if [ `grep  'PASSLENGTH.*[0-9]' $MINLEN_FILE | grep -v "#" |awk -F= '{print $2}'` -gt 7 ]
    		then
    			:
         	else
    			CHKFLAG="NO"
        	fi
    	fi
    else
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

		echo " 	  <CONTENT> " >> $RESULT_FILE 2>&1
    	
        #echo "�н����� �ּұ��� ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$MINLEN_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		if [ `grep 'PASSLENGTH.*[0-9]' $MINLEN_FILE | grep -v "#" | wc -l` -eq 0 ]
      	    then
      	        
      	        echo "$MINLEN_FILE (not setting)" >> $RESULT_FILE 2>&1
      	    else
      	        
    		    #echo "(������ �ּұ���:" `cat /etc/login.defs | grep -i "PASS_MIN_LEN"| grep -v "#" | awk '{print $2}'` "��)" >> $RESULT_FILE 2>&1
    		    echo "$MINLEN_FILE ( Password Min Length : " `cat /etc/default/passwd | grep  'PASSLENGTH.*[0-9]'| grep -v "#"|awk -F= '{print $2}'`")" >> $RESULT_FILE 2>&1
    		fi
      	else
    		VULN_RESULT="1"
           	#echo "(�н����� �ּұ��� ���� $MINLEN_FILE ������ �������� ����)"   >> $RESULT_FILE 2>&1
    		echo "$MINLEN_FILE ( File not found )"   >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi

exit 0
