#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0318"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

if [ `ps -ef | grep sendmail | grep -v "grep" | wc -l` -eq 0 ]
then
	:
else
    if [ -f /etc/mail/sendmail.cf ]
    then
        if [ `grep -v '^ *#' /etc/mail/sendmail.cf | grep "DZ8.13.4" | wc -l ` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    fi
    
    
    #13
    MAJOR_VERSION=`cat /etc/mail/sendmail.cf | grep "DZ" | awk -F. '{ print $2 }'`
    
    if [ $MAJOR_VERSION -gt "13" ]
    then
        CHKFLAG="YES"
    else
        #4
        MINOR_VERSION=`cat /etc/mail/sendmail.cf | grep "DZ" | awk -F. '{ print $3 }'`
        if [ $MINOR_VERSION -lt "5" ]
        then
            CHKFLAG="NO"
        else
            CHKFLAG="YES"
        fi
    fi
fi

if [ $CHKFLAG = "NO" ]
then
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    #echo "�Ϲݻ������ Sendmail ���� ���� ���� ���"  >> $RESULT_FILE 2>&1
    
    if [ `ps -ef | grep sendmail | grep -v "grep" | wc -l` -eq 0 ]
    then
    	:
    else
        if [ -f /etc/mail/sendmail.cf ]
        then
            #if [ `grep -v '^ *#' /etc/mail/sendmail.cf | grep "DZ8.13.4" | wc -l ` -eq 1 ]
            #then
            #    VULN_RESULT="0"
            #    #echo "Sendmail version (DZ8.13.4)" >>  $RESULT_FILE 2>&1
            #else
            #    echo "/etc/mail/sendmail.cf " >>  $RESULT_FILE 2>&1
            #    echo "(" >>  $RESULT_FILE 2>&1
            #    cat /etc/mail/sendmail.cf | grep "DZ" | awk '{ print "    " $0 }' >>  $RESULT_FILE 2>&1
            #    echo ")" >>  $RESULT_FILE 2>&1
            #fi
            
            #13
            MAJOR_VERSION=`cat /etc/mail/sendmail.cf | grep "DZ" | awk -F. '{ print $2 }'`
            if [ $MAJOR_VERSION -lt "14" ]
            then
                VULN_RESULT="1"
                
                echo "/etc/mail/sendmail.cf " >>  $RESULT_FILE 2>&1
                echo "(" >>  $RESULT_FILE 2>&1
                cat /etc/mail/sendmail.cf | grep "DZ" | awk '{ print "    " $0 }' >>  $RESULT_FILE 2>&1
                echo ")" >>  $RESULT_FILE 2>&1
            else
                #4
                MINOR_VERSION=`cat /etc/mail/sendmail.cf | grep "DZ" | awk -F. '{ print $3 }'`
                if [ $MINOR_VERSION -lt "5" ]
                then
                    VULN_RESULT="1"
                    
                    echo "/etc/mail/sendmail.cf " >>  $RESULT_FILE 2>&1
                    echo "(" >>  $RESULT_FILE 2>&1
                    cat /etc/mail/sendmail.cf | grep "DZ" | awk '{ print "    " $0 }' >>  $RESULT_FILE 2>&1
                    echo ")" >>  $RESULT_FILE 2>&1
                fi
            fi
    
        else
            echo "/etc/mail/sendmail.cf ( File Not Found )" >>  $RESULT_FILE 2>&1
            VULN_RESULT="3"
        fi
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:	
fi

