# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : NFS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0302"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"
SERVICE="nfsd"

OS=`uname -s`

if [ $OS = "AIX" ]
then
    #if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    #then
    #	:
    #else
        if [ -f /etc/exports ]
        then
            if [ `cat /etc/exports | grep everyone | grep -v "#" | wc -l` -eq 0 ]
            then
                :
            else
                CHKFLAG="NO"
                VULN_RESULT="1"
    			echo "  <RESULT>" >> $RESULT_FILE 2>&1
    			echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    			echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    			echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    			echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    			
    			#echo "NFS ���� �������̸� everyone ����Ʈ ���Ǿ� ����, Ȯ�� ����  (" >> $RESULT_FILE 2>&1
    			echo "    <CONTENT> " >> $RESULT_FILE 2>&1
				echo "/etc/exports " >> $RESULT_FILE 2>&1
    			echo "( " >> $RESULT_FILE 2>&1
    			cat /etc/exports | grep everyone | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
    			echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    			
    			echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    		    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    		    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1			
    			echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
                echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    			echo "  </RESULT>" >> $RESULT_FILE 2>&1
            fi
        fi
    #fi

elif [ $OS = "HP-UX" ]
then
    #if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    #then
    #	:
    #else
        if [ -f /etc/exports ]
        then
            if [ `cat /etc/exports | grep everyone | grep -v "#" | wc -l` -eq 0 ]
            then
                :
            else
                CHKFLAG="NO"
                VULN_RESULT="1"
    			echo "  <RESULT>" >> $RESULT_FILE 2>&1
    			echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    			echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    			echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    			echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	
	            #echo "NFS ���� �������̸� everyone ����Ʈ ���Ǿ� ����, Ȯ�� ����  (" >> $RESULT_FILE 2>&1
				echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    			echo "/etc/exports " >> $RESULT_FILE 2>&1
    			echo "( " >> $RESULT_FILE 2>&1
    			cat /etc/exports | grep everyone | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
    			echo ")" >> $RESULT_FILE 2>&1 
				echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    			
				echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    		    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    		    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1			
                echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
                echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    			echo "  </RESULT>" >> $RESULT_FILE 2>&1
            fi
        fi
    #fi

elif [ $OS = "Linux" ]
then

    #if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    #then
    #	:
    #else
        if [ -f /etc/exports ]
        then
            if [ `cat /etc/exports | grep everyone | grep -v "#" | wc -l` -eq 0 ]
            then
                :
            else
                CHKFLAG="NO"
                VULN_RESULT="1"
    			echo "  <RESULT>" >> $RESULT_FILE 2>&1
    			echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    			echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    			echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    			echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

				echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    			#echo "NFS ���� �������̸� everyone ����Ʈ ���Ǿ� ����, Ȯ�� ����  (" >> $RESULT_FILE 2>&1				
				echo "/etc/exports " >> $RESULT_FILE 2>&1
    			echo "( " >> $RESULT_FILE 2>&1
    			cat /etc/exports | grep everyone | grep -v "#" | awk '{ print "    " $0 }'  >> $RESULT_FILE 2>&1
                echo ") " >> $RESULT_FILE 2>&1
				echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    			
				echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    		    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    		    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1			
                echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
                echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    			echo "  </RESULT>" >> $RESULT_FILE 2>&1
            fi
        fi
    #fi
elif [ $OS = "SunOS" ]
then
    
    #if [ `ps -ef | egrep "nfsd" | egrep -v "grep|statdaemon|automountd" | grep -v "grep" | wc -l` -eq 0 ]
    #then
    #	:
    #else
        if [ -f /etc/dfs/dfstab ]
        then
            if [ `cat /etc/dfs/dfstab | grep everyone | grep -v "#" | wc -l` -eq 0 ]
            then
                :
            else
                CHKFLAG="NO"
                VULN_RESULT="1"
    			echo "  <RESULT>" >> $RESULT_FILE 2>&1
    			echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    			echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    			echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    			echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    			echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    			
				echo "    <CONTENT>" >> $RESULT_FILE 2>&1
				echo "/etc/dfs/dfstab " >> $RESULT_FILE 2>&1
				echo "( " >> $RESULT_FILE 2>&1
    			cat /etc/dfs/dfstab | grep everyone | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ") " >> $RESULT_FILE 2>&1
    			echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    			
    			echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    		    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    		    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1			
    		    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
                echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	        echo "  </RESULT>" >> $RESULT_FILE 2>&1
            fi
        fi
    #fi

fi


# NFS (Nework File System) : �������� �ٸ� ��ǻ���� ���丮�� �׼����ϴ� �� ����.
#
# NFS ���� ��ġ
# sudo apt-get install nfs-common nfs-kernel-server
#
# NFS �������� �ϱ� ���� ������ �����Ѵ�.
# vim /etc/exports
#
# ������ 192.168.0.243
# /common 192.168.0.243(rw,no_root_squash,no_all_squash)
#
# nfs ���� �ٽ� ����
#
## sudo /etc/init.d/nfs-kernel-server restart
## service portmap restart
#
# nfs �������� ����Ʈ
# # mount -t nfs -o nolock 192.168.0.204:/home/common /home/sora
#
# nfs ������ nfs ����Ȯ��
# # showmount -e localhost
#
# jlpark@sora:~$ showmount -e localhost
# Export list for localhost:
# /home/ajtmj/work/rootfs_nfs *
# /common                     (everyone)     --> ���
# /home/ftp                   192.168.0.181
# /home/ajtmj                 192.168.0.254



