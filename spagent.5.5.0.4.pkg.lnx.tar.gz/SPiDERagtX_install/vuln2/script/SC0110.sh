# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : �н����� �ִ� ��� �Ⱓ ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0110"
VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"


OS=`uname -s`
if [ $OS = "AIX" ]
then
    PASSWORD_MAX_DAYS_FILE="/etc/security/user"
    
    if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    then
        :
    else
    	CHKFLAG="NO"
    fi
    
    if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk  '{print $3}'| wc -l ` -eq 0 ]
    then
    	CHKFLAG="NO"
    else
        # 9�� �̻� �̸� ���
       	if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk '{print $3}'` -gt 9 ]
    	then
    		CHKFLAG="NO"
        fi
        
        # 0���̸� ���
        if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk '{print $3}'` -eq 0 ]
    	then
    		CHKFLAG="NO"
        fi
    fi
        
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
    	echo "    <CONTENT> " >> $RESULT_FILE 2>&1
		
    	#echo "�н����� �ִ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    	then
    		VULN_RESULT="1" 
    		if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk  '{print $3}'| wc -l ` -eq 0 ]
            then
                echo "$PASSWORD_MAX_DAYS_FILE (not setting)" >> $RESULT_FILE 2>&1
            else
                if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk  '{print $3}'` -gt 9 ]
                then 
    		        #echo "(������ �ִ���Ⱓ:" `cat /etc/security/user | grep -i "maxage"|grep -v "*" | awk  '{print $3}'` "��)" >> $RESULT_FILE 2>&1
      		        echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Weeks :" `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk  '{print $3}'` ")" >> $RESULT_FILE 2>&1
      		    fi
      		    
      		    if [ `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE | grep -v "*" | awk '{print $3}'` -eq 0 ]
            	then
            		echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Weeks :" `grep -i "maxage" $PASSWORD_MAX_DAYS_FILE |grep -v "*" | awk  '{print $3}'` ")" >> $RESULT_FILE 2>&1
                fi
      		fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ִ� ���ð� ���� $PASSWORD_MAX_DAYS_FILE ������ �������� ����)" >> $RESULT_FILE 2>&1
    		echo "$PASSWORD_MAX_DAYS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "HP-UX" ]
then
    
    PASSWORD_MAX_DAYS_FILE="/etc/default/security"
    
    if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    then
    	if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk  '{print $2}' | wc -l ` -eq 0 ]
      	then
    		CHKFLAG="NO"
      	else
      	    if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk '{print $2}'` -eq 0 ]
    		then
    		    CHKFLAG="NO"
    		elif [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk '{print $2}'` -gt 60 ]
    		then
    			CHKFLAG="NO"
        	fi
    	fi
    else
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    	#echo "�н����� �ִ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk '{print $2}'| wc -l` -eq 0 ]
      	    then
      	        # $PASSWORD_MAX_DAYS_FILE �� PASS_MAX_DAYS �̶�� ���ڿ��� ���� ���
      	        # ��, ���� �ȵǾ� ���� ���
      	        echo "$PASSWORD_MAX_DAYS_FILE (not setting)" >> $RESULT_FILE 2>&1
      	    else
      	        # $PASSWORD_MAX_DAYS_FILE �� PASS_MAX_DAYS �̶�� ���ڿ��� ���� ���
      	        # ����ϰ� ���� �Ǿ� �ִ� ��� 
      	        
      	        if [ `grep -i "PASS_MAX_DAYS" "$PASSWORD_MAX_DAYS_FILE" | grep -v "#" | awk '{print $2}'` -eq 0 ]
    		    then
    		        echo " $PASSWORD_MAX_DAYS_FILE ( Password Max Days :" `cat /etc/default/security | grep -i 'PASS_MAX_DAYS' | grep -v '#' | awk  '{print $2}'` " )" >> $RESULT_FILE 2>&1
      	        elif [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk '{print $2}'` -gt 60 ]
      	        then
    		        #echo "(������ �ִ���Ⱓ:" `cat /etc/default/security | grep -i "PASS_MAX_DAYS"|grep -v "#" | awk  '{print $2}'` "��)" >> $RESULT_FILE 2>&1
      		        
      		        echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Days :" `grep -i "PASS_MAX_DAYS" /etc/default/security |grep -v "#" | awk  '{print $2}'` " )" >> $RESULT_FILE 2>&1
      		    
      		    fi
      		fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ִ� ���ð� ���� /etc/login.defs ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found (/etc/default/security)" >> $RESULT_FILE 2>&1
    		echo "$PASSWORD_MAX_DAYS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
elif [ $OS = "Linux" ]
then
    
    PASSWORD_MAX_DAYS_FILE="/etc/login.defs"
    
    if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    then
        if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk  '{print $2}'| wc -l ` -eq 0 ]
        then
        	CHKFLAG="NO"
        else
        	if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk '{print $2}'` -gt 60 ]
        	then
        		CHKFLAG="NO"
            fi
        fi
    else
        CHKFLAG="NO"
    fi
       
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		
    	#echo "�н����� �ִ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    	then
    	    VULN_RESULT="1" 
    	    if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE | grep -v "#" | awk  '{print $2}'| wc -l ` -eq 0 ]
            then
    		    echo "$PASSWORD_MAX_DAYS_FILE (not setting)" >> $RESULT_FILE 2>&1
    		else
    		    if [ `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE |grep -v "#" | awk  '{print $2}'` -gt 60 ]
    		    then
    		        #echo "(������ �ִ���Ⱓ:" `cat /etc/login.defs | grep -i "PASS_MAX_DAYS"|grep -v "#" | awk  '{print $2}'` "��)" >> $RESULT_FILE 2>&1
      		        echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Days : " `grep -i "PASS_MAX_DAYS" $PASSWORD_MAX_DAYS_FILE |grep -v "#" | awk  '{print $2}'` ")" >> $RESULT_FILE 2>&1
      		        
      		    fi
      		fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ִ� ���ð� ���� $PASSWORD_MAX_DAYS_FILE ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found ($PASSWORD_MAX_DAYS_FILE)" >> $RESULT_FILE 2>&1
    		echo "$PASSWORD_MAX_DAYS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
elif [ $OS = "SunOS" ]
then
    CHKFLAG="YES"
    
    PASSWORD_MAX_DAYS_FILE="/etc/default/passwd"
    
    if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    then
    	if [ `grep  'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | grep -v "#" | wc -l ` -eq 0 ]
      	then
    		CHKFLAG="NO"
      	else
      	    if [ `grep 'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | awk -F= '{print $2}'` -eq 0 ]
    		then
    		    CHKFLAG="NO"
    		elif [ `grep 'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | awk -F= '{print $2}'` -gt 9 ]
    		then
    			CHKFLAG="NO"
        	fi
    	fi
    else
    	CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		
    	#echo "�н����� �ִ� ���Ⱓ ���� ���"   >> $RESULT_FILE 2>&1
    
    	if [ -f "$PASSWORD_MAX_DAYS_FILE" ]
    	then
    		VULN_RESULT="1" 
    		
    		#/etc/default/passwd�� MAXWEEKS �������� ������
    		if [ `grep  'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | grep -v "#" | wc -l ` -eq 0 ]
    		then
    		    echo "$PASSWORD_MAX_DAYS_FILE (not setting)" >> $RESULT_FILE 2>&1
    		else
    		
    		    # /etc/default/passwd�� MAXWEEKS �������� �ִµ� �� �������� 0 �϶�
    		    if [ `grep 'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | awk -F= '{print $2}'` -eq 0 ]
    		    then
    		        CHKFLAG="NO"
    		        #echo "(������ �ִ���Ⱓ:" `cat /etc/default/passwd | grep 'MAXWEEKS.*[0-9]'| awk -F= '{print $2}'` "��)" >> $RESULT_FILE 2>&1
      		        echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Weeks : " `cat /etc/default/passwd | grep 'MAXWEEKS.*[0-9]'| awk -F= '{print $2}'` " )" >> $RESULT_FILE 2>&1
      		        
      		    elif [ `grep 'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | awk -F= '{print $2}'` -gt 9 ]
    		    then
    		        echo "$PASSWORD_MAX_DAYS_FILE ( Password Max Weeks : " `grep 'MAXWEEKS.*[0-9]' $PASSWORD_MAX_DAYS_FILE | awk -F= '{print $2}'` " )">> $RESULT_FILE 2>&1
    		        
    		    else
      		        exit   #�߻��Ҽ����»�Ȳ
      		    fi
      		fi
    	else
    		VULN_RESULT="1"
    		#echo "(�н����� �ִ� ���ð� ���� $PASSWORD_MAX_DAYS_FILE ������ �������� ����)" >> $RESULT_FILE 2>&1
    		#echo "file not found ($PASSWORD_MAX_DAYS_FILE)" >> $RESULT_FILE 2>&1
    		echo "$PASSWORD_MAX_DAYS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    	fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi
exit
