#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0317"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

if [ `ps -ef | grep sendmail | grep -v "grep" | wc -l` -eq 0 ]
then
	:
else
    if [ -f /etc/mail/sendmail.cf ]
    then
        if [ `cat /etc/mail/sendmail.cf | grep -i "O PrivacyOptions" | grep -i "restrictqrun" | grep -v "#" |wc -l ` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
fi


if [ $CHKFLAG = "NO" ]
then
	VULN_RESULT="1"
	echo "  <RESULT>" >> $RESULT_FILE 2>&1
	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    #echo "�Ϲݻ������ Sendmail ���� ���� ���� ���"  >> $RESULT_FILE 2>&1

    if [ `ps -ef | grep sendmail | grep -v "grep" | wc -l` -eq 0 ]
    then
    	:
    else
        if [ -f /etc/mail/sendmail.cf ]
        then
            if [ `cat /etc/mail/sendmail.cf | grep -i "O PrivacyOptions" | grep -i "restrictqrun" | grep -v "#" |wc -l ` -eq 1 ]
            then
    			:
            else
                #echo "Sendmail �������̸� �Ϲݻ���� ���డ�� (" >> $RESULT_FILE 2>&1
                echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1	
                echo "(" >> $RESULT_FILE 2>&1	
                grep -v '^ *#' /etc/mail/sendmail.cf | grep PrivacyOptions | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
            fi
        else
        	#VULN_RESULT="3"
        	echo "/etc/mail/sendmail.cf ( File Not Found )" >>  $RESULT_FILE 2>&1
        fi
    fi

	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:	
fi

