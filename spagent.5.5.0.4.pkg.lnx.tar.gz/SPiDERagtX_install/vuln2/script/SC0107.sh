# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : shadow ���� ���� ����


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0107"
VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"



OS=`uname -s`
if [ $OS = "AIX" ]
then

    SHADOW_FILE="/etc/security/passwd"
    
    if [ -f "$SHADOW_FILE" ]
    then
        # 400 
    	if [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-r--------' | wc -l` -eq 1 ]
        then
            # ��ȣ 
        	if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        # 600
        elif [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-rw-------' | wc -l` -eq 1 ]
        then
            # ��ȣ
            if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        else
            
        	CHKFLAG="NO"
        fi
    else
    	CHKFLAG="NO"
    fi 
    
    if [ $CHKFLAG = "NO" ]
    then
        
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1	
        
        if [ -f "$SHADOW_FILE" ]
        then
            VULN_RESULT="1"
            
           	#echo "$SHADOW_FILE ���� ���� ���� ���"   >> $RESULT_FILE 2>&1
        	#echo "(������ ������ ����:" `ls -alL $SHADOW_FILE | awk '{print $1}'` " ������:" `ls -alL $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        	echo "$SHADOW_FILE ( Permission:" `ls -al $SHADOW_FILE | awk '{print $1}'` "Owner:" `ls -al $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        else
            VULN_RESULT="1"
            echo "$SHADOW_FILE ( File not found ) " >> $RESULT_FILE 2>&1
        fi
    	echo "    </CONTENT> " >> $RESULT_FILE 2>&1
    	
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    	
    else
    	:	
    fi
    
elif [ $OS = "HP-UX" ]
then
    
    # HP-UX �� ��� 11.23 ���� �������� /etc/shadow ������ �����ϳ�
    # ���� ������ ���� /etc/passwd ���ϸ� ���� �Ͽ���
    # ���� /etc/shadow ������ ������ ����� �˻� �ϰ� 
    # ������ ���Ѵ�
    
    SHADOW_FILE="/etc/shadow"
    
    if [ -f "$SHADOW_FILE" ]
    then
    	
    	# 400 
    	if [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-r--------' | wc -l` -eq 1 ]
        then
        	if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        # 600
        elif [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-rw-------' | wc -l` -eq 1 ]
        then
            if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        else
        	CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
    	
    if [ $CHKFLAG = "NO" ]
    then
		
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		
		#/etc/shadow
		if [ -f "$SHADOW_FILE" ]
        then
            VULN_RESULT="1"
            
    		#echo "$SHADOW_FILE ���� ���� ���� ���"   >> $RESULT_FILE 2>&1
    		#echo "(������ ������ ����:" `ls -alL $SHADOW_FILE | awk '{print $1}'` " ������:" `ls -alL $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
    		#echo "$SHADOW_FILE ( Permission:" `ls -alL $SHADOW_FILE | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
    		echo "$SHADOW_FILE ( Permission:" `ls -al $SHADOW_FILE | awk '{print $1}'` "Owner:" `ls -al $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        else
            VULN_RESULT="0"
            echo "$SHADOW_FILE ( File not found )" >> $RESULT_FILE 2>&1
        fi
        
        #/tcb/files/auth/r/root
        if [ -f "$SHADOW_FILE2" ]
        then
            VULN_RESULT="1"
    		#echo "$SHADOW_FILE2 ( Permission:" `ls -alL $SHADOW_FILE2 | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
    		echo "$SHADOW_FILE2 ( Permission:" `ls -al $SHADOW_FILE | awk '{print $1}'` "Owner:" `ls -al $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        fi

		echo "    </CONTENT> " >> $RESULT_FILE 2>&1
		
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
	    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	    echo "  </RESULT>" >> $RESULT_FILE 2>&1
    	    
    fi
    
elif [ $OS = "Linux" ]
then
    SHADOW_FILE="/etc/shadow"
    
    if [ -f "$SHADOW_FILE" ]
    then
    	# 400 
    	if [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-r--------' | wc -l` -eq 1 ]
        then
        	if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        # 600
        elif [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-rw-------' | wc -l` -eq 1 ]
        then
            if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        else
        	CHKFLAG="NO"
        fi
    else
    	CHKFLAG="NO"
    fi 
    
    if [ $CHKFLAG = "NO" ]
    then
        
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
		echo "    <CONTENT> " >> $RESULT_FILE 2>&1
		
		if [ -f "$SHADOW_FILE" ]
        then
            VULN_RESULT="1"
           	#echo "shadow ���� ���� ���� ���"   >> $RESULT_FILE 2>&1
        	#echo "(������ ������ ����:" `ls -alL /etc/shadow | awk '{print $1}'` " ������:" `ls -alL /etc/shadow | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        	#echo "$SHADOW_FILE (Permission:" `ls -alL $SHADOW_FILE | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
        	echo "$SHADOW_FILE ( Permission:" `ls -al $SHADOW_FILE | awk '{print $1}'` "Owner:" `ls -al $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        else
            VULN_RESULT="1"
            echo "$SHADOW_FILE ( File not found )" >> $RESULT_FILE 2>&1
        fi
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
elif [ $OS = "SunOS" ]
then
    SHADOW_FILE="/etc/shadow"
    
    if [ -f "$SHADOW_FILE" ]
    then
    	# 400 
    	if [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-r--------' | wc -l` -eq 1 ]
        then
        	if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        # 600
        elif [ `ls -al $SHADOW_FILE | awk {'print $1'} | grep '^-rw-------' | wc -l` -eq 1 ]
        then
            if [ `ls -al $SHADOW_FILE | awk {'print $3'} | grep 'root' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        else
        	CHKFLAG="NO"
        fi
    else
    	CHKFLAG="NO"
    fi 
    
    if [ $CHKFLAG = "NO" ]
    then
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1	
        
        if [ -f "$SHADOW_FILE" ]
        then
            VULN_RESULT="1"
           	#echo "$SHADOW_FILE ���� ���� ���� ���"   >> $RESULT_FILE 2>&1
        	#echo "(������ ������ ����:" `ls -alL $SHADOW_FILE | awk '{print $1}'` " ������:" `ls -alL $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        	#echo "$SHADOW_FILE ( Permission:" `ls -alL $SHADOW_FILE | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
        	echo "$SHADOW_FILE ( Permission:" `ls -al $SHADOW_FILE | awk '{print $1}'` "Owner:" `ls -al $SHADOW_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
        else
            VULN_RESULT="1"
            echo "$SHADOW_FILE ( File not found )" >> $RESULT_FILE 2>&1
        fi
        
        echo "    </CONTENT> " >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi

exit
