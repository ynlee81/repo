# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : .rhosts ���� ���� ����

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0309"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u`
FILES="/.rhosts"

for dir in $HOMEDIRS
do
    for file in $FILES
    do
        if [ -f "$dir$file" ]
        then
            if [ `ls -alL $dir$file | awk '{print $1}' | egrep '^-rw-------|^-r--------' | wc -l ` -eq 1 ]
            then
                :
            else
                CHKFLAG="NO"
            fi
        fi
    done
done


if [ $CHKFLAG = "NO" ]
then
    VULN_RESULT="1"
	echo "  <RESULT>" >> $RESULT_FILE 2>&1
	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	echo "    <CONTENT>" >> $RESULT_FILE 2>&1

    HOMEDIRS=`cat /etc/passwd | awk -F":" 'length($6) > 0 {print $6}' | sort -u `
    FILES="/.rhosts"
    
    for dir in $HOMEDIRS
    do
        for file in $FILES
        do
            if [ -f "$dir$file" ]
            then
                if [ $dir = '/' ]
                then
                    if [ `ls -alL $file | awk {'print $1'} | egrep '^-rw-------|^-r--------' | wc -l ` -eq 1 ]
                    then
                        :
                    else
                        #echo ".rhosts ���� ���� ���� ���, ���ϱ��� Ȯ�ο��� (" $dir$file  >> $RESULT_FILE 2>&1
        				echo "$file ( Permission:" `ls -alL $file | awk '{print $1}'` ")" >>  $RESULT_FILE 2>&1
                    fi
                else
                    if [ `ls -alL $dir$file | awk {'print $1'} | egrep '^-rw-------|^-r--------' | wc -l ` -eq 1 ]
                    then
                        :
                    else
        				echo "$dir$file ( Permission:" `ls -alL $dir$file | awk '{print $1}'` ")" >>  $RESULT_FILE 2>&1
                    fi
                fi
            else
                :
            fi
        done
    done

	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

