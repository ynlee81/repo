# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : 'r' commands ����

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0307"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

if [ -d /etc/xinetd.d ]
then
    SERVICE_INETD="rsh|rlogin|rexec"
    
    if [ `ls -aIL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
    then
        for VVV in `ls -aIL /etc/xinetd.d | egrep $SERVICE_INETD`
        do
            if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                CHKFLAG="NO"
            fi
        done
    fi
elif [ -f /etc/inetd.conf ]
then
    SERVICE_INETD="shell|login|exec"
    
    if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD | grep -v "grep" |wc -l` -eq 0 ]
    then
        :
    else
        CHKFLAG="NO"
    fi
fi

if [ $CHKFLAG = "NO" ]
then
	echo "  <RESULT>" >> $RESULT_FILE 2>&1
	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1

    if [ -d /etc/xinetd.d ]
    then
        
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
		#echo "/etc/xinetd.d (" >> $RESULT_FILE 2>&1
        
        SERVICE_INETD="rsh|rlogin|rexec"
        
        if [ `ls -aIL /etc/xinetd.d | egrep $SERVICE_INETD | wc -l` -gt 0 ]
        then
    		for VVV in `ls -aIL /etc/xinetd.d | egrep $SERVICE_INETD`
            do
                if [ `cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
                then
                    #echo "��r�� commands ���� : " $VVV "���� ���, ���񽺸� disable ��Ű�ñ� �ٶ��ϴ�" >> $RESULT_FILE 2>&1
                    
                    echo $VVV >> $RESULT_FILE 2>&1
                    echo "( " >> $RESULT_FILE 2>&1
                    cat /etc/xinetd.d/$VVV | grep -i "disable" | grep -i "no" | awk '{ print "    " $1 }' >> $RESULT_FILE 2>&1
                    echo ") " >> $RESULT_FILE 2>&1
                else
    			    :
                fi
            done
        else
    		:
        fi
    elif [ -f /etc/inetd.conf ]
    then
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
		        
        SERVICE_INETD="shell|login|exec"
        if [ `cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD|grep -v "grep" |wc -l` -eq 0 ]
        then
    		:
        else
            #echo "��r�� commands ���� : ���, �Ʒ��� ���� ���ſ���" >> $RESULT_FILE 2>&1
            
            echo "/etc/inetd.conf " >> $RESULT_FILE 2>&1
		    echo "( " >> $RESULT_FILE 2>&1
            cat /etc/inetd.conf | grep -v '^ *#' | egrep $SERVICE_INETD  | awk '{ print "    " $1 " " $3 }' >> $RESULT_FILE 2>&1
            echo ") " >> $RESULT_FILE 2>&1
        fi
    else
    	:
    fi

    VULN_RESULT="1"
    
	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
	
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:
fi

