# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : root ���� ���� ���� ���� ���� ����


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0211"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

OS=`uname -s`
if [ $OS = "AIX" ]
then
    if [ -f /etc/security/user ]
    then
        if [ `ls -alL /etc/security/user | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
        then
    		echo "  <RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    		#echo "root ���� �������� ���� ���� ���� ��� (" >> $RESULT_FILE 2>&1
            echo "/etc/security/user ( Permission:" `ls -alL /etc/security/user | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
            #echo ")" >> $RESULT_FILE 2>&1
    		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    		echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi
elif [ $OS = "HP-UX" ]
then
    
    if [ -f /etc/securetty ]
    then
        if [ `ls -alL /etc/securetty | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
        then
    		echo "  <RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    		#echo "root ���� �������� ���� ���� ���� ��� (" >> $RESULT_FILE 2>&1
            echo "/etc/securetty ( Permission:" `ls -alL /etc/securetty | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
            #echo ")" >> $RESULT_FILE 2>&1
    		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    	    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	    echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi
elif [ $OS = "Linux" ]
then

    if [ -f /etc/pam.d/login ]
    then
        if [ `ls -alL /etc/pam.d/login | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
        then
    		echo "  <RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    		#echo "root ���� �������� ���� ���� ���� ��� (" >> $RESULT_FILE 2>&1
            echo "/etc/pam.d/login ( Permission:" `ls -alL /etc/pam.d/login | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
            #echo ")" >> $RESULT_FILE 2>&1
    		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
            echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    		echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi
elif [ $OS = "SunOS" ]
then

    if [ -f /etc/default/login ]
    then
        if [ `ls -alL /etc/default/login | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
        then
    		echo "  <RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    		#echo "root ���� �������� ���� ���� ���� ��� (" >> $RESULT_FILE 2>&1
            echo "/etc/default/login ( Permission: " `ls -alL /etc/default/login | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
            #echo ")" >> $RESULT_FILE 2>&1
    		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    	    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	    echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi
fi

