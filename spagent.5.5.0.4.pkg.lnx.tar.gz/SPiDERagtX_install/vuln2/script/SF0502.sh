# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ������ PUT �޼ҵ� ��� ���� ����

# ��� OS ���� 

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SF0502"

VULN_RESULT="0"

EXISTS=0

PWD=`pwd`


if [ -f "$PWD/vuln2/script/XFIND_RESULT" ]
then
	:
else
	exit
fi

XFIND_RESULT_FILE=`ls $PWD/vuln2/script/XFIND_RESULT`;
#echo $XFIND_RESULT_FILE

CHKFLAG="YES"

while read line ;
do
	if [ `grep "LimitExcept" $line | grep -v "^#" | grep "PUT" | wc -l` -eq 0 ]
	then
		:
	else
        CHKFLAG="NO"
	fi
	
done < $XFIND_RESULT_FILE

if [ $CHKFLAG = "NO" ]
then
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
           	
	echo "    <CONTENT> " >> $RESULT_FILE 2>&1
	
	while read line ;
	do
	    if [ `ls $line | grep "httpd.conf" | wc -l` -gt 0 ]
	    then
    		if [ `grep LimitExcept $line |  grep -v "^#" | grep "PUT" | wc -l` -eq 0 ]
    		then
    			:
    		else
            	VULN_RESULT="1"
                        
    			echo "$line " >> $RESULT_FILE 2>&1
    			echo "( " >> $RESULT_FILE 2>&1
            	grep LimitExcept $line | grep -v "^#" | grep "PUT" >> $RESULT_FILE 2>&1
    			echo ") " >> $RESULT_FILE 2>&1
    			echo " " >> $RESULT_FILE 2>&1
            	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    		fi
    	fi
    	
	done < $XFIND_RESULT_FILE  
	
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

#
#APACHE_HTTPD_CONF_LIST=`find /$ff -name "httpd.conf"`
#    #echo "apache :" $APACHE_HTTPD_CONF_LIST
#    
#    for httpd in $APACHE_HTTPD_CONF_LIST
#    do
#        #echo "httpd : $httpd"
#        
#        if [ -r $httpd ]
#        then
#            if [ `grep LimitExcept $httpd | grep -v "^#" | grep "PUT" | wc -l` -eq 0 ]
#            then
#                :
#            else
#                VULN_RESULT="1"
#                    
#               echo "  <RESULT>" >> $RESULT_FILE 2>&1
#              	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
#               	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
#               	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
#               	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
#              	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
#               	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
#               	#echo "    <CONTENT> PUT Method is being used" >> $RESULT_FILE 2>&1
#                #cat $APACHE_HTTPD_CONF_LIST | grep -v "^#" | grep LimitExcept | grep "PUT" >> $RESULT_FILE 2>&1
#                #grep LimitExcept $APACHE_HTTPD_CONF_LIST | grep -v "^#" | grep "PUT" >> $RESULT_FILE 2>&1
#                grep LimitExcept $httpd | grep -v "^#" | grep "PUT" >> $RESULT_FILE 2>&1
#                                
#                echo "    </CONTENT>" >> $RESULT_FILE 2>&1
#                echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
#                echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
#                echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
#                echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
#              	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
#                echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
#                echo "  </RESULT>" >> $RESULT_FILE 2>&1
#            fi
#        fi
#   done
#



