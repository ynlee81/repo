#!/bin/sh
# $SPXAGT_DIR/assess/systemscript/S?????.sh ip id result_filename

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3

# RUN_XFIND : xfind ���� ���� 
# 1 : run
# 0 : not run
RUN_XFIND=$4
if [ $RUN_XFIND = "1" ]
then
PWD=`pwd`
`$PWD/util/xfind "/" "httpd.conf|*.php|*.jsp" "1000" > $PWD/vuln2/script/XFIND_RESULT`
fi

CODENAME="S00001"
echo "<?xml version=\"1.0\" encoding=\"euc-kr\"?>" > $RESULT_FILE 2>&1
#echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" > $RESULT_FILE 2>&1
echo "<!--`date '+%Y/%m/%d %H:%M:%S'` -->" >> $RESULT_FILE 2>&1
echo "<RESULTS>" >> $RESULT_FILE 2>&1

