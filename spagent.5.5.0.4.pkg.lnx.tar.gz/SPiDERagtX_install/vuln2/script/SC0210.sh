# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : ftp ����� ���� ���� ����


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0210"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

OS=`uname -s`
if [ $OS = "AIX" ]
then
    
    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    CHKFLAG="NO"
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                fi
            fi
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                done
            fi
        done
    fi
    
    if [ $CHKFLAG = "YES" ]
    then
    	exit
    else
    	:
    fi
    
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    if [ -f "/etc/inetd.conf" ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f "/etc/ftpd/ftpusers" ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    #echo "ftp������������ ���Ѽ��� ���(" >> $RESULT_FILE 2>&1
                    #echo "/etc/ftpd/ftpusers ( Permission:" `ls -alL /etc/ftpd/ftpusers | awk '{print $1}'` " )" >> $RESULT_FILE 2>&1
                    ls -alL /etc/ftpd/ftpusers | awk {'print $9 " ( Permission : " $1 " Owner : " $3 " )" '}  >> $RESULT_FILE 2>&1
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        #echo "/etc/ftpusers ( Permission:" `ls -alL /etc/ftpusers | awk '{print $1}'` " )" >> $RESULT_FILE 2>&1 
                        ls -alL /etc/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                else
                    :
                fi
            fi
        else
            :
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        echo "$VV ( Permission:" `ls -alL $VV | awk '{print $1}'` " )" >>$RESULT_FILE 2>&1
                        ls -alL $VV | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                done
    
            fi
        done
    else
        :
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    VULN_RESULT="1"
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

elif [ $OS = "HP-UX" ]
then
    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    CHKFLAG="NO"
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                fi
            fi
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                done
            fi
        done
    fi
    
    if [ $CHKFLAG = "YES" ]
    then
    	exit
    else
    	:
    fi
    
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    #echo "ftp������������ ���Ѽ��� ���(" >> $RESULT_FILE 2>&1
                    #echo "/etc/ftpd/ftpusers ( Permission:" `ls -alL /etc/ftpd/ftpusers | awk '{print $1}'` " )" >> $RESULT_FILE 2>&1
                    ls -alL /etc/ftpd/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        #echo "/etc/ftpusers ( Permission:" `ls -alL /etc/ftpusers | awk '{print $1}'` " )" >> $RESULT_FILE 2>&1 
                        ls -alL /etc/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                else
                    :
                fi
            fi
        else
            :
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        #echo "$VV ( Permission:" `ls -alL $VV | awk '{print $1}'` " )" >>$RESULT_FILE 2>&1
                        ls -alL $VV | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                done
    
            fi
        done
    else
        :
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    VULN_RESULT="1"
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

elif [ $OS = "Linux" ]
then
    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    CHKFLAG="NO"
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                fi
            fi
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                done
            fi
        done
    fi
    
    #/etc/vsftpd.ftpusers, 
    if [ -f "/etc/vsftpd.ftpusers" ]
    then
        # rw-r--r--, r--r--r--
        if [ `ls -al /etc/vsftpd.ftpusers | egrep '^-rw-r--r--|^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] 
        then
        #|| [ `ls -al /etc/vsftpd.ftpusers | grep '^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] ; then
            CHKFLAG="NO"
        fi
    fi
    
    #/etc/vsftpd.user_list
    if [ -f "/etc/vsftpd.user_list" ]
    then
        # rw-r--r--, r--r--r--
        if [ `ls -al /etc/vsftpd.user_list | egrep '^-rw-r--r--|^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] 
        then
        #|| [ `ls -al /etc/vsftpd.user_list | grep '^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] ; then
            CHKFLAG="NO"
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        
        if [ -f /etc/inetd.conf ]
        then
            if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
            then
                if [ -f /etc/ftpd/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ���(" >> $RESULT_FILE 2>&1
                        #echo "/etc/ftpd/ftpusers ( Permission:" `ls -alL /etc/ftpd/ftpusers | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                        ls -alL /etc/ftpd/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                else
                    if [ -f /etc/ftpusers ]
                    then
                        if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                        then
                            #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                            echo "/etc/ftpusers ( Permission:" `ls -alL /etc/ftpusers | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1 
                            ls -alL /etc/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                        fi
                    else
                        :
                    fi
                fi
            else
                :
            fi
        elif [ -f /etc/xinetd.conf ]
        then
            for V in `ls /etc/xinetd.d/* | grep ftp`
            do
                if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
                then
                    for VV in `ls /etc/*ftpusers*`
                    do
                        if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                        then
                            #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                            #echo "$VV ( Permission:" `ls -alL $VV | awk '{print $1}'` ")" >>$RESULT_FILE 2>&1
                            ls -alL $VV | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                        fi
                    done
        
                fi
            done
        else
            :
        fi
        
        
        #/etc/vsftpd.ftpusers, 
        if [ -f "/etc/vsftpd.ftpusers" ]
        then
            # rw-r--r--, rw-------
            if [ `ls -al /etc/vsftpd.ftpusers | egrep '^-rw-r--r--|^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] 
            then
                #|| [ `ls -al /etc/vsftpd.ftpusers | awk {'print $1 " " $3 '} | grep '^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] ; then
                #echo "/etc/vsftpd.ftpusers ( Permission:" `ls -alL /etc/vsftpd.ftpusers | awk '{print $1}'` ")" >>$RESULT_FILE 2>&1
                ls -alL /etc/vsftpd.ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
            fi
        fi
        
        #/etc/vsftpd.user_list
        if [ -f "/etc/vsftpd.user_list" ]
        then
            # rw-r--r--, rw-------
            if [ `ls -al /etc/vsftpd.user_list | egrep '^-rw-r--r--|^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] 
            then
                #|| [ `ls -al /etc/vsftpd.user_list | awk {'print $1 " " $3 '} | grep '^-rw-------' | egrep "root|bin" | wc -l` -eq 0 ] ; then
                #echo "/etc/vsftpd.user_list ( Permission:" `ls -alL /etc/vsftpd.user_list | awk '{print $1}'` ")" >>$RESULT_FILE 2>&1
                ls -alL /etc/vsftpd.user_list | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
            fi
        fi
        
        
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        VULN_RESULT="1"
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
    
elif [ $OS = "SunOS" ]
then

    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    CHKFLAG="NO"
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                fi
            fi
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        CHKFLAG="NO"
                    fi
                done
            fi
        done
    fi
    
    if [ $CHKFLAG = "YES" ]
    then
    	exit
    else
    	:
    fi
    
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    if [ -f /etc/inetd.conf ]
    then
        if [ `cat /etc/inetd.conf | grep ftp | grep -v "#" | wc -l` -gt 0 ]
        then
            if [ -f /etc/ftpd/ftpusers ]
            then
                if [ `ls -alL /etc/ftpd/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                then
                    #echo "ftp������������ ���Ѽ��� ���(" >> $RESULT_FILE 2>&1
                    #echo "/etc/ftpd/ftpusers (Permission:" `ls -alL /etc/ftpd/ftpusers | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                    ls -alL /etc/ftpd/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                fi
            else
                if [ -f /etc/ftpusers ]
                then
                    if [ `ls -alL /etc/ftpusers | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        #echo "/etc/ftpusers (Permission:" `ls -alL /etc/ftpusers | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1 
                        ls -alL /etc/ftpusers | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                else
                    :
                fi
            fi
        else
            :
        fi
    elif [ -f /etc/xinetd.conf ]
    then
        for V in `ls /etc/xinetd.d/* | grep ftp`
        do
            if [ `cat $V | grep -i "disable" | grep -i "no" | wc -l` -gt 0 ]
            then
                for VV in `ls /etc/*ftpusers*`
                do
                    if [ `ls -alL $VV | egrep '^-rw-r--r--|^-rw-------' | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 0 ]
                    then
                        #echo "ftp������������ ���Ѽ��� ��� (" >> $RESULT_FILE 2>&1
                        #echo "$VV (Permission:" `ls -alL $VV | awk '{print $1}'` ")" >>$RESULT_FILE 2>&1
                        ls -alL $VV | awk '{print $9 " ( Permission : " $1 " Owner : " $3 " )" }'  >> $RESULT_FILE 2>&1
                    fi
                done
    
            fi
        done
    else
        :
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    VULN_RESULT="1"
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

fi

exit 0

