# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : inetd.conf ���� ���� ����

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0202"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

if [ -f /etc/xinetd.conf ]
then
    if [ `ls -alL /etc/xinetd.conf | grep '........-.'| awk '{print $3}' | egrep "root|bin" | wc -l` -eq 1 ]
    then
        CHKFLAG="YES"
    else
        CHKFLAG="NO"
    fi
elif [ -f /etc/inetd.conf ]
then
    if [ `ls -alL /etc/inetd.conf | grep '........-.'| awk '{print $3}' | egrep "root|bin" | wc -l` -eq 1 ]
    then
        CHKFLAG="YES"
    else
        CHKFLAG="NO"
    fi
else
    CHKFLAG="YES"
fi

if [ $CHKFLAG = "NO" ]
then
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    #echo "���Ѽ��� ���"   >> $RESULT_FILE 2>&1
    
    if [ -f /etc/inetd.conf ]
    then
    	#echo "(inetd.conf ���ϱ��� " `ls -alL /etc/inetd.conf| awk '{print $1}'` "������:"`ls -alL /etc/inetd.conf| awk '{print $3}'` ")" >>  $RESULT_FILE 2>&1
        echo "inetd.conf ( Permission : " `ls -alL /etc/inetd.conf| awk '{print $1}'` " Owner : "`ls -alL /etc/inetd.conf| awk '{print $3}'` ")" >>  $RESULT_FILE 2>&1
    fi
    
    if [ -f /etc/xinetd.conf ]
    then
        #echo "(xinetd.conf���� ���� " `ls -alL /etc/xinetd.conf| awk '{print $1}'` "������:"`ls -alL /etc/xinetd.conf| awk '{print $3}'` ")" >>  $RESULT_FILE 2>&1
        echo "xinetd.conf ( Permission : " `ls -alL /etc/xinetd.conf| awk '{print $1}'` "Owner :"`ls -alL /etc/xinetd.conf| awk '{print $3}'` ")" >>  $RESULT_FILE 2>&1
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1

else
    :	
fi



