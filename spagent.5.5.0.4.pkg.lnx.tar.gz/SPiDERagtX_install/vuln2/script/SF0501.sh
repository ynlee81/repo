# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : Webshell pattern Ž��

# ��� OS ���� 

#!/bin/sh
#

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SF0501"

VULN_RESULT="0"

JSP_WEBSHELL_PATTERN="request.getParameter|Runtime.getRuntime"
PHP_WEBSHELL_PATTERN="passthru|system|exec|shell"

PWD=`pwd`
#echo "SF0501 PWD=$PWD"

if [ -f "$PWD/vuln2/script/XFIND_RESULT" ]
then
	:
else
	exit
fi

CHKFLAG="YES"

XFIND_RESULT_FILE=`ls $PWD/vuln2/script/XFIND_RESULT`;

i="0"

while read line ; 
do

	# JSP WEBSHELL CHECK
	if [ `grep "jsp" $line | wc -l` -gt 0 ]
	then 
    	if [ `egrep "$JSP_WEBSHELL_PATTERN" $line | wc -l` -gt 0 ]
    	then
    		#echo "egrep $JSP_WEBSHELL_PATTERN $line"
    		CHKFLAG="NO"
    		i=`expr $i + 1`
    	fi
    fi

	# PHP WEBSHELL CHECK
	if [ `grep "php" $line | wc -l` -gt 0 ]
	then 
    	if [ `egrep $PHP_WEBSHELL_PATTERN $line | wc -l` -gt 0 ]
    	then
    		CHKFLAG="NO"
    		i=`expr $i + 1`
    	fi
    fi

done < $XFIND_RESULT_FILE

#echo "i=$i CHKFLAG=$CHKFLAG"

if [ $CHKFLAG = "NO" ] 
then
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    #echo "webshell pattern Ž��, Ȯ���� ���� ���("  >> $RESULT_FILE 2>&1
        
    if [ $i -gt "10" ]
    then
        echo "webshell pattern found ( $i File(s) Found )" >> $RESULT_FILE 2>&1 
    else
        echo "webshell pattern found " >> $RESULT_FILE 2>&1 
	    echo "(" >> $RESULT_FILE 2>&1
    	
    	while read line ; 
    	do
    		# JSP WEBSHELL CHECK
    		if [ `grep "jsp" $line | wc -l` -gt 0 ]
            then
        		if [ `egrep $JSP_WEBSHELL_PATTERN $line | wc -l` -gt 0 ]
        		then
        			echo "    $line"  >> $RESULT_FILE 2>&1    		    
        		fi
            fi
            
    		# PHP WEBSHELL CHECK
    		if [ `grep "php" $line | wc -l` -gt 0 ]
            then
        		if [ `egrep $PHP_WEBSHELL_PATTERN $line | wc -l` -gt 0 ]
        		then
        			echo "    $line"  >> $RESULT_FILE 2>&1
        		fi
            fi
            
    	done < $XFIND_RESULT_FILE
    	
        echo ")" >> $RESULT_FILE 2>&1
    fi
    
    VULN_RESULT="1"
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
    
fi


