#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0311"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`

if [ $OS = "AIX" ]
then
    if [ -f /etc/motd ] 
    then
        if [ `cat /etc/motd | grep -v '#' | grep "Version" | grep  "\." | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi

    if [ `dspcat -g /usr/lib/nls/msg/en_US/ftpd.cat | grep "%s FTP server (%s) ready." | wc -l` -gt 0 ]
    then
        CHKFLAG="NO"  
    fi
    
    if [ -f /etc/mail/sendmail.cf ] 
    then
        if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
		VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1

        if [ -f /etc/motd ]
        then
            if [ `cat /etc/motd | grep -v '#' | grep "Version" | grep  "\." | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                echo "/etc/motd " >> $RESULT_FILE 2>&1
                echo "(" >> $RESULT_FILE 2>&1
                    
                if [ `cat /etc/motd | wc -l` -gt 10 ]
                then
                    cat /etc/motd | grep -v '#' | grep "Version" | grep  "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                else
                    cat /etc/motd | grep -v '#' | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                fi
                
                echo ")" >> $RESULT_FILE 2>&1
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi

        if [ `dspcat -g /usr/lib/nls/msg/en_US/ftpd.cat | grep "%s FTP server (%s) ready." | wc -l` -gt 0 ]
        then
            VULN_RESULT="1"
            
            if [ `dspcat -g /usr/lib/nls/msg/en_US/ftpd.cat | grep "%s FTP server (%s) ready." | wc -l` -gt 10 ]
            then
                echo "/usr/lib/nls/msg/en_US/ftpd.cat" >> $RESULT_FILE 2>&1
            else
                echo "/usr/lib/nls/msg/en_US/ftpd.cat" >> $RESULT_FILE 2>&1
                echo "(" >> $RESULT_FILE 2>&1
                echo "    %s FTP server (%s) ready." >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
            fi
            echo " " >> $RESULT_FILE 2>&1
        fi

        if [ -f /etc/mail/sendmail.cf ]
        then
            if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 10 ]
                then
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                else
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/mail/sendmail.cf | grep -i "GreetingMessage"  | grep "v" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
            fi
        fi
        
		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "HP-UX" ]
then
    if [ -f /etc/issue ]
    then
        if [ `cat /etc/issue | grep "Release" | grep -v "#" | grep "\." | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f /etc/ftpd/ftpaccess ]
    then
        if [ `cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | grep -i "yes" | wc -l` -lt 2 ]
        then
            CHKFLAG="NO"  
        fi
    fi

    if [ -f /etc/mail/sendmail.cf ]
    then
        if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi

    if [ $CHKFLAG = "NO" ]
    then
		VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1

        if [ -f /etc/issue ]
        then
            if [ `cat /etc/issue | grep "Release" | grep -v "#" | grep "\." | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                echo "/etc/issue " >> $RESULT_FILE 2>&1
                echo "(" >> $RESULT_FILE 2>&1
                
                if [ `cat /etc/issue | wc -l` -gt 10 ]
                then
                    grep "Release" /etc/issue | grep -v "#" | grep "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                else
                    cat /etc/issue | grep "Release" | grep -v "#" | grep "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                fi
                
                echo ")" >> $RESULT_FILE 2>&1
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/ftpd/ftpaccess ]
        then
            if [ `cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | egrep -i "yes" | wc -l` -lt 2 ]
            then
                VULN_RESULT="1"
                
                echo "/etc/ftpd/ftpaccess " >> $RESULT_FILE 2>&1
                echo "(" >> $RESULT_FILE 2>&1
                cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/mail/sendmail.cf ]
        then
            if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 10 ]
                then
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                else
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
            fi
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "Linux" ]
then
    if [ -f "/etc/issue" ]
    then
        if [ `cat /etc/issue | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f "/etc/issue.net" ]
    then
        if [ `cat /etc/issue.net | wc -l` -gt 0 ] 
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f "/etc/welcome.msg" ]
    then
        if [ `cat /etc/welcome.msg | grep -i "banner" | grep "=" | grep "\".\"" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi 
    fi
    
    if [ -f "/etc/vsftpd.conf" ]
    then
        if [ `cat /etc/vsftpd.conf | grep -i "ftp_banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
        then 
            CHKFLAG="NO"  
        fi
    fi

    if [ -f "/etc/proftpd.conf" ]
    then
        if [ `cat /etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f "/usr/local/etc/proftpd.conf" ]
    then
        if [ `cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f "/etc/ftpaccess" ]
    then
        if [ `cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" | wc -l` -gt 0 ]
        then 
            CHKFLAG="NO"  
        fi 
    fi
    
    if [ -f "/etc/mail/sendmail.cf" ]
    then
        if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
		VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1

        if [ -f "/etc/issue" ] 
        then
            if [ `cat /etc/issue | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/issue | wc -l` -gt 10 ]
                then
                    echo "/etc/issue" >> $RESULT_FILE 2>&1
                else
                    echo "/etc/issue" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/issue | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/issue.net ] 
        then
            if [ `cat /etc/issue.net | wc -l` -gt 0 ] 
            then
                VULN_RESULT="1"
               
                if [ `cat /etc/issue.net | wc -l` -gt 10 ] 
                then
                    echo "/etc/issue.net" >> $RESULT_FILE 2>&1
                else
                    echo "/etc/issue.net" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/issue.net | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/welcome.msg ] 
        then
            if [ `cat /etc/welcome.msg | grep -i "banner" | grep "=" | grep "\".\"" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                if [ `cat /etc/welcome.msg | grep -i "banner" | grep "=" | grep "\".\"" | wc -l` -gt 0 ]
                then
                    echo "/etc/welcome.msg" >> $RESULT_FILE 2>&1
                else
                    echo "/etc/welcome.msg" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/welcome.msg | grep -i "banner" | grep "=" | grep "\".\"" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi 
        fi
        
        if [ -f /etc/vsftpd.conf ]
        then
            if [ `cat /etc/vsftpd.conf | grep -i "ftp_banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
            then 
                VULN_RESULT="1"
                if [ `cat /etc/vsftpd.conf | grep -i "ftp_banner" | grep "=" |  grep "\." | wc -l` -gt 10 ]
                then
                    echo "/etc/vsftpd.conf" >> $RESULT_FILE 2>&1
                else 
                    echo "/etc/vsftpd.conf" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/vsftpd.conf | grep -i "ftp_banner" | grep "=" |  grep "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/proftpd.conf ]
        then
            if [ `cat /etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 10 ]
                then
                    echo "/etc/proftpd.conf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /usr/local/etc/proftpd.conf ]
        then
            if [ `cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | wc -l` -gt 10 ]
                then
                    echo "/usr/local/etc/proftpd.conf " >> $RESULT_FILE 2>&1
                else
                    echo "/usr/local/etc/proftpd.conf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /usr/local/etc/proftpd.conf | grep -i "Serverldent" | grep -i "off" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/ftpaccess ]
        then
            if [ `cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" | wc -l` -gt 0 ]
            then 
                VULN_RESULT="1"
               
                if [ `cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" | wc -l` -gt 10 ]
                then 
                    echo "/etc/ftpaccess " >> $RESULT_FILE 2>&1
                else
                    echo "/etc/ftpaccess " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/ftpaccess | grep -i "greeting" | grep -i "terse" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
         
        if [ -f /etc/mail/sendmail.cf ]
        then
            if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | wc -l` -gt 10 ]
                then
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                else
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep "v" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "SunOS" ]
then
    if [ -f /etc/default/telnetd ]
    then
        if [ `cat /etc/default/telnetd | grep -v "#" | grep -i "banner" | grep "=" | grep "Unlistend OS"| wc -l` -gt 0 ]
        then
         :
        else
            
            if [ `cat /etc/default/telnetd | grep -v "#" | grep -i "banner" | grep "\." | grep "=" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
        fi
    fi
    
    if [ -f /etc/default/ftpd ]
    then
        if [ `cat /etc/default/ftpd | grep -v "#" | grep -i "banner" | grep "=" |grep "Unlistend OS"| wc -l` -gt 0 ]
        then
          :
        else
            if [ `cat /etc/default/ftpd | grep -v "#" | grep -i "banner" | grep "=" | grep "\." | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
        fi
    fi

    if [ -f /etc/ftpd/ftpaccess ]
    then
        if [ `cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | grep -i "yes" | wc -l` -lt 2 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f /etc/ftpd/welcome.msg ]
    then
        if [ `cat /etc/ftpd/welcome.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f /etc/ftpd/banner.msg ]
    then
        if [ `cat /etc/ftpd/banner.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi
    
    if [ -f /etc/mail/sendmail.cf ]
    then
        if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep -v "#" | grep "v" | wc -l` -gt 0 ]
        then
            CHKFLAG="NO"  
        fi
    fi

    if [ $CHKFLAG = "NO" ]
    then
    	VULN_RESULT="1"
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
        if [ -f /etc/default/telnetd ]
        then
            if [ `cat /etc/default/telnetd | grep -v "#" | grep -i "banner" | grep "=" | grep "Unlistend" | wc -l` -gt 0 ]
            then
                :
            else
                if [ `cat /etc/default/telnetd | grep -v "#" | grep -i "banner" |  grep "\." | grep "=" | wc -l` -gt 0 ]
                then
                    VULN_RESULT="1"
                    
                    if [ `cat /etc/default/telnetd | grep -v "#" | grep -i "banner" |  grep "\." | grep "=" | wc -l` -gt 10 ]
                    then
                        echo "/etc/default/telnetd" >> $RESULT_FILE 2>&1
                    else
                        echo "/etc/default/telnetd" >> $RESULT_FILE 2>&1
                        echo "(" >> $RESULT_FILE 2>&1
                        cat /etc/default/telnetd | grep -v "#" | grep -i "banner" | grep "\." | grep "=" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                        echo ")" >> $RESULT_FILE 2>&1
                    fi
                    
                    echo " " >> $RESULT_FILE 2>&1
                fi
            fi
        fi
        
        if [ -f /etc/default/ftpd ]
        then
            if [ `cat /etc/default/ftpd | grep -v "#" | grep -i "banner" | grep "=" | grep "Unlistend"| wc -l` -gt 0 ]
            then
                :
            else
                if [ `cat /etc/default/ftpd | grep -v "#" | grep -i "banner" |  grep "\." | grep "=" | wc -l` -gt 0 ]
                then
                    VULN_RESULT="1"
                    
                    if [ `cat /etc/default/ftpd | grep -v "#" | grep -i "banner" |  grep "\." | grep "=" | wc -l` -gt 10 ]
                    then
                        echo "/etc/default/ftpd " >> $RESULT_FILE 2>&1
                    else
                        echo "/etc/default/ftpd " >> $RESULT_FILE 2>&1
                        echo "(" >> $RESULT_FILE 2>&1
                        cat /etc/default/ftpd | grep -v "#" | grep -i "banner" |  grep "\." | grep "=" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                        echo ")" >> $RESULT_FILE 2>&1
                    fi
                    
                    echo " " >> $RESULT_FILE 2>&1
                fi
            fi
        fi
        
        if [ -f /etc/ftpd/ftpaccess ]
        then
            if [ `cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | egrep -i "yes" | wc -l` -lt 2 ]
            then
                VULN_RESULT="1"
                
                echo "/etc/ftpd/ftpaccess " >> $RESULT_FILE 2>&1
                echo "(" >> $RESULT_FILE 2>&1
                cat /etc/ftpd/ftpaccess | grep -v "#" | egrep -i "suppresshostname|suppressversion" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/ftpd/welcome.msg ] 
        then
            if [ `cat /etc/ftpd/welcome.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/ftpd/welcome.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 10 ]
                then
                    echo "/etc/ftpd/welcome.msg" >> $RESULT_FILE 2>&1
                else
                    echo "/etc/ftpd/welcome.msg" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/ftpd/welcome.msg | grep -i "banner" | grep "=" |  grep "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/ftpd/banner.msg ]
        then
            if [ `cat /etc/ftpd/banner.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                if [ `cat /etc/ftpd/banner.msg | grep -i "banner" | grep "=" |  grep "\." | wc -l` -gt 10 ]
                then
                    echo "/etc/ftpd/banner.msg" >> $RESULT_FILE 2>&1
                else
                    echo "/etc/ftpd/banner.msg" >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/ftpd/banner.msg | grep -i "banner" | grep "=" | grep "\." | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
                
                echo " " >> $RESULT_FILE 2>&1
            fi
        fi
        
        if [ -f /etc/mail/sendmail.cf ]
        then
            if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep -v "#" | grep "v" |  wc -l` -gt 0 ]
            then
                VULN_RESULT="1"
                
                
                if [ `cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep -v "#" | grep "v" |  wc -l` -gt 0 ]
                then
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                else
                    echo "/etc/mail/sendmail.cf " >> $RESULT_FILE 2>&1
                    echo "(" >> $RESULT_FILE 2>&1
                    cat /etc/mail/sendmail.cf | grep -i "GreetingMessage" | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
            fi
        fi
        
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1	
    fi
fi

