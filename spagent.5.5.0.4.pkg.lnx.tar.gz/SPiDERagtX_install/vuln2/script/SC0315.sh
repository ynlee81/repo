#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0315"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
    then
        CHKFLAG="YES"
    else
        if [ -f "/etc/snmpd.conf" ]
        then
            if [ `cat /etc/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
            	:
            else
                CHKFLAG="NO"
            fi
        else
            VULN_RESULT="0"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            echo "    <CONTENT>" >> $RESULT_FILE 2>&1
            echo "/etc/snmpd.conf ( File not found )" >> $RESULT_FILE 2>&1
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
            echo "    <START_DATE>`date "+%Y/%m/%d %H:%M:%S"`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date "+%Y/%m/%d %H:%M:%S"`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi

    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	#echo "SNMP ���� ���� ���"  >> $RESULT_FILE 2>&1
    
        if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
        then
        	:
        else
        
            if [ -f "/etc/snmpd.conf" ]
            then
                if [ `cat /etc/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
                then
            		:
                else
                    #echo ", SNMP���� �������̸� Default String�� �����Ǿ� ���� (" >> $RESULT_FILE 2>&1
                    
                    echo "/etc/snmpd.conf " >> $RESULT_FILE 2>&1
                    echo "( " >> $RESULT_FILE 2>&1
                    cat /etc/snmpd.conf | egrep -i "public|private" | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                    echo ")" >> $RESULT_FILE 2>&1
                fi
            fi
        fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1	
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "HP-UX" ]
then

    if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
    then
        CHKFLAG="YES"
    else
        if [ -f "/etc/snmpd.conf" ]
        then
            if [ `cat /etc/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
            	:
            else
                CHKFLAG="NO"
            fi
        else
            VULN_RESULT="3"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT>" >> $RESULT_FILE 2>&1
            echo "/etc/snmpd.conf ( File not found )" >> $RESULT_FILE 2>&1
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
            echo "    <START_DATE>`date "+%Y/%m/%d %H:%M:%S"`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date "+%Y/%m/%d %H:%M:%S"`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
            
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	#echo "SNMP ���� ���� ���"  >> $RESULT_FILE 2>&1
    
        if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
        then
        	:
        else
            if [ `cat /etc/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
        		:
            else
                #echo ", SNMP���� �������̸� Default String�� �����Ǿ� ���� (" >> $RESULT_FILE 2>&1
                echo "/etc/snmpd.conf " >> $RESULT_FILE 2>&1
                echo "( " >> $RESULT_FILE 2>&1
                cat /etc/snmpd.conf | egrep -i "public|private" | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
            fi
        fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1			
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
elif [ $OS = "Linux" ]
then

    if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
    then
        CHKFLAG="YES"
    else
    
        if [ -f "/etc/snmp/conf/snmpd.conf" ]
        then
            if [ `cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
            	CHKFLAG="YES"
            else
                CHKFLAG="NO"
            fi
        else
            VULN_RESULT="0"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT>" >> $RESULT_FILE 2>&1
            echo "/etc/snmp/conf/snmpd.conf ( File not found )" >> $RESULT_FILE 2>&1
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
            echo "    <START_DATE>`date "+%Y/%m/%d %H:%M:%S"`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date "+%Y/%m/%d %H:%M:%S"`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
		VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		#echo "SNMP ���� ���� ���"  >> $RESULT_FILE 2>&1
    
        if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
        then
        	:
        else
            if [ `cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
        		:
            else
                #echo ", SNMP���� �������̸� Default String�� �����Ǿ� ���� (" >> $RESULT_FILE 2>&1
        	    
        	    echo "/etc/snmp/conf/snmpd.conf " >> $RESULT_FILE 2>&1
        	    echo "( " >> $RESULT_FILE 2>&1
                cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private" | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
            fi
        fi
    
		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date "+%Y/%m/%d %H:%M:%S"`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date "+%Y/%m/%d %H:%M:%S"`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi
    
elif [ $OS = "SunOS" ]
then

    if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
    then
        CHKFLAG="YES"
    else
    
        if [ -f /etc/snmp/conf/snmpd.conf ]
        then
        
            if [ `cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
                CHKFLAG="YES"
            else
                CHKFLAG="NO"
            fi
        else
            VULN_RESULT="0"
        	echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT>" >> $RESULT_FILE 2>&1
            echo "/etc/snmp/conf/snmpd.conf ( File not found )" >> $RESULT_FILE 2>&1
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
            echo "    <START_DATE>`date "+%Y/%m/%d %H:%M:%S"`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date "+%Y/%m/%d %H:%M:%S"`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    fi

    if [ $CHKFLAG = "NO" ]
    then
		VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
		#echo "SNMP ���� ���� ���"  >> $RESULT_FILE 2>&1

        if [ `ps -ef | grep snmp | grep -v "dmi" | grep -v "grep" | wc -l` -eq 0 ]
        then
        	:
        else
            if [ `cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private"| grep -v "#" | wc -l ` -eq 0 ]
            then
        		:
            else
                #echo ", SNMP���� �������̸� Default String�� �����Ǿ� ���� (" >> $RESULT_FILE 2>&1
        	    echo "/etc/snmp/conf/snmpd.conf " >> $RESULT_FILE 2>&1
        	    echo "(" >> $RESULT_FILE 2>&1
                cat /etc/snmp/conf/snmpd.conf | egrep -i "public|private" | grep -v "#" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
                echo ")" >> $RESULT_FILE 2>&1
            fi
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi

else
    VULN_RESULT="2"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    echo "not support os" >> $RESULT_FILE 2>&1
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

