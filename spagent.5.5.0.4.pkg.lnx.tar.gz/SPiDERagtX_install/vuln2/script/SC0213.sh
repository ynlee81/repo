#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0213"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`
if [ $OS = "AIX" ]
then
    DIR744="/etc/inittab /etc/syslog.conf /etc/snmpd.conf"
    #ALL="/etc/rc*.d/* /etc/inittab /etc/syslog.conf /etc/snmpd.conf /var/adm/cron/cron* /var/adm/cron/at* /var/spool/cron/*"
    #DIR="/etc/rc*.d/* "

    if [  `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
    then
        :
    else
	    CHKFLAG="NO"
    fi

    i=0
    for check_dir in $DIR744
    do
    	i=`expr $i + 1`
    	
    	if [ $i = 25 ]
    	then
    		sleep 1
    		i=0
    	fi
    	
        if [  `ls -alL $check_dir 2> /dev/null | awk '{print $1}' |grep  '........w.' |wc -l` -eq 0 ]
        then
            :
        else
            CHKFLAG="NO"
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "��Ÿ �߿� ���� ���� ���� ���"   >> $RESULT_FILE 2>&1

        if [  `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
        then
            :
        else
            j=`ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l`
            if [ $j -gt 5 ]
            then
                echo "/etc/rc*.d/* ($j File(s) Found )" >> $RESULT_FILE 2>&1
            else
                i=0
                for check_dir in /etc/rc*.d/*
                do
                	i=`expr $i + 1`
                	
                	if [ $i = 25 ]
                	then
                		sleep 1
                		i=0
                	fi
            
                    if [ -f "$check_dir" ]
                    then
                        if [ `ls -alL $check_dir 2> /dev/null |  awk '{print $1}'| grep  '........w.' | wc -l` -eq 0 ]
                        then
            	            : 
                        else
            	            echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                        fi
                    else
                        :
                    fi
                done
            fi
        fi

        i=0
        for check_dir in $DIR744
        do
            i=`expr $i + 1`
            
            if [ $i = 25 ]
            then
            	sleep 1
            	i=0
            fi
            
            if [ -f "$check_dir" ]
            then
                if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'| grep  '........w.' |wc -l` -eq 0 ]
                then
                    : 
                else
                    echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")"  >> $RESULT_FILE 2>&1
                	VULN_RESULT="1"
                fi
            else
                :
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "HP-UX" ]
then
    DIR744="/etc/inittab /etc/syslog.conf /etc/snmpd.conf"
    #ALL="/sbin/rc*.d/* /etc/inittab /etc/syslog.conf /etc/snmpd.conf /var/adm/cron/cron* /var/adm/cron/at* /var/spool/cron/*"
    #DIR="/sbin/rc*.d/* "

    if [  `ls -alL /sbin/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
    then
        :
    else
	    CHKFLAG="NO"
    fi

    i=0
    for check_dir in $DIR744
    do
    	i=`expr $i + 1`
    	
    	if [ $i = 25 ]
    	then
    		sleep 1
    		i=0
    	fi
    	
        if [  `ls -alL $check_dir 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ]
        then
            :
        else
            CHKFLAG="NO"
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "��Ÿ �߿� ���� ���� ���� ���"   >> $RESULT_FILE 2>&1

        if [  `ls -alL /sbin/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
        then
            :
        else
            j=`ls -alL /sbin/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l`
            if [ $j -gt 5 ]
         	then
                echo "/sbin/rc*.d/* ($j File(s) Found )" >> $RESULT_FILE 2>&1
            else
                i=0
                
                for check_dir in /sbin/rc*.d/*
                do
                	i=`expr $i + 1`
                	
                	if [ $i = 25 ]
                	then
                		sleep 1
                		i=0
                	fi
                	
                    if [ -f "$check_dir" ]
                    then
                        if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'|  grep  '........w.' |wc -l` -eq 0 ]
                        then
                            : 
                        else
                            echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                        fi
                    else
                        :
                    fi
                done
            fi
        fi

        i=0
        for check_dir in $DIR744
        do
            i=`expr $i + 1`
            
            if [ $i = 25 ]
            then
            	sleep 1
            	i=0
            fi
            
            if [ -f "$check_dir" ]
            then
                if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'|  grep  '........w.' |wc -l` -eq 0 ]
                then
                    : 
                else
                    echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                fi
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "Linux" ]
then
    DIR744="/etc/inittab /etc/syslog.conf /etc/snmp/snmpd.conf /etc/crontab"
    #ALL="/etc/rc*.d/* /etc/inittab /etc/syslog.conf /etc/snmp/snmpd.conf /etc/crontab /etc/cron.daily/* /etc/cron.hourly/* /etc/cron.monthly/* /etc/cron.weekly/* /var/spool/cron/*"
    #DIR="/etc/rc*.d/*"
    
    if [ `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
    then
        :
    else
	    CHKFLAG="NO"
    fi

    i=0
    for check_dir in $DIR744
    do
    	i=`expr $i + 1`
    	
    	if [ $i = 25 ]
    	then
    		sleep 1
    		i=0
    	fi
    	
        if [  `ls -alL $check_dir 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ]
        then
            :
        else
            CHKFLAG="NO"
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "��Ÿ �߿� ���� ���� ���� ���"   >> $RESULT_FILE 2>&1

        if [  `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
        then
            :
        else
            j=`ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l`
            
            if [ $j -gt 5 ]
         	then
                echo "/etc/rc*.d/* ($j File(s) Found )" >> $RESULT_FILE 2>&1
            else
                i=0
                
                for check_dir in /etc/rc*.d/*
                do
                	i=`expr $i + 1`
                	
                	if [ $i = 25 ]
                	then
                		sleep 1
                		i=0
                	fi
                
                    if [ -f "$check_dir" ]
                    then
                        if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'| grep  '........w.' |wc -l` -eq 0 ]
                        then
                            : 
                        else
                            echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                        fi
                    else
                        :
                    fi
                done
            fi
        fi

        i=0
        for check_dir in $DIR744
        do
        	i=`expr $i + 1`
        	
        	if [ $i = 25 ]
        	then
        		sleep 1
        		i=0
        	fi
        	
        	i=`expr $i + 1`
        	
        	if [ $i = 25 ]
        	then
        		sleep 1
        		i=0
        	fi

            if [ -f "$check_dir" ]
            then
                if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'| grep  '........w.' |wc -l` -eq 0 ]
                then
                    : 
                else
                    echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")"  >> $RESULT_FILE 2>&1
                fi
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "SunOS" ]
then
    DIR744="/etc/inittab /etc/syslog.conf /etc/snmp/conf/snmpd.conf"
    #ALL="/etc/rc2.d/* /etc/inittab /etc/syslog.conf /etc/snmp/conf/snmpd.conf /etc/cron.d/cron* /etc/cron.d/at* /var/spool/cron/*"
    #DIR="/etc/rc*.d/* "

    if [  `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' |wc -l` -eq 0 ] 
    then
        :
    else
	    CHKFLAG="NO"
    fi

    i=0
    for check_dir in $DIR744
    do
    	i=`expr $i + 1`
    	
    	if [ $i = 25 ]
    	then
    		sleep 1
    		i=0
    	fi
    	
        if [  `ls -alL $check_dir 2> /dev/null | awk '{print $1}'| grep  '........w.' |wc -l` -eq 0 ]
        then
            :
        else
            CHKFLAG="NO"
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "��Ÿ �߿� ���� ���� ���� ���"   >> $RESULT_FILE 2>&1

        if [  `ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.' | wc -l` -eq 0 ] 
        then
            :
        else
            j=`ls -alL /etc/rc*.d/* 2> /dev/null | grep  '........w.'|wc -l`
	
	        if [ $j -gt 5 ]
     	    then
	            echo "/etc/rc*.d/* ($j File(s) Found )" >> $RESULT_FILE 2>&1
	        else
	            i=0
	            
                for check_dir in /etc/rc*.d/*
                do
                	i=`expr $i + 1`
                	
                	if [ $i = 25 ]
                	then
                		sleep 1
                		i=0
                	fi
                	
                    if [ -f "$check_dir" ]
                    then
                        if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'|  grep  '........w.' |wc -l` -eq 0 ]
                        then
                            : 
                        else
                            echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                        fi
                    fi
                done
            fi
        fi

        i=0
        for check_dir in $DIR744
        do
        	i=`expr $i + 1`
        	
        	if [ $i = 25 ]
        	then
        		sleep 1
        		i=0
        	fi

            if [ -f "$check_dir" ]
            then
                if [ `ls -alL $check_dir 2> /dev/null | awk '{print $1}'| grep  '........w.' |wc -l` -eq 0 ]
                then
                    : 
                else
                    echo "$check_dir ( Permission:" `ls -alL $check_dir | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
                fi
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

else
    VULN_RESULT="2"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    echo "not support os" >> $RESULT_FILE 2>&1
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

