# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ��Ʈ��ũ ����(amd) Ȯ��


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0305"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"


OS=`uname -s`
if [ $OS = "AIX" ]
then
        
    if [ `ps -ef | grep amd | grep -v "grep"| wc -l` -eq 0 ]
    then
    	:
    else
        CHKFLAG="NO"
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "automountd ���� ������, Ȯ�� ���� (" >> $RESULT_FILE 2>&1
        echo "automountd service is running " >> $RESULT_FILE 2>&1
        echo "(" >> $RESULT_FILE 2>&1
        ps -ef | egrep "amd" | grep -v "grep" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
        echo ")" >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1	
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
    

elif [ $OS = "HP-UX" ]
then
    
    if [ `ps -ef | grep amd | grep -v samd | grep -v "grep"| wc -l` -eq 0 ]
    then
    	:
    else
        CHKFLAG="NO"
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "automountd ���� ������, Ȯ�� ���� (" >> $RESULT_FILE 2>&1
        echo "automountd service is running " >> $RESULT_FILE 2>&1
        echo "(" >> $RESULT_FILE 2>&1
        ps -ef | egrep "amd" | grep -v samd | grep -v "grep" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
        echo ")" >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1	
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
    
elif [ $OS = "Linux" ]
then
    SERVICE_NAME="autofs"
    
    if [ `ps -ef | grep $SERVICE_NAME | grep -v "grep"| wc -l` -eq 0 ]
    then
    	:
    else
        CHKFLAG="NO"
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "automountd ���� ������, Ȯ�� ���� (" >> $RESULT_FILE 2>&1
        echo "$SERVICE_NAME service is running " >> $RESULT_FILE 2>&1
        echo "(" >> $RESULT_FILE 2>&1
        ps -ef | egrep "$SERVICE_NAME" | grep -v "grep" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
        echo ")" >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1	
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

elif [ $OS = "SunOS" ]
then
    SERVICE_NAME="autofs"
    
    if [ `ps -ef | grep $SERVICE_NAME | grep -v "grep"| wc -l` -eq 0 ]
    then
    	:
    else
        CHKFLAG="NO"
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "automountd ���� ������, Ȯ�� ���� (" >> $RESULT_FILE 2>&1
        echo "$SERVICE_NAME service is running " >> $RESULT_FILE 2>&1
        echo "(" >> $RESULT_FILE 2>&1
        ps -ef | egrep "$SERVICE_NAME" | grep -v "grep" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
        echo ")" >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1	
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi

fi
