# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : /dev ���丮 ���� ����

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0208"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

FILE_COUNT=`find /dev -type f -exec ls -alL {} \; | egrep -v "/dev/.devfsadm_dev.lock | /dev/.devlink_db_lock | /dev/.devfsadm_deamon.lock | /dev/.devfsadm_synch_door|/dev/.devlink_db|/dev/disk.log|/dev/null2" | awk {'print $1'} | wc -l`

if [ $FILE_COUNT -gt 0 ]
then
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    
    echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    #echo "/dev ���丮�� �ǽɽ��� ���� ����, Ȯ�� �ʿ�( "   >> $RESULT_FILE 2>&1
    # 10�� �̻��� ��� ������ ������
    if [ $FILE_COUNT -gt 10 ]
    then
        echo "/dev ( $FILE_COUNT File(s) Found )" >> $RESULT_FILE 2>&1
    else
        find /dev -type f -exec ls -alL {} \; | egrep -v "/dev/.devfsadm_dev.lock|/dev/.devlink_db_lock|/dev/.devfsadm_deamon.lock|/dev/.devfsadm_synch_door|/dev/.devlink_db|/dev/disk.log|/dev/null2" | awk {'print $9 " ( Permission: " $1 " )" '}  >> $RESULT_FILE 2>&1
    fi
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

