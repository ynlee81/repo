# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ���̷���/���ͳ� �� ���� ����(Trinoo Backdoor) 1524/tcp , 27665/tcp , 27444/tcp , 31335/udp


# ��� OS ���� 

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0703"

VULN_RESULT="0"

CHKFLAG="YES"

TMPFLAG="YES"

if [ `netstat -an | egrep '1524|27665|27444|31335' | wc -l` -eq 0 ]
then
 	:
else
	CHKFLAG="NO"
fi


if [ $CHKFLAG = "NO" ]
then
    VULN_RESULT="1"
	echo "  <RESULT>" >> $RESULT_FILE 2>&1
	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
	#echo "���̷���/���ͳ� �� ���� �ǽ�, Trinoo Backdoor("  >> $RESULT_FILE 2>&1
	#echo "Trinoo Backdoor("  >> $RESULT_FILE 2>&1

	#netstat -an | egrep "1524|27665|27444|31335" >> $RESULT_FILE 2>&1
	
	PORT_LIST="1524 27665 27444 31335"
    for port in $PORT_LIST
    do
        if [ `netstat -an | grep $port | wc -l` -gt 0 ]
        then
            echo "$port port is opened" >>  $RESULT_FILE 2>&1
        fi
    done
    
	
	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:	
fi



#if [ `crontab -l | egrep 'tsolnmb|ns|httpd|rpc.trinoo|rpc.listen|trinix|rpc.irix|irix'| wc -l` -eq 0 ]
#then
#    CHKFLAG="YES"
#else
#    CHKFLAG="NO"
#fi

#if [ $CHKFLAG = "NO" ]
#then
#    VULN_RESULT="1"
#	echo "  <RESULT>" >> $RESULT_FILE 2>&1
#	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
#	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
#	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
#	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
#	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
#	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
#	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
#	#echo "���̷���/���ͳ� �� ���� �ǽ�, Trinoo Backdoor("  >> $RESULT_FILE 2>&1
#	#echo "Trinoo Backdoor("  >> $RESULT_FILE 2>&1
#
#  crontab -l | egrep "tsolnmb|ns|httpd|rpc.trinoo|rpc.listen|trinix|rpc.irix|irix" >> $RESULT_FILE 2>&1
#echo ")" >> $RESULT_FILE 2>&1
#	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
#	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
#	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
#	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
#	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
#	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
#  echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
#	echo "  </RESULT>" >> $RESULT_FILE 2>&1
#else
#	:	
#fi

exit
