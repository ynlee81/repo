# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : CRON �� root ���ٱ��� ���� ����


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0215"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`

if [ $OS = "AIX" ]
then
    CRON_ALLOW_FILE="/var/adm/cron/cron.allow"
    AT_ALLOW_FILE="/var/adm/cron/at.allow"
elif [ $OS = "HP-UX" ]
then
    CRON_ALLOW_FILE="/var/adm/cron/cron.allow"
    AT_ALLOW_FILE="/var/adm/cron/at.allow"
elif [ $OS = "Linux" ]
then
    CRON_ALLOW_FILE="/etc/cron.allow"
    AT_ALLOW_FILE="/etc/at.allow"
elif [ $OS = "SunOS" ]
then
    CRON_ALLOW_FILE="/etc/cron.d/cron.allow"
    AT_ALLOW_FILE="/etc/cron.d/at.allow"
fi


if [ -f "$CRON_ALLOW_FILE" ]
then
    # cron.allow 
    if [ `ls -al $CRON_ALLOW_FILE | awk {'print $3'} | egrep 'root|bin' | wc -l` -eq 1 ]
    then
        :
    else
        CHKFLAG="NO"
    fi
else
    # $CRON_ALLOW_FILE �� ������ ��� �Ѱ�? 
    # �������� FreeBSD�� ��� ����ڰ� ��� ����
    if [ $OS = "Linux" ]
    then
        VULN_RESULT="1"
    else
        :
    fi
fi

if [ -f "$AT_ALLOW_FILE" ]
then
    if [ `ls -al $AT_ALLOW_FILE | awk {'print $3'} | egrep 'root|bin' | wc -l` -eq 1 ]
    then
        :
    else
        CHKFLAG="NO"
    fi
else
    :
fi


if [ $CHKFLAG = "NO" ]
then
    

    VULN_RESULT="1"
     
	echo "  <RESULT>" >> $RESULT_FILE 2>&1
	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	echo "    <CONTENT>" >> $RESULT_FILE 2>&1

	#echo "CRON �� root ���ٱ��� ���� ���� ��� ($CRON_ALLOW_FILE, $AT_ALLOW_FILE)"  >> $RESULT_FILE 2>&1

    if [ -f "$CRON_ALLOW_FILE" ]
    then
        if [ `ls -al $CRON_ALLOW_FILE | awk {'print $3'} | egrep 'root|bin' | wc -l` -eq 1 ]
        then
            :
        else            
            echo "$CRON_ALLOW_FILE ( Owner : " `ls -al $CRON_ALLOW_FILE | awk {'print $3'}` " )" >> $RESULT_FILE 2>&1
        fi
    else
        echo "$CRON_ALLOW_FILE ( File not found ) " >> $RESULT_FILE 2>&1
    fi

    if [ -f "$AT_ALLOW_FILE" ]
    then
        if [ `ls -al $AT_ALLOW_FILE | awk {'print $3'} | egrep 'root|bin' | wc -l` -eq 1 ]
        then
            :
        else
            echo "$AT_ALLOW_FILE ( Owner : " `ls -al $AT_ALLOW_FILE | awk {'print $3'}` " )" >> $RESULT_FILE 2>&1
        fi
    fi

	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
	echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
	echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:
fi
    
# HP-UX
# /var/adm/con/cron.allow
# cron�� ��� �Ҽ� �ִ� ������ ���� �Ҽ� �ִ�

