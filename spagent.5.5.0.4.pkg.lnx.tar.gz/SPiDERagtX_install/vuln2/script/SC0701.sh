# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ���̷���/���ͳ� �� ���� ����(Leapfrog Backdoor)


#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0701"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    #netstat -an|grep tcp
    #tcp4       0      0  *.13                   *.*                    LISTEN
    #tcp        0      0  *.21                   *.*                    LISTEN
    #tcp        0      0  *.23                   *.*                    LISTEN

    #netstat -an | grep tcp | grep 5000  | awk {'print $4'}| grep "^*" | awk -F. {'print $2'}
    PORT_NUM=`netstat -an | grep tcp | grep 5000 | awk {'print $4'}| grep "^*" | awk -F. {'print $2'} | wc -l`
    PORT_LIST=`netstat -an | grep tcp | grep 5000 | awk {'print $4'}| grep "^*" | awk -F. {'print $2'}`

    if [ $PORT_NUM -gt 0 ]
    then
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                CHKFLAG="NO"
            fi
        done
    else
        exit
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT>5000</VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL>TCP</PROTOCOL>" >> $RESULT_FILE 2>&1
    	
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "���̷���/���ͳ� �� �������� - Backdoor Leapfrog : ���"  >> $RESULT_FILE 2>&1
    
        VULN_RESULT="1"
        
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                echo "$port port is opened" >>  $RESULT_FILE 2>&1
                #netstat -an | grep tcp | grep 5000 >>  $RESULT_FILE 2>&1
            fi
        done
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "HP-UX" ]
then

    #netstat -an | grep tcp
    #tcp        0      0  *.37                   *.*                     LISTEN
    #tcp        0      0  *.7                    *.*                     LISTEN

    #netstat -an | grep tcp | grep 5000  | awk {'print $4'}| grep "^*" | awk -F. {'print $2'}
    PORT_NUM=`netstat -an | grep tcp | grep 5000  | awk {'print $4'}| grep "^*" | awk -F. {'print $2'} | wc -l`
    PORT_LIST=`netstat -an | grep tcp | grep 5000  | awk {'print $4'}| grep "^*" | awk -F. {'print $2'}`

    if [ $PORT_NUM -gt 0 ]
    then
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                CHKFLAG="NO"
            fi
        done
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT>5000</VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL>TCP</PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	
        #echo "���̷���/���ͳ� �� �����ǽ�, Backdoor Leapfrog (openport:5000)" >>  $RESULT_FILE 2>&1
            
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                echo "$port port is opened" >>  $RESULT_FILE 2>&1
                #netstat -an | grep tcp | grep 5000 >>  $RESULT_FILE 2>&1
            fi
        done
        
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    
elif [ $OS = "Linux" ]
then

    #netstat -an | grep tcp
    
    #tcp        0      0 0.0.0.0:32768           0.0.0.0:*               LISTEN
    #tcp        0      0 0.0.0.0:40001           0.0.0.0:*               LISTEN
    #tcp        0      0 0.0.0.0:60001           0.0.0.0:*               LISTEN

    PORT_NUM=`netstat -an | grep tcp | grep 5000 | awk {'print $4'} | awk -F: {'print $2'} | wc -l`
    PORT_LIST=`netstat -an | grep tcp | grep 5000 | awk {'print $4'} | awk -F: {'print $2'}`
    
    # 5000 �̶�� ���ڿ��� ã��
    if [ $PORT_NUM -gt 0 ]
    then
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                CHKFLAG="NO"
            fi
        done
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT>5000</VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL>TCP</PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    	
        #echo "���̷���/���ͳ� �� �����ǽ�, Backdoor Leapfrog (openport:5000)" >>  $RESULT_FILE 2>&1
            
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                echo "$port port is opened" >>  $RESULT_FILE 2>&1
                #netstat -an | grep tcp | grep 5000 >>  $RESULT_FILE 2>&1
            fi
        done
        
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "SunOS" ]
then

    #netstat -an 
    
    #TCP: IPv4
    #   Local Address        Remote Address    Swind Send-Q Rwind Recv-Q  State
    #-------------------- -------------------- ----- ------ ----- ------ -------
    #      *.*                  *.*                0      0 24576      0 IDLE
    #      *.111                *.*                0      0 24576      0 LISTEN
    #      *.*                  *.*                0      0 24576      0 IDLE
    #      *.21                 *.*                0      0 24576      0 LISTEN
    #      *.23                 *.*                0      0 24576      0 LISTEN
    
    
    # �ֶ󸮽��� tcp�� ��� LISTEN 
    #            udp�� ��� Idle
    # ��� ����Ѵ�

    PORT_NUM=`netstat -an | grep 'LISTEN' | grep 5000 | awk {'print $1'} | grep '^*' | awk -F. {'print $2'} | wc -l`
    PORT_LIST=`netstat -an | grep 'LISTEN' | grep 5000 | awk {'print $1'} | grep '^*' | awk -F. {'print $2'}`
    
    # 5000 �̶�� ���ڿ��� ã��
    if [ $PORT_NUM -gt 0 ]
    then
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                $CHKFLAG = "NO"
            fi
        done
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
        VULN_RESULT="1"
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT>5000</VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL>TCP</PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1

        #echo "���̷���/���ͳ� �� �����ǽ�, Backdoor Leapfrog (openport:5000)" >>  $RESULT_FILE 2>&1
            
        for port in $PORT_LIST
        do
            if [ $port -eq 5000 ]
            then
                echo "$port port is opened" >>  $RESULT_FILE 2>&1
                #netstat -an | grep 'LISTEN' | grep 5000 >>  $RESULT_FILE 2>&1
            fi
        done
        
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi


