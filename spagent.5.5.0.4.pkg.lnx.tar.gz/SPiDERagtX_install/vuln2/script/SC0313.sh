# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : root ������ telnet ���� ����

# /etc/security/user ���Ͽ��� root���� rlogin ������ ������ ���� ���   
# ��� ������ rlogin�� ���� �� ��

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0313"

VULN_RESULT="0"


OS=`uname -s`
if [ $OS = "AIX" ]
then
    if [ -f /etc/security/user ]
    then
        if [ `cat /etc/security/user | grep "rlogin = false" | wc -l` -ge 1 ]
        then
    		:
        else
    		VULN_RESULT="1"
    		echo "  <RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    		
			echo "    <CONTENT> " >> $RESULT_FILE 2>&1
			
    		#echo "root ������ telnet ���� : ���, root���� telnet���� ��������" >> $RESULT_FILE 2>&1
    		#echo "root ������ telnet ���� ���, telnet���� ��������" >> $RESULT_FILE 2>&1
    		
    		echo "/etc/security/user ">> $RESULT_FILE 2>&1
    		echo "(">> $RESULT_FILE 2>&1
    		cat /etc/security/user | grep -v "^*" | grep "rlogin = false" | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
    		echo ")" >> $RESULT_FILE 2>&1 
			echo "    </CONTENT>" >> $RESULT_FILE 2>&1
			
    		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    		echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    else
    	VULN_RESULT="1"
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    	echo "/etc/security/user ( File not found ) " >> $RESULT_FILE 2>&1
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>0</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
elif [ $OS = "HP-UX" ]
then
    
    #/etc/securetty ������ �ִ� ���  
	#root ������ telnet ���� ��� ������ �Ǿ� ���� �ʴ� ���
    if [ -f /etc/securetty ]
    then
        #root ������ telnet ���� ��� ������ �Ǿ� �ִ��� Ȯ��
        if [ `grep "console" /etc/securetty | grep -v '#' | wc -l` -eq 0 ]
        then
    		: 
        elif [ `grep "console" /etc/securetty | grep -v '#' | wc -l` -eq 1 ]
        then
		    
            #root ������ telnet ���� ��� ������ �Ǿ� �ִ� ���
            
            VULN_RESULT="1"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT> " >> $RESULT_FILE 2>&1
            #echo "root ������ telnet ���� : ���, root���� telnet���� ��������" >> $RESULT_FILE 2>&1
            #echo "root ������ telnet ���� ���, telnet���� ��������" >> $RESULT_FILE 2>&1
            
            echo "/etc/securetty " >> $RESULT_FILE 2>&1
            echo "(" >> $RESULT_FILE 2>&1
            grep "console" /etc/securetty | grep -v '#' | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
            echo ")" >> $RESULT_FILE 2>&1 
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
            echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    else
        #root ������ telnet ���� ��� ������ �Ǿ� �ִ� ���
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        echo "/etc/securetty ( File not found )" >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>0</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
    
elif [ $OS = "Linux" ]
then
    if [ -f /etc/pam.d/login ]
    then
        if [ `grep "auth.*required.*pam_securetty.so"  /etc/pam.d/login | grep -v '#' | wc -l ` -eq 1 ]
        then
    		:
        else
            VULN_RESULT="1"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT> " >> $RESULT_FILE 2>&1
            
            #echo "root ������ telnet ���� : ���, root���� telnet���� ��������" >> $RESULT_FILE 2>&1
                        
            echo "/etc/pam.d/login " >> $RESULT_FILE 2>&1 
            echo "(" >> $RESULT_FILE 2>&1 
            cat /etc/pam.d/login | grep -v '#' | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
            #grep "auth.*required.*pam_securetty.so"  /etc/pam.d/login | grep -v '#' | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
            echo ")" >> $RESULT_FILE 2>&1 
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
            echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
    else
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        echo "/etc/pam.d/login ( File not found ) " >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>0</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
elif [ $OS = "SunOS" ]
then
    
    if [ -f /etc/default/login ]
    then
    
        #��Ʈ���� ���� ����
        
        #  #CONSOLE=/dev/console : root�������� �ٸ�terminal���� ���� ���� -> ���
        #  CONSOLE=/dev/console  : console �θ� ���� ����
        #  CONSOLE=#/dev/console : �������ε� root�� login �Ұ��� -> ��ȣ
        
        if [ `grep "CONSOLE=/dev/console" /etc/default/login | grep -v '^#' | wc -l` -eq 0 ]
        then
            VULN_RESULT="1"
            echo "  <RESULT>" >> $RESULT_FILE 2>&1
            echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
            echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
            echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
            echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
            echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
            
            echo "    <CONTENT> " >> $RESULT_FILE 2>&1
            #echo "root ������ telnet ���� : ���, root���� telnet���� ��������" >> $RESULT_FILE 2>&1
            #echo "root ������ telnet ���� ���, telnet���� ��������" >> $RESULT_FILE 2>&1
            echo "/etc/default/login " >> $RESULT_FILE 2>&1 
            echo "(" >> $RESULT_FILE 2>&1 
            grep "CONSOLE=/dev/console" /etc/default/login | awk '{ print "    " $0 }' >> $RESULT_FILE 2>&1
            echo ")" >> $RESULT_FILE 2>&1 
            echo "    </CONTENT>" >> $RESULT_FILE 2>&1
            
            echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
            echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
            echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
            echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
            echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
            echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
            echo "  </RESULT>" >> $RESULT_FILE 2>&1
        fi
        
    else
        VULN_RESULT="1"
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        echo "/etc/default/login ( File not found ) " >> $RESULT_FILE 2>&1
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>0</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    fi
fi

