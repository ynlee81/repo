#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0401"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    if [ -f /etc/syslog.conf ]
    then
        if [ `cat /etc/syslog.conf | grep -i 'auth.notice' | grep -i "/var/adm/sulog" | grep -v "#" | wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "su �α� ���� - SULOG_FILE=/var/adm/sulog ���� : ���"  >> $RESULT_FILE 2>&1
        
        if [ -f /etc/syslog.conf ]
        then
            if [ `cat /etc/syslog.conf | grep -i 'auth.notice' | grep -i "/var/adm/sulog" | grep -v "#" | wc -l` -eq 0 ]
            then
                #echo "su �α� ���� ���, /etc/login.defs ���Ͽ� sulog �������� (" >> $RESULT_FILE 2>&1
                #cat /etc/login.defs | grep -i "SULOG"  >> $RESULT_FILE 2>&1
        	    echo "/etc/syslog.conf ( Set up sulog )." >> $RESULT_FILE 2>&1
                #echo ")" >> $RESULT_FILE 2>&1
        	VULN_RESULT="1"
            fi
        else
            #echo "su �α� ���� : ���, /etc/login.defs ���� ���� " >> $RESULT_FILE 2>&1
            echo "/etc/syslog.conf ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    exit

elif [ $OS = "HP-UX" ]
then

    if [ -f /etc/default/security ]
    then
        if [ `cat /etc/default/security | grep -i "SULOG.*/var/log/sulog" | grep -v "#" | wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "su �α� ���� - SULOG_FILE=/var/adm/sulog ���� : ���"  >> $RESULT_FILE 2>&1

        if [ -f /etc/default/security ]
        then
            if [ `cat /etc/default/security | grep -i "SULOG.*/var/log/sulog" | grep -v "#" | wc -l` -eq 0 ]
            then
                #echo "su �α� ���� : ���, /etc/default/security ���Ͽ� sulog �������� (" >> $RESULT_FILE 2>&1
                #cat /etc/default/security | grep -i "SULOG"  >> $RESULT_FILE 2>&1
                echo "/etc/default/security ( Set up sulog )" >> $RESULT_FILE 2>&1
                #echo ")" >> $RESULT_FILE 2>&1
        	VULN_RESULT="1"
            fi
        else
            #echo "su �α� ���� : ���, /etc/default/security ���� ���� " >> $RESULT_FILE 2>&1
            echo "/etc/default/security ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1	
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi
    exit

elif [ $OS = "Linux" ]
then

    if [ -f /etc/login.defs ]
    then
        if [ `cat /etc/login.defs | grep -i "SULOG.*/var/log/sulog" | grep -v "#" | wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1

        if [ -f /etc/login.defs ]
        then
            if [ `cat /etc/login.defs | grep -i "SULOG.*/var/log/sulog" | grep -v "#" | wc -l` -eq 0 ]
            then
                #echo "su �α� ���� ���, /etc/login.defs ���Ͽ� sulog �������� (" >> $RESULT_FILE 2>&1
                #cat /etc/login.defs | grep -i "SULOG"  >> $RESULT_FILE 2>&1
                #cat /etc/login.defs >> $RESULT_FILE 2>&1
                echo "/etc/login.defs ( Set up sulog )" >> $RESULT_FILE 2>&1
                #echo ")" >> $RESULT_FILE 2>&1
        	VULN_RESULT="1"
            fi
        else
            #echo "su �α� ���� : ���, /etc/login.defs ���� ���� " >> $RESULT_FILE 2>&1
            echo "/etc/login.defs ( File Not found ) " >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi
exit

elif [ $OS = "SunOS" ]
then

    if [ -f /etc/default/su ]
    then
        if [ `cat /etc/default/su | grep -i "SULOG.*/var/adm/sulog" | grep -v "#" | wc -l` -eq 0 ]
        then
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "su �α� ���� - SULOG_FILE=/var/adm/sulog ���� : ���"  >> $RESULT_FILE 2>&1

        if [ -f /etc/default/su ]
        then
            if [ `cat /etc/default/su | grep -i "SULOG.*/var/adm/sulog" | grep -v "#" | wc -l` -eq 0 ]
            then
                #echo "su �α� ���� ���, /etc/defaul/su ���Ͽ� sulog �������� (" >> $RESULT_FILE 2>&1
                #cat /etc/default/su | grep -i "SULOG"  >> $RESULT_FILE 2>&1
                echo "/etc/default/su ( Set up sulog )" >> $RESULT_FILE 2>&1
                #echo ")" >> $RESULT_FILE 2>&1
        	    VULN_RESULT="1"
            fi
        else
            #echo "su �α� ���� : ���, /etc/default/su ���� ���� " >> $RESULT_FILE 2>&1
            echo "/etc/default/su ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1" 
        fi

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi
    
else
    :
fi
