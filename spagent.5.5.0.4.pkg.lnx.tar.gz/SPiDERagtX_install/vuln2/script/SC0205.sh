# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Mar 31
# ���� : hosts ������ ���� ����

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0205"
VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

HOSTS_FILE="/etc/hosts"

if [ -f "$HOSTS_FILE" ]
then

    # ls -al �� ls -alL �� ������ 
    #root@nike:/data/pis/vuln2:632> ls -al /etc/hosts
    #lrwxrwxrwx   1 root     root          12 2005��a  8��u  3AI /etc/hosts -> ./inet/hosts
    #root@nike:/data/pis/vuln2:633> ls -alL /etc/hosts
    #-r--r--r--   1 root     sys          265 2006��a  7��u 24AI /etc/hosts
    
    
    if [ `ls -alL $HOSTS_FILE | awk {'print $1'} | grep '........-.' |wc -l` -eq 1 ]
    then
        if [ `ls -alL $HOSTS_FILE | awk '{print $3}' | egrep "root|bin" |wc -l` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
else
    CHKFLAG="NO"
fi

if [ $CHKFLAG = "NO" ]
then
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    #echo "$HOSTS_FILE ���� ���Ѽ��� ���"   >> $RESULT_FILE 2>&1
    
    if [ -f "$HOSTS_FILE" ]
    then
        #echo "(����:" `ls -alL $HOSTS_FILE | awk '{print $1}'` "������:" `ls -alL $HOSTS_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
    	echo "$HOSTS_FILE ( Permission:" `ls -alL $HOSTS_FILE | awk '{print $1}'` "Owner: " `ls -alL $HOSTS_FILE | awk '{print $3}'` ")" >> $RESULT_FILE 2>&1
    else
        echo "$HOSTS_FILE ( File not found )" >> $RESULT_FILE 2>&1
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
else
	:	
fi
exit
