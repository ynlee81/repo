#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0403"

CHKFLAG="YES"
TMPFLAG="YES"
VULN_RESULT="0"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    FILES="/var/adm/wtmp /etc/utmp /etc/security/lastlog"
    
    for file in $FILES
    do
        if [ -f $file ]
        then
            if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
            then
                CHKFLAG="NO"
            fi
        fi
    done


    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
    	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "�α� ���� ���� ���� ���� : ���"  >> $RESULT_FILE 2>&1
    
        for file in $FILES
        do
            if [ -f $file ]
            then
                if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
                then
                    #echo "�α� ���� ���� ���� ���, ���� ���Ѽ��� ���� (" >> $RESULT_FILE 2>&1
                    echo "$file ( Permission:" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
        	        VULN_RESULT="1"
                fi
            else
        	    echo "$file ( File not found )" >> $RESULT_FILE 2>&1
                #echo "�α� ���� ���� ���� ���� ���, ���� ����(" $file ")" >> $RESULT_FILE 2>&1
            fi
        done
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    	echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    
    else
    	:	
    fi

elif [ $OS = "HP-UX" ]
then

    FILES="/var/adm/wtmp /etc/utmp /var/adm/btmp" 

    for file in $FILES
    do
        if [ -f $file ]
        then
            if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
            then
                CHKFLAG="NO"
            fi
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "�α� ���� ���� ���� ���� : ���"  >> $RESULT_FILE 2>&1
        
        for file in $FILES
        do
            if [ -f $file ]
            then
                if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
                then
                    #echo "�α� ���� ���� ���� ���, ���� ���Ѽ��� ���� ("  $file "���� ���Ѽ��� ����" >> $RESULT_FILE 2>&1
                    echo "$file ( Permission:" `ls -alL $file | awk '{print $1}'` ")" >> $RESULT_FILE 2>&1
               	    VULN_RESULT="1"
                fi
            else
                #echo "�α� ���� ���� ���� ���� ���, ���� ����(" $file ")" >> $RESULT_FILE 2>&1
            	echo "$file ( File not found )" >> $RESULT_FILE 2>&1
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi

elif [ $OS = "Linux" ]
then

    FILES="/var/log/wtmp /var/run/utmp /var/log/btmp /var/log/pacct /var/log/messages /var/log/lastlog /var/log/secure"
    
    for file in $FILES
    do
        if [ -f $file ]
        then
            if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
            then
                CHKFLAG="NO"
            fi
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "�α� ���� ���� ���� ���� : ���"  >> $RESULT_FILE 2>&1

        for file in $FILES
        do
            if [ -f $file ]
            then
                if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
                then
                    #echo "�α� ���� ���� ���� ���, ���� ���Ѽ��� ���� (" >> $RESULT_FILE 2>&1
                    echo "$file ( Permission:" `ls -alL $file | awk '{print $1}'`  ")" >> $RESULT_FILE 2>&1
        	        VULN_RESULT="1"
                fi
            else
                echo "$file ( File not found )" >> $RESULT_FILE 2>&1
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi

elif [ $OS = "SunOS" ]
then

    FILES="/var/adm/wtmp /var/adm/wtmpx /var/adm/utmp /var/adm/utmpx /var/adm/lastlog /var/adm/messages"
    
    for file in $FILES
    do
        if [ -f $file ]
        then
            if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
            then
                CHKFLAG="NO"
            fi
        fi
    done

    if [ $CHKFLAG = "NO" ]
    then
		echo "  <RESULT>" >> $RESULT_FILE 2>&1
		echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
		echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
		echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
		echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
		echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
		echo "    <CONTENT>" >> $RESULT_FILE 2>&1
        #echo "�α� ���� ���� ���� ���� : ���"  >> $RESULT_FILE 2>&1

        for file in $FILES
        do
            if [ -f $file ]
            then
                if [ `ls -alL $file | grep '........-.' | wc -l` -eq 0 ]
                then
                    #echo "�α� ���� ���� ���� ���, ���� ���Ѽ��� ���� (" >> $RESULT_FILE 2>&1
                    echo "$file ( Permission:" `ls -alL $file | awk '{print $1}'`  ")" >> $RESULT_FILE 2>&1
        	        VULN_RESULT="1"
                fi
            else
        	    echo "$file ( File not found )" >> $RESULT_FILE 2>&1
                #echo "�α� ���� ���� ���� ���� ���, ���� ����(" $file ")" >> $RESULT_FILE 2>&1
            fi
        done

		echo "    </CONTENT>" >> $RESULT_FILE 2>&1
		echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
		echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
		echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
		echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
		echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
		echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
		echo "  </RESULT>" >> $RESULT_FILE 2>&1
	else
		:	
    fi

else
    :
fi
