# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ����Ŭ ���� ��� IP ���� ����

# ��� OS ����

#!/bin/sh
#

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0602"

VULN_RESULT="0"

sp_getvalue() {
    RET_VAL=;
    FULL_STR=`/bin/grep -w $1 $2 | /bin/grep -v grep`
    VALUE_STR=`echo $FULL_STR | cut -d= -f 2`
    VALUE_STR1=`echo $VALUE_STR | sed 's/ //g'`

    RET_VAL=$VALUE_STR1

    return
}


# find ORA_HOME 
ORA_HOME=`grep oracle /etc/passwd | awk -F: '{print $6}'`
#echo $ORA_HOME

if [ -d "$ORA_HOME" ] ;
then
	ORACLE_CONF=`find $ORA_HOME -name "protocol.ora" -o -name "sqlnet.ora" | grep -v samples`
else
	exit 0
fi


if [ b"$ORACLE_CONF" = b"" ] ;
then
    exit 0
fi

#echo "$ORACLE_CONF"

sp_getvalue "^tcp.validnode_checking" "$ORACLE_CONF"
ORA_CHECK=$RET_VAL
#echo "aa{$ORA_CHECK}aa"

if [ "$ORA_CHECK" = "yes" ] ;
then
    :
else
    # tcp.validnode_checking=yes�� �ƴ� ��� 
    
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    echo "    <CONTENT>" >> $RESULT_FILE 2>&1
    
    #echo "ORACLE ���� ��� IP ���� ����, ���� �̼���($ORACLE_CONF�� tcp.validnode_checking=yes / tcp.invited_nodes = (������ ����� ip) / tcp.excluded_nodes = (������ ������ ip) ���� ����)"  >> $RESULT_FILE 2>&1
    
    if [ `grep "tcp.validnode_checking" $ORACLE_CONF | wc -l` -gt 0 ]
    then
        echo "$ORACLE_CONF "  >> $RESULT_FILE 2>&1
        echo "("  >> $RESULT_FILE 2>&1
        #echo "tcp.validnode_checking=yes " | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
        #echo "tcp.invited_nodes = ( Allowing Ip ) " | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
        #echo "tcp.excluded_nodes = ( Blocking ip )" | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
    
        grep "tcp.validnode_checking" $ORACLE_CONF | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
        grep "tcp.invited_nodes" $ORACLE_CONF | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
        grep "tcp.excluded_nodes" $ORACLE_CONF | awk '{print "    " $0 }'  >> $RESULT_FILE 2>&1
        echo ")"  >> $RESULT_FILE 2>&1
    else
        echo "$ORACLE_CONF ( not setting )"  >> $RESULT_FILE 2>&1
    fi
    
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

