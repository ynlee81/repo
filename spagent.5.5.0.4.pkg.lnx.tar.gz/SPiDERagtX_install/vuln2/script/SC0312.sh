# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ���� Ÿ�� �ƿ� ����

#!/bin/sh


LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0312"

VULN_RESULT="0"

CHKFLAG="YES"
TMPFLAG="YES"

OS=`uname -s`
if [ $OS = "AIX" ]
then

    #�������� ������
    if [ -f "/etc/security/login.cfg" ]
    then
        if [ `cat /etc/security/login.cfg | grep -i "logintimeout" | grep -v "*" | awk '{print$3}'` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
        
    # /etc/profile �� TMOUT üũ
    if [ -f "/etc/profile" ]
    then
        # ���� �Ǿ� �ִ� ���
        if [ `grep TMOUT /etc/profile | grep -v '#' | wc -l` -eq 1 ]
        then
            :
        else
            CHKFLAG="NO"
        fi
    fi
        
    if [ $CHKFLAG = "NO" ]
    then
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        
        #echo "session timeout ���� ���"   >> $RESULT_FILE 2>&1
                
        if [ -f /etc/security/login.cfg ]
        then
            if [ `cat /etc/security/login.cfg | grep -i "logintimeout" | grep -v "*" | awk '{print$3}' | wc -l ` -eq 1 ]
            then

                if [ `cat /etc/security/login.cfg | grep -i "logintimeout" | grep -v "*" | awk '{print$3}' ` -eq 0 ]
                then
                    VULN_RESULT="0"                    
                else
                    VULN_RESULT="1"
        		fi
        		
        		echo "/etc/security/login.cfg ( Timeout" = `cat /etc/security/login.cfg | grep -i "logintimeout" | grep -v "*" | awk '{print$3}'`" sec )" >> $RESULT_FILE 2>&1                        
            else
                VULN_RESULT="1"
                #echo ", session timeout��������(" >>  $RESULT_FILE 2>&1
                echo "/etc/security/login.cfg ( Timeout = " `cat /etc/security/login.cfg | grep -i "logintimeout" | grep -v "*" | awk '{print$3}'`" sec )" >> $RESULT_FILE 2>&1    
            fi
        else
            #echo "session timeout ����(/etc/security/login.cfg ���� ����)" >> $RESULT_FILE 2>&1
            echo "/etc/security/login.cfg ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi
                
        if [ -f "/etc/profile" ]
        then
            # ���� �Ǿ� �ִ� ���
            if [ `grep TMOUT /etc/profile | grep -v '#' | wc -l` -eq 1 ]
            then
                =
                if [ `grep TMOUT /etc/profile | grep -v '#' ` -eq 0 ]
                then
                    VULN_RESULT="1"                    
                else
                    VULN_RESULT="0"
        		fi
        		
                echo "/etc/profile (" `grep TMOUT /etc/profile | grep -v '#'` " )"  >> $RESULT_FILE 2>&1 
            else
                echo "/etc/profile ( Timeout not setting )"  >> $RESULT_FILE 2>&1 
                VULN_RESULT="1"
            fi
        fi
        
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
    

elif [ $OS = "HP-UX" ]
then
    
    if [ -f "/etc/profile" ]
    then
        if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' | wc -l ` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        
        if [ -f /etc/profile ]
        then
            if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' | wc -l ` -eq 1 ]
            then
                if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' ` -eq 0 ]
                then
                    VULN_RESULT="1"
                else
                    VULN_RESULT="0"
                fi
                
        		echo "/etc/profile ( Timeout =" `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' |awk -F= '{print $2}'` "sec )" >> $RESULT_FILE 2>&1
        		
            else
                #echo ", session timeout�������� (" >>  $RESULT_FILE 2>&1
                echo "/etc/profile ( Timeout not setting )" >>  $RESULT_FILE 2>&1
                VULN_RESULT="1"
            fi
        else
            #echo "session timeout ����(/etc/profile ���� ����)" >> $RESULT_FILE 2>&1
            echo "/etc/profile ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi
        
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "Linux" ]
then
        
    if [ -f "/etc/profile" ]
    then
        if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' | wc -l ` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
    	echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    	#echo "session timeout ���� ���"   >> $RESULT_FILE 2>&1
       
        if [ -f /etc/profile ]
        then
            if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' | wc -l ` -eq 1 ]
            then
            
                if [ `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' ` -eq 0 ]
                then
                    VULN_RESULT="1"
                else
                    VULN_RESULT="0"
                fi
                
        		echo "/etc/profile ( Timeout =" `cat /etc/profile |  grep -v "#" | grep 'TMOUT.*[0-9]' |awk -F= '{print $2}'` "sec )" >> $RESULT_FILE 2>&1
        		
            else
                #echo ", session timeout�������� (" >>  $RESULT_FILE 2>&1
    	        echo "/etc/profile ( Timeout not setting )" >>  $RESULT_FILE 2>&1
    	        VULN_RESULT="1"
            fi
        else
            #echo "session timeout ����(/etc/profile ���� ����)" >> $RESULT_FILE 2>&1
            echo "/etc/profile ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi
    
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi

elif [ $OS = "SunOS" ]
then

    if [ -f /etc/default/login ]
    then
        if [ `cat /etc/default/login |  grep -v "#" | grep 'TIMEOUT.*[0-9]' | wc -l ` -eq 1 ]
        then
            CHKFLAG="YES"
        else
            CHKFLAG="NO"
        fi
    else
        CHKFLAG="NO"
    fi
    
    
    if [ $CHKFLAG = "NO" ]
    then
    	echo "  <RESULT>" >> $RESULT_FILE 2>&1
    	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    	echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    	
    	echo "    <CONTENT> " >> $RESULT_FILE 2>&1
    	    
    	#echo "session timeout ���� ���"   >> $RESULT_FILE 2>&1
    
        if [ -f "/etc/default/login" ]
        then
            if [ `cat /etc/default/login |  grep -v "#" | grep 'TIMEOUT.*[0-9]' | wc -l ` -eq 1 ]
            then
            
                if [ `cat /etc/default/login |  grep -v "#" | grep 'TIMEOUT.*[0-9]' ` -eq 0 ]
                then
                    VULN_RESULT="1"
                else
                    VULN_RESULT="0"
                fi
        
    		    echo "/etc/default/login ( Timeout =" `cat /etc/default/login |  grep -v "#" | grep 'TIMEOUT.*[0-9]' |awk -F= '{print $2}'` " sec )" >> $RESULT_FILE 2>&1
                
            else
                #echo ", session timeout�������� (" >>  $RESULT_FILE 2>&1
                echo "/etc/default/login ( Timeout not setting )" >>  $RESULT_FILE 2>&1
                VULN_RESULT="1"
            fi
        else
            #echo "session timeout ����(/etc/default/login ���� ����)" >> $RESULT_FILE 2>&1
            echo "/etc/default/login ( File not found )" >> $RESULT_FILE 2>&1
            VULN_RESULT="1"
        fi
    	
    	echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    	echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    	echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    	echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1				
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    	echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
    	:	
    fi
fi

