# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���� : ������ Ȩ���丮�� �ǿ� ���ɼ� �ִ� ��� ���� ���� ����

# ��� OS ���� 

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SF0504"

#####################################################################
sp_getvalue() {
    RET_VAL=;
    FULL_STR=`/bin/grep -w $1 $2 | /bin/grep -v grep`

    RET_VAL=$FULL_STR

    return
}
#####################################################################

#check web service 
if [ `ps -ef | grep httpd | grep -v grep | wc -l` -eq "0" ] ;
then
	:
	#exit 0
fi

EXISTS=0

CHKFLAG="YES"

PWD=`pwd`


if [ -f "$PWD/vuln2/script/XFIND_RESULT" ]
then
	:
else
	exit
fi


XFIND_RESULT_FILE=`ls $PWD/vuln2/script/XFIND_RESULT`;

while read line ;
do
	APACHE_HTTPD_CONF_LIST=`ls $line | grep "httpd.conf" `
	APACHE_HTTPD_CONF_LIST_CNT=`ls $line | grep "httpd.conf" | wc -l`

	if [ $APACHE_HTTPD_CONF_LIST_CNT -gt "0"  ]
	then
		for APACHE_HTTPD_CONF in $APACHE_HTTPD_CONF_LIST
		do
			#echo "APACHE_HTTPD_CONF=$APACHE_HTTPD_CONF"

			if [ -f "$APACHE_HTTPD_CONF" ] ;
			then
				
				if [ -f "/bin/grep" ]
				then
					DOCUMENT_ROOT_LIST=`/bin/grep -w "^DocumentRoot" "$APACHE_HTTPD_CONF" | /bin/grep -v grep `
				else
					DOCUMENT_ROOT_LIST=`grep "^DocumentRoot" "$APACHE_HTTPD_CONF" | grep -v grep `
				fi
				
				for DOCUMENT_ROOT1 in $DOCUMENT_ROOT_LIST
				do
					#echo "DOCUMENT_ROOT1=$DOCUMENT_ROOT1"
					
					if [ $DOCUMENT_ROOT1 = "DocumentRoot" ] ;
					then
						#skip
						:
					else
						#echo "DOCUMENT_ROOT1=$DOCUMENT_ROOT1"
						
						DOCUMENT_ROOT=`echo $DOCUMENT_ROOT1 | sed 's/"//g'`
						#echo "DOCUMENT_ROOT=$DOCUMENT_ROOT"

       					if [ -d "/org " ]
       					then
           					BACKUP_FILE_LIST=`find $DOCUMENT_ROOT -name "*.tar" -o -name "*.gz" -o -name "*.old*"  -o -name "*_old" -o -name "*.bak*" -o -name "*_bak*" -o -name "*.back" -o -name "*_back" -o -name "/org" 2> /dev/null`
       					else
           					BACKUP_FILE_LIST=`find $DOCUMENT_ROOT -name "*.tar" -o -name "*.gz" -o -name "*.old*"  -o -name "*_old" -o -name "*.bak*" -o -name "*_bak*" -o -name "*.back" -o -name "*_back" 2> /dev/null`
       					fi
				
						#echo "BACKUP_FILE_LIST=$BACKUP_FILE_LIST"
						
        				if [ "$BACKUP_FILE_LIST" = "" ] ;
        				then
							:
						else
							for BACKUP_FILE in $BACKUP_FILE_LIST
            				do
								if [ -f "$BACKUP_FILE" ]
								then
									#echo "BACKUP_FILE=$BACKUP_FILE"
									
               						if [ `echo $BACKUP_FILE | /bin/egrep "tar|gz" | wc -l` -gt "0" ] || [ -d "$BACKUP_FILE" ] ; then
                   						#echo "$BACKUP_FILE" >> $RESULT_FILE 2>&1
										CHKFLAG="NO"
               						fi
								fi
            				done
        				fi

					fi
					
				done # loop DOCUMENT_ROOT_LIST
			
			fi
			
		done # loop APACHE_HTTPD_CONF_LIST
	fi

done < $XFIND_RESULT_FILE





if [ $CHKFLAG = "NO" ]
then
   	echo "  <RESULT>" >> $RESULT_FILE 2>&1
   	echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
   	echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
   	echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
   	echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
   	echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
	
   	echo "    <CONTENT>" >> $RESULT_FILE 2>&1
	#echo "������ Ȩ���丮��  �ǿ밡�ɼ� �ִ� ������� ����, ���� ���("  >> $RESULT_FILE 2>&1
	#echo "Backup file is exist in httpd home directory " >> $RESULT_FILE 2>&1
	#echo "( " >> $RESULT_FILE 2>&1		

	while read line ;
	do
		APACHE_HTTPD_CONF_LIST=`ls $line | grep "httpd.conf" `
		APACHE_HTTPD_CONF_LIST_CNT=`ls $line | grep "httpd.conf" | wc -l`

		if [ $APACHE_HTTPD_CONF_LIST_CNT -gt 0  ]
		then
			for APACHE_HTTPD_CONF in $APACHE_HTTPD_CONF_LIST
			do
				
				if [ -f "$APACHE_HTTPD_CONF" ] ;
				then
				    				    
					if [ -f "/bin/grep" ]
					then
						DOCUMENT_ROOT_LIST=`/bin/grep -w "^DocumentRoot" "$APACHE_HTTPD_CONF" | /bin/grep -v grep `
					else
						DOCUMENT_ROOT_LIST=`grep "^DocumentRoot" "$APACHE_HTTPD_CONF" | /bin/grep -v grep `
					fi
				
					
					# 
					for DOCUMENT_ROOT1 in $DOCUMENT_ROOT_LIST
					do
						if [ $DOCUMENT_ROOT1 = "DocumentRoot" ] ;
						then
							:
						else
						
							DOCUMENT_ROOT=`echo $DOCUMENT_ROOT1 | sed 's/"//g'`

       						if [ -d "/org " ]
       						then
           						BACKUP_FILE_LIST=`find $DOCUMENT_ROOT -name "*.tar" -o -name "*.gz" -o -name "*.old*"  -o -name "*_old" -o -name "*.bak*" -o -name "*_bak*" -o -name "*.back" -o -name "*_back" -o -name "/org" 2> /dev/null`
       						else
           						BACKUP_FILE_LIST=`find $DOCUMENT_ROOT -name "*.tar" -o -name "*.gz" -o -name "*.old*"  -o -name "*_old" -o -name "*.bak*" -o -name "*_bak*" -o -name "*.back" -o -name "*_back" 2> /dev/null`
       						fi
					
        					if [ "$BACKUP_FILE_LIST" ] ;
        					then
								for BACKUP_FILE in $BACKUP_FILE_LIST
            					do
               						if [ `echo $BACKUP_FILE | /bin/egrep "tar|gz" | wc -l` -gt "0" ] || [ -d "$BACKUP_FILE" ] ; then
                   						
										echo "$BACKUP_FILE" >> $RESULT_FILE 2>&1
										
               						fi
            					done	
        					fi
						fi
					done # loop DOCUMENT_ROOT_LIST
    				
				fi
			done # loop APACHE_HTTPD_CONF_LIST
		fi
	done < $XFIND_RESULT_FILE
    
	VULN_RESULT="1"
    #echo ")" >> $RESULT_FILE 2>&1
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1
    
	echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>3</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1
	echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
fi

#######################################################
