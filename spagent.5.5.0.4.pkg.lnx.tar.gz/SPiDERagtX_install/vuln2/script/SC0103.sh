# IGLOO Security Inc.
# ver 3.1.6.3
# last update 2011 Jan 04
# ���ʿ� ���� ����(default ����)
# /etc/passwd�� lp, uucp, nuucp �� ������� ��ȣ

# ��� OS ����

#!/bin/sh

LANG=C
export LANG

IP=$1
ID=$2
RESULT_FILE=$3
CODENAME="SC0103"
VULN_RESULT="0"

#echo "SUBJECT=/etc/passwd ���Ͽ� lp/uucp/nuucp ������ ��ȣ" >> $RESULT_FILE 2>&1

if [ -f /etc/passwd ]
then
    if [ `egrep -i "lp|uucp|nuucp" /etc/passwd | wc -l` -gt 0 ]
    then
        VULN_RESULT="1";
        echo "  <RESULT>" >> $RESULT_FILE 2>&1
        echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
        echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
        echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
        echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
        echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
        
        echo "    <CONTENT> " >> $RESULT_FILE 2>&1
        #echo "/etc/passwd�� ���ʿ��� ��� ���� ����(" >> $RESULT_FILE 2>&1
        echo "/etc/passwd " >> $RESULT_FILE 2>&1
        echo "(" >> $RESULT_FILE 2>&1
        egrep "^lp:|^uucp:|^nuucp:" /etc/passwd | awk -F: '{print "    ID : " $1 }' >> $RESULT_FILE 2>&1 
        echo ")" >> $RESULT_FILE 2>&1 
        echo "    </CONTENT>" >> $RESULT_FILE 2>&1
        
        echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
        echo "    <RISK>1</RISK>" >> $RESULT_FILE 2>&1
        echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
        echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
        echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
        echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
        echo "  </RESULT>" >> $RESULT_FILE 2>&1
    else
        :
    fi
else
    # /etc/passwd ������ �ʼ� ���� �̹Ƿ� ������ ��� �ϴ�
    VULN_RESULT="1"
    echo "  <RESULT>" >> $RESULT_FILE 2>&1
    echo "    <CHECK_ID>`echo $ID`</CHECK_ID>" >> $RESULT_FILE 2>&1
    echo "    <SCANNER_IP>`echo $IP`</SCANNER_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_DB_ID>`echo $CODENAME`</VULN_DB_ID>" >> $RESULT_FILE 2>&1
    echo "    <ASSET_IP>`echo $IP`</ASSET_IP>" >> $RESULT_FILE 2>&1
    echo "    <VULN_PORT></VULN_PORT>" >> $RESULT_FILE 2>&1
    echo "    <PROTOCOL></PROTOCOL>" >> $RESULT_FILE 2>&1
    
    echo "    <CONTENT> " >> $RESULT_FILE 2>&1		
    echo "/etc/passwd ( File not found ) " >> $RESULT_FILE 2>&1		
    echo "    </CONTENT>" >> $RESULT_FILE 2>&1		
    
    echo "    <VULN_RESULT>`echo $VULN_RESULT`</VULN_RESULT>" >> $RESULT_FILE 2>&1
    echo "    <RISK>0</RISK>" >> $RESULT_FILE 2>&1
    echo "    <METHOD></METHOD>" >> $RESULT_FILE 2>&1
    echo "    <EXTEND></EXTEND>" >> $RESULT_FILE 2>&1		
    echo "    <START_DATE>`date '+%Y/%m/%d %H:%M:%S'`</START_DATE>" >> $RESULT_FILE 2>&1
    echo "    <END_DATE>`date '+%Y/%m/%d %H:%M:%S'`</END_DATE>" >> $RESULT_FILE 2>&1
    echo "  </RESULT>" >> $RESULT_FILE 2>&1
    exit
fi

