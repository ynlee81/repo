import base64
import urllib
import uuid
from xml.dom.minidom import Document

from util.cipher import AesCipher, decrypt_data_from_client
from util.const import INSTALL_MODEL
from util.log_helper import get_logger
logger = get_logger()

from dateutil import tz
from django.contrib.auth import authenticate, login
from django.contrib.sites import requests

from account.models import UserEx, GroupEx, AccountDevice
from app.models import LocAppWrapper
from configuration import helper
from configuration.helper import get_ldap_lock, get_ldap_lock_interval, get_remember_passwd
from device.helper import android_get_device_by_udid, ios_get_device_by_udid
from device.models import Android, DEVICE_STATUS_CHECKOUT, IOS
from device.serializers import AndroidSerializer
from engine.api import getUniaNotificationStatus, setUniaNotificationStatus, stop_session, sendAndRecvCmd
from mdm.cmds.helper import install_profile
from mdm.helper import bind_mdm_policy_to_device, get_mdmpolicy_by_device
from portal.api import LoginResponse, ChPwdResponse, GetCfgResponse, \
    StartUniaResponse, GetIOSNotificationResponse, GetAppInfoResponse, GetWallPaperResponse,\
    GetPolicyResponse,LocLoginResponse, GetWaterMarkResponse, GetMdmResponse
from portal.helper import _start_unia, _check_unia_ready,set_block_user, set_login_error_number
from portal.models import VSession, OAuthToken, LocAppToken, AppVersion
from portal.serializers import LoginRequestSerializer, LoginResponseSerializer, \
    StartUniaRequestSerializer, ChPwdRequestSerializer, \
    StartUniaResponseSerializer, ChModeRequestSerializer, \
    ChModeResponseSerializer, GeneralUniaRequestSerializer, \
    ChPwdResponseSerializer, GetCfgResponseSerializer, GetCfgRequestSerializer, CheckUniaRequestSerializer, \
    GetIOSNotificationRequestSerializer, GetIOSNotificationResponseSerializer,GetAppInfoRequestSerializer,\
    GetAppInfoResponseSerializer, SyncPasswordRequestSerializer, GetWallPaperResponseSerializer,\
    UploadDeviceTokenRequestSerializer,CaptureScreenRequestSerializer, LocAppLoginRequestSerializer,\
    LocAppLoginResponseSerializer,GetPolicyResponseSerializer, GetWaterMarkResponseSerializer, GetMdmResponseSerializer, AppVersionSerializer

from requests.auth import HTTPProxyAuth
from rest_framework.views import APIView
from rest_framework import generics
import sys

from report.models import OSInfoReport
from servers.models import Site
from util.general_helper import generalResponse, generalResponseEx
from util.ldap_helper import LDAPHelper
from util.unia_manager import UniaServerManager
from configuration.models import CustomBrand
reload(sys)
sys.setdefaultencoding('utf-8')
from portal.helper import *

# from util.sectools import genRandomStr

class Login(APIView):
    def ldap_login(self, request, data, aes_cipher):
        if enabled_ldap():
            load_ldap_settings()
            if len(data) != 0:
                if data.has_key("os_info"):
                    os_type =  data["os_info"].split(",")[0]
                else:
                    os_type = ""
                if os_type == "ios":
                    if data.has_key("username"):
                        r = get_redis()
                        username = data["username"]
                        usernames = username.split("\\")
                        if len(usernames) > 1:
                            username = usernames[1]
                        r.setex(username, 10, data)
            relay = NtlmRelay(settings.AUTH_LDAP_SERVER_URI)
            relay.logger = logger
            try:
                logger.debug("try to verify ldap password")
                response = relay.authenhandler(request)
                logger.debug("verify result %d" %response.status_code )

                lock_enable, lock_number = get_ldap_lock()
                if response.status_code == status.HTTP_200_OK:
                    r = get_redis()
                    users = User.objects.filter(username = relay.username)
                    unia_status = "1"
                    if len(users) > 0:
                        unia_status = r.hget("user_unia_status", users[0].userex.guid)
                        if unia_status is None:
                            unia_status = "1"
                    if unia_status == "1" and r.ttl("lock_unia_"+relay.username) > 0:
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.UNIA_IS_STOPING, aes_cipher=aes_cipher)
                    response = self.login_django(request, data, aes_cipher, relay.username, relay.username.lower(), request.META['HTTP_USER_AGENT'])
                    if lock_enable:
                        set_login_error_number(relay.username.lower(), 0)
                else:
                    if lock_enable and len(relay.username) > 0:
                        times = int(get_login_error_number(relay.username.lower())) + 1
                        set_login_error_number(relay.username.lower(), times)
                        logger.error("%s login failure %d times" % (relay.username, times))
                        if  times >= lock_number:
                            interval = get_ldap_lock_interval()
                            set_block_user(relay.username.lower(), datetime.timedelta(seconds=interval))
                            logger.error("set block user interval%d" % interval)
                    setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, relay.username, request, LOGTYPE.LOGIN_FAILURE)
                return response
            except SaltTimeoutException:
                logger.exception('login got SaltTimeoutException for user %s' % relay.username)
                return generalResponseCRC(status.HTTP_408_REQUEST_TIMEOUT, ErrorCode.SALT_TIMEOUT, aes_cipher=aes_cipher)
            except Exception:
                logger.exception('login got Exception for user %s' % relay.username)
                setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, relay.username, request, LOGTYPE.LOGIN_FAILURE)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

    def post(self, request, *args, **kargs):
        logger.debug('login post %s' % (str(request.data)))
        auth_type = get_auth_type()

        #data = JSONParser().parse(request)
        data, aes_cipher = decrypt_data_from_client(request.data)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        if auth_type == VMI.AUTH_NTLM:
            return self.ldap_login(request, data, aes_cipher)

        #data = json.loads(request.body)
        serializer = LoginRequestSerializer(data=data)
        username=""
        if serializer.is_valid():
            loginReq = serializer.save()
            password = loginReq.password
            vmi_token = loginReq.token
            _, username = parse_username(loginReq.username)

            users = User.objects.filter(username=username)
            if len(users) > 0:
                user = users[0]
                policy = get_policy_by_user(user)
                user_type = policy.profile_type

                # only vmi user need check
                if user_type == USERTYPE.VMI_USER:
                    r = get_redis()
                    unia_status = r.hget("user_unia_status", user.userex.guid)
                    if unia_status is None:
                        unia_status = "1"
                    if unia_status == "1" and r.ttl("lock_unia_"+username) > 0:
                        logger.debug("lock_unia, return 400")
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.UNIA_IS_STOPING, aes_cipher=aes_cipher)

                user = User.objects.get(username=username)
                if not user.is_active :
                    logger.warn('%s has been disabled' % username)
                    setLogEvent(LOGSTRINGID.USER_DISABLE, username, request, LOGTYPE.LOGIN_FAILURE)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)
                if not user.userex.is_visible:
                    logger.warn('%s is not visible' % username)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)

                if auth_type == VMI.AUTH_OAUTH:
                    if vmi_token is None:
                        logger.warn("OAuth but no token found")
                        setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                    try:
                        oauth = OAuthToken.objects.get(user=user, vmi_token=vmi_token)
                        # todo refresh token if expired
                    except:
                        logger.exception('%s cannot find OAuth' % username)
                        setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                else: # VMI.AUTH_PASSWORD
                    vmi_token = None
                    if enabled_ldap() and ldap_type() == "openldap":
                        load_ldap_settings()
                        ldap_helper = LDAPHelper(settings.AUTH_LDAP_SERVER_URI, settings.AUTH_LDAP_BIND_DN,settings.AUTH_LDAP_BIND_PASSWORD, use_mode=settings.AUTH_LDAP_ACCESS_PROTOCOL)
                        uid = username
                        password = password
                        filter = "(&(objectClass=inetOrgPerson)(uid=" + uid + ")(userPassword=" + to_md5(decode_with_user(user, password, None)) + "))";
                        if len(ldap_helper.search_by_filter(settings.AUTH_LDAP_SEARCH_BASE_DN, filter)) == 0:
                            ldap_helper = LDAPHelper(settings.AUTH_LDAP_SERVER_URI, user.userex.dn, decode_with_user(user, password, None), use_mode=settings.AUTH_LDAP_ACCESS_PROTOCOL)
                            if not ldap_helper.test_bind():
                                # try again for Hefei case
                                ldap_helper = LDAPHelper(settings.AUTH_LDAP_SERVER_URI, user.userex.dn, to_md5(decode_with_user(user, password, None)), use_mode=settings.AUTH_LDAP_ACCESS_PROTOCOL)
                                if not ldap_helper.test_bind():
                                    logger.warn('%s ldap auth failed' % username)
                                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                        password = username # we use username as password for ldap account in local account system
                    else:
                        mode = Configuration.objects.get(group='ldap', name='access_protocol').value
                        if enabled_ldap() and mode == "1":#ssl
                            load_ldap_settings()
                            ldap_helper = LDAPHelper(settings.AUTH_LDAP_SERVER_URI, user=loginReq.username, password=password, use_mode=settings.AUTH_LDAP_ACCESS_PROTOCOL)
                            if not ldap_helper.test_bind():
                                logger.warn('%s ldap auth failed' % username)
                                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL)
                            password = username
            else:
                logger.debug("begin to check need to create user %s, settings.DEMO %s" % (username, settings.DEMO))
                try:
                    if settings.DEMO != 0:
                        user_obj = User.objects.create(username=username, first_name= username)
                        user_obj.set_password(password)
                        user_obj.save()
                        UserEx.objects.create(user=user_obj, guid=uuid.uuid4(), need_change_password=False)
                        try:
                            top_group = GroupEx.objects.get(id=2)
                        except Exception as e:
                            logger.debug(str(e))
                            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                        user_obj.groups.add(top_group.group)
                    else:
                        logger.exception('%s does not exist' % username)
                        setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                except Exception as e:
                    logger.debug(str(e))
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            return self.login_django(request, data, aes_cipher, username, password, request.META['HTTP_USER_AGENT'], loginReq, vmi_token)
        else:
            logger.debug('Invalid input when login')
            #setLogEvent(LOGSTRINGID.INVALID_INPUT, username, request, LOGTYPE.LOGIN_FAILURE)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)


    def login_django(self, request, data, aes_cipher, username, password, user_agent, loginReq=None, vmi_token=None):
        try:
            if loginReq is None:
                if len(data) == 0:
                    logger.debug("no data,triger to get memory")
                    r = get_redis()
                    serializer = LoginRequestSerializer(data=eval(r.get(username)))
                else:
                    serializer = LoginRequestSerializer(data=data)
                #serializer = LoginRequestSerializer(data=request.data)
                if not serializer.is_valid():
                    logger.debug('Invalid input when login_django')
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

                loginReq = serializer.save()
            logger.debug('%s start to login' % username)
            user = authenticate(username=username, password=password, token=vmi_token)

            if user is None:
                setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                logger.warn('%s auth failed' % username)
                lock_enable, lock_number = get_ldap_lock()
                if lock_enable and len(username) > 0:
                    times = int(get_login_error_number(username)) + 1
                    set_login_error_number(username, times)
                    logger.error("%s login failure %d times" % (username, times))
                    if  times >= lock_number:
                        interval = get_ldap_lock_interval()
                        set_block_user(username, datetime.timedelta(seconds=interval))
                        logger.error("set block user interval%d" % interval)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            os_platform = "Android"
            if loginReq.os_info is not None:
                os_platform, os_version= loginReq.os_info.split(",")
                if user.userex.siteinfo is None:
                    site_id = 1
                else:
                    site_id = user.userex.siteinfo.id
                OSInfoReport.objects.create(date_time= datetime.datetime.utcnow().replace(tzinfo=utc), user_id= user.id, \
                    site_id = site_id, os_platform=os_platform, os_version=os_version)

            if user.userex.need_change_password and not isoauth():
                logger.debug('%s need change password' % username)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.UPDATE_PWD_NEEDED, aes_cipher=aes_cipher)

            login(request, user)
            conf = Configuration.objects.get(group="general",name="user_bind")
            enable = is_true_value(conf.value)
            if enable:
                conf = Configuration.objects.get(group="general",name="auto_binding")
                auto_binding = is_true_value(conf.value)
                check_user = AccountDevice.objects.filter(user_id=user.id,device_info = loginReq.device_info, status=1).count()
                device_mode = getDeviceMode(request)
                AccountDevice.objects.filter(device_info=loginReq.device_info,device_mode=None).update(device_mode=device_mode)
                if check_user == 0:
                    block = True
                    if "Android" == os_platform:
                        device_type = 0
                    elif "ios"  == os_platform:
                        device_type = 1
                    else:
                        block = False
                    if block:
                        if auto_binding:
                            count = AccountDevice.objects.filter(user_id=user.id).count()
                            if count == 0:
                                account_device, created = AccountDevice.objects.get_or_create(user_id=user.id, username = username,\
                              email = user.email, device_info=loginReq.device_info, defaults={'device_mode':device_mode, 'device_type':device_type, 'status':1})
                            else:
                                account_device, created = AccountDevice.objects.get_or_create(user_id=user.id, username = username,\
                              email = user.email, device_info=loginReq.device_info, defaults={'device_mode':device_mode, 'device_type':device_type, 'status':0})
                                if created:
                                    SendUnbindMail(username)
                                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.IMEI_BLOCK)
                        else:
                            account_device, created = AccountDevice.objects.get_or_create(user_id=user.id, username = username,\
                              email = user.email, device_info=loginReq.device_info, defaults={'device_mode':device_mode, 'device_type':device_type, 'status':0})
                            
                            if created:
                                SendUnbindMail(username)                        
                            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.IMEI_BLOCK)
            unia_server_manager = UniaServerManager()
            existSession = unia_server_manager.findActiveUniaSession(user)
            if existSession == None:
                user.userex.login_time = datetime.datetime.utcnow().replace(tzinfo=utc)
            user.userex.save()

            session, errorcode, ac_expire = unia_server_manager.createUniaSession(user, user_agent, vmi_token, loginReq.device_token)
            if session is None:
                logger.debug('fail to create session for %s' % (username))
                if errorcode == 1:
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AC_IS_EXPIRE, aes_cipher=aes_cipher)
                elif errorcode == 2:
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.NO_AC, aes_cipher=aes_cipher)
                elif errorcode ==3:
                    setLogEvent(LOGSTRINGID.SERVER_LIMITION, username, request, LOGTYPE.LOGIN_FAILURE)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INSTANCE_LIMITED, aes_cipher=aes_cipher)
                else:
                    logger.debug('server is unavailable')
                    setLogEvent(LOGSTRINGID.SERVER_UNAVAILBALE, username, request, LOGTYPE.LOGIN_FAILURE)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.SERVER_NOT_AVAILABLE, aes_cipher=aes_cipher)

            logger.debug('create session success for %s' % (username))
            demo_flag = None
            if loginReq.demo_flag:
                e_token = encode_with_user(user, session.token,0)
                demo_flag = loginReq.demo_flag
            else:
                e_token = encode_with_user(user, session.token, None)
            logger.debug("%s login success with token: %s, Encrypted token: %s" % (username, debug_info(session.token), debug_info(e_token)))

            policy = get_policy_by_user(user)

            startUniaResp = None
            #just start unia for vmi client without sandbox client
            if policy.profile_type == USERTYPE.VMI_USER:
                if loginReq.locale is not None and loginReq.display is not None:
                    startUniaResp = _start_unia(user, user_agent, loginReq.username, loginReq.locale, session.token, loginReq.display, loginReq.opengl, loginReq.render, demo_flag, None, loginReq.vnc_token)
                    if isinstance(startUniaResp, GeneralResponse):
                        startUniaResp = None
                        return generalResponseCRC(status.HTTP_500_INTERNAL_SERVER_ERROR, ErrorCode.SERVER_NOT_AVAILABLE, aes_cipher=aes_cipher)
            app_info,wall_paper, use_wallpaper = get_app_wallpaper_info(user, loginReq.locale)
            try:
                loc = LocAppToken.objects.get(user = user)
                loc_token = loc.loc_token
            except Exception as e:
                loc_token = get_random_string(32)
                loc = LocAppToken()
                loc.user = user
                loc.loc_token = loc_token
                loc.save()

            watermark_text = policy.watermark_text.strip()
            if policy.watermark_enable:
                if len(watermark_text) == 0:
                    now = user.userex.login_time
                    to_zone = tz.tzlocal()
                    now = now.astimezone(to_zone)
                    watermark_text = "%s %s" % (username, datetime.datetime.strftime(now, "%Y/%m/%d %H:%M:00"))
            if user.userex.siteinfo is not None:
                sa_server = user.userex.siteinfo.sa
            else:
                site = Site.objects.get(id=1)
                sa_server = site.sa

            mdm_status = DEVICE_STATUS_CHECKOUT
            if "ios"  == os_platform and not loginReq.device_udid is None and len(loginReq.device_udid) > 0:
                device = ios_get_device_by_udid(loginReq.device_udid)
                if not device is None and (device.user is None or device.user.id != user.id):
                    mdm_policy_pre = get_mdmpolicy_by_device(device)
                    device.user = user
                    device.save()
                    try:
                        bind_mdm_policy_to_device(device)
                        mdm_policy_now = get_mdmpolicy_by_device(device)
                        if mdm_policy_pre != mdm_policy_now:
                            install_profile(mdm_policy_now, [device.udid])
                            logger.info('apply new mdm_policy %s to ios' % mdm_policy_now)
                    except Exception as e:
                        logger.error('apply ios mdm_policy error for %s' % str(e))
                if device is not None:
                    mdm_status = device.mdm_status
            #judge whether android user change, if change bind the device id to the new user
            logger.debug("find os platform %s device_udid is %s" % (os_platform,loginReq.device_udid))
            if "Android" == os_platform and not loginReq.device_udid is None and len(loginReq.device_udid) > 0:
                device = android_get_device_by_udid(loginReq.device_udid)
                if not device is None and (device.user is None or device.user.id != user.id):
                    mdm_policy_pre = get_mdmpolicy_by_device(device)
                    logger.debug("user change")
                    device.user = user
                    device.save()
                    try:
                        bind_mdm_policy_to_device(device)
                        mdm_policy_now = get_mdmpolicy_by_device(device)
                        if mdm_policy_pre != mdm_policy_now:
                            install_profile(mdm_policy_now, [device.uuid])
                            logger.info('apply new mdm_policy %s to android' % mdm_policy_now)
                    except Exception as e:
                        logger.error('apply android mdm_policy error for %s' % str(e))
                #mdm_status = device.mdm_status
                if not device is None:
                    mdm_status = device.mdm_status
                #mdm_status = device.mdm_status

            sandbox_user = True if policy.profile_type == USERTYPE.SANDBOX_USER else False

            mdm_enable = policy.mdm_enable
            if "ios"  == os_platform:
                try:
                    ret = sendAndRecvCmd(CMD.CMD_PARSE_P12)
                    expire_time = ret['valid_to']
                    if expire_time != "":
                        limittime = datetime.datetime.now()
                        if expire_time < limittime:
                            mdm_enable = False
                    else:
                        mdm_enable = False
                except Exception as e:
                    logger.error('check ios mdm cert error')

            bt_info = None
            if policy.bluetooth_enable_rule == True:
                bt_info = policy.bluetoothrulepolicy_set.all()
            resp = LoginResponse(e_token, session.expire_date, startUniaResp, app_info,user.userex.pw_type,user.userex.pw_hash,wall_paper, loc_token, policy.watermark_enable, watermark_text,sa_server, mdm_enable, mdm_status, sandbox_user, ac_expire, user.userex.sandbox_encryption_key, bt_info, use_wallpaper)
            se = LoginResponseSerializer(resp)
            logger.info('login resp %s, %s' % (username, se.data))

            setLogEvent(LOGSTRINGID.LOGIN_SUCCESS, username, request, LOGTYPE.LOGIN_SUCCESS)
            json_response = JSONResponse(se.data, aes_cipher=aes_cipher, status=status.HTTP_200_OK)
            # logger.info('login resp %s, %s' % (username, json_response))
            return json_response
        except SaltTimeoutException:
            logger.exception('login got SaltTimeoutException for user %s' % username)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.SALT_TIMEOUT, aes_cipher=aes_cipher)
        except Exception:
            logger.exception('login got Exception for user %s' % username)
            setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

class CheckUniaView(APIView):

    def post(self, request, *args, **kargs):
        logger.debug('CheckUniaView %s, %s' % (type(request.data), str(request.data)))
        result, response = handle_ntlm_auth(request)
        if not result:
            return response

        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = CheckUniaRequestSerializer(data=data)

        if serializer.is_valid():
            req = serializer.save()
            _, username = parse_username(req.username)
            logger.debug('check unia request by: %s' % username)
            user = None
            try:
                #user = User.objects.get(username=username)
                users = User.objects.filter(username=username)
                if len(users)>0:
                    user = users[0]
                else:
                    conf = ConfigurationEx.objects.get(group="specialconfig_auth",name = "auth_type")
                    custom_auth = int(conf.value)
                    if custom_auth > 0:
                        serial_number = username
                        uinfo = UserInfo.objects.filter(serial_number = serial_number)
                        if len(uinfo) > 0:
                            username = uinfo[0].user.username
                            user = uinfo[0].user
                if req.demo_flag:
                    token = decode_with_user(user, req.token, 0)
                else:
                    token = decode_with_user(user, req.token, None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            except Exception as e:
                logger.exception('CheckUniaView %s' % str(e))
                logger.exception('%s CheckUniaView got exception' % username)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            redis = get_redis()
            vnc_token = _check_unia_ready(user, token, redis, req.demo_flag)
            if vnc_token is not None:
                code = ErrorCode.SUCCESS
                return JSONResponse({"code": code, "detail": get_error_detail(code), "vnc_token": vnc_token}, aes_cipher, status=status.HTTP_200_OK)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)
        else:
            logger.error('CheckUniaView invalid data')
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

class GetIOSNotificationView(APIView):

    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = GetIOSNotificationRequestSerializer(data=data)

        if serializer.is_valid():
            req = serializer.data
            _, username = parse_username(req['username'])
            logger.debug('get ios notification for user: %s' % username)

            try:
                user = User.objects.get(username=username)
                r = get_redis()
                notification_msg = getUniaNotificationStatus(r, user)
                msg = {}
                msg['status'] =0
                setUniaNotificationStatus(r, user, msg)

                resp = GetIOSNotificationResponse(notification_msg)

                respSerializer = GetIOSNotificationResponseSerializer(resp)
                return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
            except User.DoesNotExist:
                logger.exception('%s get ios notification  got exception' % username)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            except Exception, e:
                logger.exception('%s get ios notification  got exception: %s ' % (username, str(e)))
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

class StartUniaView(APIView):
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = StartUniaRequestSerializer(data=data)

        if serializer.is_valid():
            req = serializer.save()
            _, username = parse_username(req.username)
            logger.debug('start unia request by: %s' % username)

            try:
                user, username = getUserByName(username)
                token = decode_with_user(user, req.token, None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            except User.DoesNotExist:
                logger.exception('%s StartUniaView got exception' % username)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            resp = _start_unia(user, request.META['HTTP_USER_AGENT'], req.username, req.locale, token, req.display, req.opengl, \
                               req.render, None, None, None)
            if isinstance(resp, GeneralResponse):
                return generalResponseCRC(status.HTTP_500_INTERNAL_SERVER_ERROR, ErrorCode.SERVER_NOT_AVAILABLE, aes_cipher=aes_cipher)
            else:
                respSerializer = StartUniaResponseSerializer(resp)
                return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)

class StopUniaView(APIView):
    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response

        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = GeneralUniaRequestSerializer(data=data)

        if serializer.is_valid():
            req = serializer.save()
            try:
                _, username = parse_username(req.username)
                r = get_redis()
                r.setex("lock_unia_"+username, 15, None)
                user, username = getUserByName(username)
                logger.debug('stop unia request by: %s' % username)

                if req.demo_flag:
                    token = decode_with_user(user, req.token, 0)
                else:
                    token = decode_with_user(user, req.token, None)
                if not verifyToken(user, token):
                    setLogEvent(LOGSTRINGID.LOGOUT_AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGOUT_FAILURE)
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                stop_session(user, token)
                setLogEvent(LOGSTRINGID.LOGOUT_SUCCESS, username, request, LOGTYPE.LOGOUT_SUCCESS)
                return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
            except User.DoesNotExist:
                logger.exception('%s StopUniaView got exception', req.username)
                setLogEvent(LOGSTRINGID.LOGOUT_AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGOUT_FAILURE)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

class SuspendUniaView(APIView):
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = GeneralUniaRequestSerializer(data=data)
        if serializer.is_valid():
            req = serializer.data
            try:
                _, username = parse_username(req['username'])
                logger.debug('suspend unia request by: %s' % username)
                user = User.objects.get(username=username)
                token = decode_with_user(user, req['token'], None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                sendAndRecvCmd(CMD.CMD_SUSPEND_UNIA, agent_server_id=user.userex.last_server_id, username=username, token=token)
                return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
            except User.DoesNotExist:
                logger.exception('%s SuspendUniaView got exception', req['username'])
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

class ResumeUniaView(APIView):
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = GeneralUniaRequestSerializer(data=data)
        if serializer.is_valid():
            req = serializer.data
            try:
                _, username = parse_username(req['username'])
                logger.debug('resume unia request by: %s' % username)
                user = User.objects.get(username=username)
                token = decode_with_user(user, req['token'], None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                sendAndRecvCmd(CMD.CMD_RESUME_UNIA, agent_server_id=user.userex.last_server_id, username=username, token=token)
                return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
            except User.DoesNotExist:
                logger.exception('%s ResumeUniaView got exception', req['username'])
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

class ChPwdView(APIView):
    def getNewPwd(self, key, msg):
        if get_encryption() == VMI.ENCRYPTION_NONE:
            return msg

        cipher = AesCipher(key)
        omsg = cipher.decrypt(msg)
        rpos = omsg.rfind('$')
        pwd_timestamp = omsg[0:rpos]
        rpos = pwd_timestamp.rfind('$')  # # to avoid the issue which passwd contains $
        pwd = pwd_timestamp[0:rpos]
        return pwd

    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response

        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)

        if enabled_ldap():
            logger.warn('Not allowed to change password for ldap user')
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.NOT_ALLOWED, aes_cipher=aes_cipher)
        serializer = ChPwdRequestSerializer(data=data)

        if serializer.is_valid():
            req = serializer.data
            _, username = parse_username(req['username'])

            user = None
            try:
                user, username = getUserByName(username)
                if not user.is_active:
                    logger.warn('%s has been disabled' % username)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)
            except:
                logger.exception('%s does not exist' % username)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            ############# for demo
            if get_encryption() == VMI.ENCRYPTION_NONE:
                pwd = req['oldpasswd']
                newPwd = req['newpasswd']
                user = authenticate(username=username, password=pwd)
            else:
                try:
                    user = authenticate(username=username, password=req['oldpasswd'])
                except SaltTimeoutException:
                    logger.exception('%s ChPwdView got exception' % username)
                    return generalResponseCRC(status.HTTP_408_REQUEST_TIMEOUT, ErrorCode.SALT_TIMEOUT, aes_cipher=aes_cipher)

            if user is not None:
                key = get_pwd_from_user(user)
                newPwd = self.getNewPwd(key, req['newpasswd'])
                user.set_password(newPwd)
                user.last_login = datetime.datetime.utcnow().replace(tzinfo=utc)
                user.userex.need_change_password = False
                user.save()
                timestamp = datetime.datetime.now()
                user.userex.login_time = datetime.datetime.utcnow().replace(tzinfo=utc)
                user.userex.save()

                unia_server_manager = UniaServerManager()
                session, errorcode, ac_expire = unia_server_manager.createUniaSession(user, request.META['HTTP_USER_AGENT'])
                if session is None:
                    if errorcode == 1:
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AC_IS_EXPIRE, aes_cipher=aes_cipher)
                    elif errorcode == 2:
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.NO_AC, aes_cipher=aes_cipher)
                    else:
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INSTANCE_LIMITED, aes_cipher=aes_cipher)

                e_token = encode_with_user(user, session.token, None)
                resp = ChPwdResponse(e_token, getSalt(user.password), timestamp)
                se = ChPwdResponseSerializer(resp)
                logger.debug('%s change passward success' % username)
                return JSONResponse(se.data, aes_cipher, status=status.HTTP_200_OK)
            else:
                logger.warn('%s change passward failed. auth failed, aes_cipher %s' % (username, aes_cipher))
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

class ChModeView(APIView):
    """
    Not used
    """
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = ChModeRequestSerializer(data=data)
        if serializer.is_valid():
            req = serializer.data
            _, username = parse_username(req['username'])
            try:
                user = User.objects.get(username=username)
                token = decode_with_user(user, req['token'], None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                cmd = ChModeCmd(username, token, req['display'])
                resp = BaseCmd.sendAndReceive(cmd)
                if isinstance(resp, GeneralResponse):
                    logger.warn('%s ChModeView failed return %d: %s' % (username, resp.code, resp.detail))
                    return generalResponseEx(resp)
                else:
                    respSerializer = ChModeResponseSerializer(resp)
                    logger.debug('%s ChModeView success' % (username,))
                    return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
            except Exception:
                logger.exception('%s ChModeView got exception' % username)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        else:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)


class GetCfgView(APIView):
    def post(self, request, *args, **kargs):
        try:
#             for k, v in request.META.iteritems():
#                 logger.debug("%s: %s"%(k, v))
            logger.debug('getcfg post %s' % request.data)
            aes_cipher = None
            result, response = handle_ntlm_auth(request)
            if not result:
                return response
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                logger.warn('decrypt data fail')
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            serializer = GetCfgRequestSerializer(data=data)
            if serializer.is_valid():
                timestamp = datetime.datetime.utcnow().replace(tzinfo=utc)
                remember_passwd = get_remember_passwd()
                salt = None
                username = None

                req = serializer.save()
                encryption = get_encryption()
                if req.demo_flag:
                    if settings.DEMO != 0:
                        encryption = VMI.ENCRYPTION_NONE
                        logger.debug("skip username for demo.")
                else:
                    if req.username and len(req.username) > 0:
                        _, username = parse_username(req.username)
                        logger.debug('%s try to get config' % username)
                        users = User.objects.filter(username=username)
                        if len(users) > 0:
                            user = users[0]
                            user.userex.timestamp = timestamp
                            user.userex.save()
                            salt = getSalt(user.password)

                            lock_enable, lock_number = get_ldap_lock()
                            error_number = 0
                            if not lock_enable:
                                lock_number = 0
                                logger.error("lock disable")
                            else:
                                ret = get_block_user(username.lower())
                                if ret == -1 or ret == -2: # -2 means not set thie key
                                    #set_login_error_number(username.lower(), 0)
                                    pass
                                else:
                                    interval = ret
                                    logger.error("block user %d seconds" % interval)
                                    set_login_error_number(username.lower(), 0)
                                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.LDAP_LOCK_TIMEOUT, interval, aes_cipher=aes_cipher)
                        else:
                            username = None
                    else:
                        logger.debug("getcfg without username")

                auth_type = get_auth_type()
                single_app, package, code_list = get_singleapp_config()
                if single_app == 0:
                    if username is not None:
                        single_app, package = get_global_singleapp_config(user)
                    else:
                        package = Package(None, None, None)
                    code_list = None
                if single_app > 0 or auth_type==VMI.AUTH_OAUTH or enabled_ldap():
                    change_password=False
                else:
                    change_password=True

                conf = Configuration.objects.get(group='server', name='guid')
                server_guid = conf.value
                if len(server_guid) == 0:
                    server_guid = uuid.uuid4()
                    conf.value = server_guid
                    conf.save()
                p_level = Configuration.objects.get(group="general",name="password_level")
                conf = Configuration.objects.get(group="unia_cfg", name="anti_screen")
                anti_screen = conf.value
                root_or_jailbreak_char = Configuration.objects.get(group="unia_cfg", name="root_or_jailbreak").value
                root_or_jailbreak = 0
                if root_or_jailbreak_char.lower() == 'true':
                    root_or_jailbreak = 1
                shaconf = Configuration.objects.get(group="loc_wrap",name="sha1")
                sha1 = shaconf.value
                confs = ConfigurationEx.objects.filter(group="specialconfig_auth")
                custom_auth = 0
                custom_auth_url = None
                authorize_uri = None
                for conf in confs:
                    if conf.name == "auth_type":
                        custom_auth = int(conf.value)
                    if conf.name == "ca_url":
                        custom_auth_url = conf.value
                    if conf.name == 'authorize_uri':
                        authorize_uri = conf.value
                conf = Configuration.objects.get(group="unia_mode", name="mode_change")
                is_native_dpi = is_true_value(conf.value)
                #is_native_dpi = True
                if req.version_flag is not None:
                    version_flag = 5
                else:
                    version_flag = 0
                ui_script = [
                {
                    "className":"TMAccountView",
                    "parameter":{"placeHolder":"User name", 
                                 "key":"username","isRequired":1},
                    "method":"updateParameter"},
                {
                    "className":"TMPwdView",
                    "parameter":{"passwordPlaceHolder":"Password",
                                   "rememberPlaceHolder":"Remember password",
                                   "showRememberMe":0,
                                   "key":"password",
                                   "isRequired":1},
                    "method":"updateParameter"
                }]
                client_img = {}
                brand = CustomBrand.objects.filter(apply_status=1)
                banner_img = settings.BANNER_IMG
                banner_txt = settings.BANNER_TEXT 
                logo_img = settings.LOGO_IMG
                banner_sha = settings.BANNER_IMG_SHA
                logo_sha = settings.LOGO_IMG_SHA
                tp_logo_img = settings.TRANSPARENT_LOGO_IMG
                tp_logo_sha = settings.TRANSPARENT_LOGO_IMG_SHA
                product_name = 'Virtual Mobile Infrastructure'
                download_apk = settings.DOWNLOAD_APK
                license_url = "license.htm"                
                if len(brand) > 0:
                    banner_img = brand[0].banner_image_path
                    banner_txt = brand[0].banner_text
                    logo_img = brand[0].logo_image_path
                    banner_sha = brand[0].banner_image_sha
                    logo_sha = brand[0].logo_image_sha
                    product_name = brand[0].product_name
                    tp_logo_img = "" if brand[0].t_logo_image_path is None else brand[0].t_logo_image_path
                    tp_logo_sha = "" if brand[0].t_logo_image_sha is None else brand[0].t_logo_image_sha
                    if brand[0].license_url == None:
                        license_url = "license.htm"
                    else:                        
                        license_url = brand[0].license_url
                client_img['banner_image'] = banner_img
                client_img['banner_text'] = banner_txt
                client_img['logo_image'] = logo_img
                client_img['banner_image_sha'] = banner_sha
                client_img['logo_image_sha'] = logo_sha
                client_img['product_name']= product_name
                client_img['download_apk'] = download_apk
                client_img['tp_logo_img'] = tp_logo_img
                client_img['tp_logo_image_sha'] = tp_logo_sha
                client_license_url = license_url
                conf = Configuration.objects.get(group="general",name="graphic_quality")
                graphic_quality = int(conf.value) 
                conf = Configuration.objects.get(group="general",name="user_bind")
                device_bind = is_true_value(conf.value)
                conf = Configuration.objects.get(group="general",name="enable_csr")
                enable_csr = is_true_value(conf.value)
                conf = Configuration.objects.get(group="general",name="wifi_block")
                wifi_block = is_true_value(conf.value)
                security_keypad_key = Configuration.objects.get(group="krc",name="security_keypad_key").value
                resp = GetCfgResponse(settings.VMIM['api_url_prefix'], salt, timestamp, encryption, get_self_host(request), \
                                      3, remember_passwd.enabled, anti_screen, auth_type,settings.CUSTOMIZE, \
                                      single_app, package, code_list, change_password,server_guid, \
                                      int(p_level.value), sha1, root_or_jailbreak, custom_auth, \
                                      custom_auth_url, is_native_dpi, version_flag, ui_script, client_img, \
                                      graphic_quality,device_bind, enable_csr,client_license_url,settings.TAG, wifi_block, security_keypad_key)
                se = GetCfgResponseSerializer(resp)
                logger.debug('%s get config success, ret %s' % (username, jsonpickle.encode(se.data)))
                return JSONResponse(se.data, aes_cipher, status=status.HTTP_200_OK)
            else:
                logger.debug("wrong request %s"%str(serializer.errors))
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)
        except User.DoesNotExist as e:
            logger.exception(e)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        except Exception:
            logger.exception('GetCfgView got exception')
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

class AddressRangeView(APIView):
    def get(self, request, *args, **kargs):
        sa_address = request.META.get("REMOTE_ADDR", None)
        conf = Configuration.objects.get(group='apns', name='sa_address')
        if conf.value is None or conf.value == "":
            logger.info("sa address is %s" % sa_address)
            conf.value = sa_address
            conf.save()
        ips = ""
        ports = "5901"
        has_nat = False
        for i in Server.objects.filter(Q(model=INSTALL_MODEL.HYBRID) | Q(model=INSTALL_MODEL.UNIA)):
            if i.isUniaServerRunning():
                if i.nat_disable:
                    logger.debug("IP Range mode not support!")
                else:
                    has_nat = True
                    ip = i.ifs[0]["ip"]

                if len(ips) == 0:
                    ips = ip
                else:
                    ips += ";%s" % ip

        for vip in hastate.objects.all():
            ips += ";%s" % vip.virt_ip

        if has_nat:
            port = Configuration.objects.get(group = "unia_config", name = "port_range")
            ports = "%s-%s" % (int(port.value), int(port.value) + 1023)
            #ports = "5900-6923"

        return JSONResponse({"ips": ips, "ports": ports}, status=status.HTTP_200_OK)

class OAuthCallbackView(APIView):
    def get(self, request, *args, **kargs):
        if not isoauth():
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.NOT_SUPPORTED)

        error = request.query_params.get("error", None)
        state = request.query_params.get("state", None)
        code = request.query_params.get("code", None)
        ret = sendAndRecvCmd(CMD.CMD_GET_TOKEN, error=error, code=code, state=state)
        tmsmw_uri = ret.get("tmsmw_uri")
        error = ret.get("error")
        if error is not None:
            logger.warn("OAuthCallbackView error: %s" % (error, ))
            return VmiResponseRedirect("%s?error=%s&state=%s" % (tmsmw_uri, error, state))

        username = ret.get("username")
        logger.debug("OAuthCallbackView success for %s"%username)
        return VmiResponseRedirect("%s?code=%s&state=%s&username=%s" % (tmsmw_uri, code, state, username))

class GetPlistView(APIView):
    def get(self, request, *args, **kargs):
        plist = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>items</key>
    <array>
        <dict>
            <key>assets</key>
            <array>
                <dict>
                    <key>kind</key>
                    <string>software-package</string>
                    <key>url</key>
                    <string>%(host)s/iUnia.ipa</string>
                </dict>
            </array>
            <key>metadata</key>
            <dict>
                <key>bundle-identifier</key>
                <string>com.trendmicro.iUnia</string>
                <key>bundle-version</key>
                <string>1.0</string>
                <key>kind</key>
                <string>software</string>
                <key>title</key>
                <string>tmsmw</string>
            </dict>
        </dict>
    </array>
</dict>
</plist>
'''
        return HttpResponse(plist % {"host":get_self_host(request, True)}, content_type="application/x-plist")

class GetAppInfoView(APIView):
    def post(self, request, *args, **kargs):
        #result, response = handle_ntlm_auth(request)
        #if not result:
#            return response
        logger.debug('begin get app info...')
        try:
            data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            _, username = parse_username(data["username"])
            locale = data["locale"]
        except Exception as e:
            logger.debug(str(e))
        try:
            user, username = getUserByName(username)
            app_info, wallpaper, use_wallpaper = get_app_wallpaper_info(user, locale)
            resp = GetAppInfoResponse(app_info)
            respSerializer = GetAppInfoResponseSerializer(resp)
            return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            logger.exception('%s not exist.' % username)
            return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        except Exception, e:
            logger.exception('%s get app info  got exception: %s ' % (username, str(e)))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

class GetWallPaperView(APIView):
    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        _, username = parse_username(data["username"])
        try:
            user, username = getUserByName(username)
            app_info, wallpaper, use_wallpaper = get_app_wallpaper_info(user, None, False)
            resp = GetWallPaperResponse(wallpaper, use_wallpaper)
            respSerializer = GetWallPaperResponseSerializer(resp)
            return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            logger.exception('%s not exist.' % username)
            return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        except Exception, e:
            logger.exception('%s get app info  got exception: %s ' % (username, str(e)))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

class UpdateDeviceTokenView(APIView):
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = UploadDeviceTokenRequestSerializer(data=data)
        if serializer.is_valid():
            req = serializer.save()
            try:
                _, username = parse_username(req.username)
                logger.debug('update device token request by: %s' % username)
                logger.debug("UploadDeviceTokenRequestSerializer %s" % serializer.data)
                user = User.objects.get(username=username)
                if req.demo_flag:
                    token = decode_with_user(user, req.token, 0)
                else:
                    token = decode_with_user(user, req.token, None)

                # logger.debug('token: %s, device_token %s' % (token, req.device_token))
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                VSession.objects.filter(user__username=username, token=token).update(device_token=req.device_token)
                if req.udid is not None:
                    IOS.objects.filter(udid=req.udid).update(device_token=req.device_token)
                return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
            except User.DoesNotExist:
                logger.exception('%s UpdateDeviceTokenView got exception', req.username)
                return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        else:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

class SyncPasswordView(APIView):

    def post(self, request, *args, **kargs):
        try:
            data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            # logger.debug("SyncPasswordView data %s" % data)
            serializer = SyncPasswordRequestSerializer(data=data)
            if serializer.is_valid():
                syncpwReq = serializer.data
                _, username = parse_username(syncpwReq["username"])
                logger.debug("SyncPasswordView serializer data %s, username %s" % (data, username))
                user = None
                try:
                    users = User.objects.filter(username=username)
                    if len(users)>0:
                        user = users[0]
                    else:
                        conf = ConfigurationEx.objects.get(group="specialconfig_auth",name = "auth_type")
                        custom_auth = int(conf.value)
                        if custom_auth > 0:
                            serial_number = username
                            uinfo = UserInfo.objects.filter(serial_number = serial_number)
                            if len(uinfo) > 0:
                                username = uinfo[0].user.username
                                user = uinfo[0].user
                    if not user.is_active :
                        logger.warn('%s has been disabled' % username)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)
                    if not user.userex.is_visible:
                        logger.warn('%s is not visible' % username)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)
                except:
                    logger.exception('%s does not exist' % username)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                logger.debug('%s start to sync pw' % username)
                token = syncpwReq["token"]
                if syncpwReq.has_key("demo_flag") and syncpwReq["demo_flag"] !=0:
                    token = decode_with_user(user, token, 0)
                else:
                    token = decode_with_user(user, token, None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                user.userex.pw_type = syncpwReq["lock_pw_type"]
                user.userex.pw_hash = syncpwReq["lock_pw_hash"]
                user.userex.save()
                return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
        except Exception as e:
            logger.debug(str(e))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)


class CaptureScreenView(APIView):
    def post(self, request, *args, **kargs):
        data, aes_cipher = decrypt_data_from_client(request.data) #JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
        serializer = CaptureScreenRequestSerializer(data=data)
        if serializer.is_valid():
            capReq = serializer.data
            _, username = parse_username(capReq["username"])
            setLogEvent(LOGSTRINGID.CAPTURESCREEN, username, request, LOGTYPE.CAPTURESCREEN)
            return generalResponseCRC(status.HTTP_200_OK, ErrorCode.SUCCESS, aes_cipher=aes_cipher)
        else:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)

class LocApp_LoginView(APIView):
    def ldap_login(self, request, data, aes_cipher):
        if enabled_ldap():
            load_ldap_settings()
            if len(data) != 0:
                if data.has_key("username"):
                    r = get_redis()
                    username = data["username"]
                    usernames = username.split("\\")
                    if len(usernames) > 1:
                        username = usernames[1]
                    r.setex(username, 10, data)

            relay = NtlmRelay(settings.AUTH_LDAP_SERVER_URI)
            relay.logger = logger
            try:
                logger.debug("try to verify ldap password")
                response = relay.authenhandler(request)
                logger.debug("verify result %d" %response.status_code )

                lock_enable, lock_number = get_ldap_lock()
                if response.status_code == status.HTTP_200_OK:
                    response = self.login_django(request, data, aes_cipher, relay.username, relay.username.lower(), request.META['HTTP_USER_AGENT'])
                    if lock_enable:
                        set_login_error_number(relay.username.lower(), 0)
                else:
                    if lock_enable and len(relay.username) > 0:
                        times = int(get_login_error_number(relay.username.lower())) + 1
                        set_login_error_number(relay.username.lower(), times)
                        logger.error("%s login failure %d times" % (relay.username, times))
                        if  times >= lock_number:
                            interval = get_ldap_lock_interval()
                            set_block_user(relay.username.lower(), datetime.timedelta(seconds=interval))
                            logger.error("set block user interval%d" % interval)
                    setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, relay.username, request, LOGTYPE.LOGIN_FAILURE)
                return response
            except SaltTimeoutException:
                logger.exception('login got SaltTimeoutException for user %s' % relay.username)
                return generalResponseCRC(status.HTTP_408_REQUEST_TIMEOUT, ErrorCode.SALT_TIMEOUT, aes_cipher=aes_cipher)
            except Exception:
                logger.exception('login got Exception for user %s' % relay.username)
                setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, relay.username, request, LOGTYPE.LOGIN_FAILURE)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

    def get(self, request, *args, **kargs):
        if enabled_ldap():
            return self.ldap_login(request, request.data, None)


    def post(self, request, *args, **kargs):
        auth_type = get_auth_type()
        data, aes_cipher = decrypt_data_from_client(request.data)  # JSONParser().parse(request)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)

        if auth_type == VMI.AUTH_NTLM:
            return self.ldap_login(request, data, aes_cipher)

        username = ''
        serializer = LocAppLoginRequestSerializer(data=data)
        if serializer.is_valid():
            loginReq = serializer.save()
            _, username = parse_username(loginReq.username)
            r = get_redis()
            password = loginReq.password
            vmi_token = loginReq.token
            user = None
            try:
                user = User.objects.get(username=username)
                if not user.is_active :
                    logger.warn('%s has been disabled' % username)
                    setLogEvent(LOGSTRINGID.USER_DISABLE, username, request, LOGTYPE.LOGIN_FAILURE)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)
                if not user.userex.is_visible:
                    logger.warn('%s is not visible' % username)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.USER_DISABLED, aes_cipher=aes_cipher)

                if auth_type == VMI.AUTH_OAUTH:
                    if vmi_token is None:
                        logger.warn("OAuth but no token found")
                        setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

                    try:
                        oauth = OAuthToken.objects.get(user=user, vmi_token=vmi_token)
                    except:
                        logger.exception('%s cannot find OAuth' % username)
                        setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                else: # VMI.AUTH_PASSWORD
                    vmi_token = None
                    if enabled_ldap() and ldap_type() == "openldap":
                        load_ldap_settings()
                        ldap_helper = LDAPHelper(settings.AUTH_LDAP_SERVER_URI, settings.AUTH_LDAP_BIND_DN,settings.AUTH_LDAP_BIND_PASSWORD, use_mode=settings.AUTH_LDAP_ACCESS_PROTOCOL)
                        uid = username
                        password = password
                        filter = "(&(objectClass=inetOrgPerson)(uid=" + uid + ")(userPassword=" + to_md5(decode_with_user(user, password, None)) + "))";
                        if len(ldap_helper.search_by_filter(settings.AUTH_LDAP_SEARCH_BASE_DN, filter)) == 0:
                            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                        password = username
            except:
                logger.exception('%s does not exist' % username)
                setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            return self.login_django(request, data, aes_cipher, username, password, request.META['HTTP_USER_AGENT'], loginReq, vmi_token)
        else:
            logger.debug('Invalid input when login')
            setLogEvent(LOGSTRINGID.INVALID_INPUT, username, request, LOGTYPE.LOGIN_FAILURE)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)


    def login_django(self, request, data, aes_cipher, username, password, user_agent, loginReq=None, vmi_token=None):
        try:
            if loginReq is None:
                if len(data) == 0:
                    logger.debug("no data,triger to get memory")
                    r = get_redis()
                    serializer = LocAppLoginRequestSerializer(data=eval(r.get(username)))
                else:
                    serializer = LocAppLoginRequestSerializer(data=data)

                if not serializer.is_valid():
                    logger.debug('Invalid input when login_django')
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT, aes_cipher=aes_cipher)
                loginReq = serializer.save()
            logger.debug('%s start to login' % username)
            user = authenticate(username=username, password=password, token=vmi_token)
            policy = get_policy_by_user(user)

            if user is None:
                setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
                logger.warn('%s auth failed' % username)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            if user.userex.need_change_password and not isoauth():
                logger.debug('%s need change password' % username)
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.UPDATE_PWD_NEEDED, aes_cipher=aes_cipher)

            login(request, user)

            conf = Configuration.objects.get(group="general",name="user_bind")
            enable = is_true_value(conf.value)
            if enable:
                os_platform = "Android"
                if loginReq.os_info is not None:
                    os_platform, os_version= loginReq.os_info.split(",")
                check_user = AccountDevice.objects.filter(user_id=user.id,device_info = loginReq.device_info, status=1).count()
                device_mode = getDeviceMode(request)
                AccountDevice.objects.filter(device_info=loginReq.device_info,device_mode=None).update(device_mode=device_mode)
                if check_user == 0:
                    block = True
                    if "Android" == os_platform:
                        device_type = 0
                    elif "ios"  == os_platform:
                        device_type = 1
                    else:
                        block = False
                    if block:
                        account_device, created = AccountDevice.objects.get_or_create(user_id=user.id, username = username,\
                          email = user.email, device_info=loginReq.device_info, defaults={'device_mode':device_mode, 'device_type':device_type, 'status':0})
                        if created:
                            SendUnbindMail(username)
                        return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.IMEI_BLOCK, aes_cipher=aes_cipher)

            apps = policy.local_apps.filter(package=loginReq.app_id)
            if len(apps) == 0:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.APP_REMOVE, aes_cipher=aes_cipher)
            app = apps[0]
            if app.enable == 0:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.APP_DISABLE, aes_cipher=aes_cipher)

            try:
                loc = LocAppToken.objects.get(user = user)
                loc_token = loc.loc_token
            except Exception as e:
                loc_token = get_random_string(32)
                loc = LocAppToken()
                loc.user = user
                loc.loc_token = loc_token
                loc.save()
            error_code = 0

            newversion_list = app.version.split(".")
            version_list = loginReq.app_version.split(".")
            app_info = {}
            if len(version_list) > 1:
                for i in range(len(newversion_list)):
                    if i >= len(version_list):
                        break
                    if version_list[i] < newversion_list[i]:
                        error_code = 1
                        break
            else:
                if int(version_list[0]) != int(app.version_code):
                    error_code = 1

            html_parser = HTMLParser.HTMLParser()
            app_info["id"] = app.id
            app_info["package"] = app.package
            app_info["name"] = html_parser.unescape(app.name)
            if app.icon == "":
                app_info["icon"] = ""
            else:
                app_info["icon"] = app.icon.url
            app_info["type"] = app.app_type + 1
            app_info["download_url"] = app.file.url
            app_info["open_url"] = app.open_url
            app_info["version_code"] = int(app.version_code)
            app_info["size"] = app.size
            app_info["version"] = app.version
            logger.debug("%s login success with Encrypted token: %s" % (username, debug_info(loc_token)))

            resp = LocLoginResponse(loc_token, error_code, app_info)
            se = LocAppLoginResponseSerializer(resp)
            setLogEvent(LOGSTRINGID.LOGIN_SUCCESS, username, request, LOGTYPE.LOGIN_SUCCESS)
            return JSONResponse(se.data, aes_cipher, status=status.HTTP_200_OK)
        except SaltTimeoutException:
            logger.exception('login got SaltTimeoutException for user %s' % username)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.SALT_TIMEOUT, aes_cipher=aes_cipher)
        except Exception:
            logger.exception('login got Exception for user %s' % username)
            setLogEvent(LOGSTRINGID.AUTHENTICATION_FAIL, username, request, LOGTYPE.LOGIN_FAILURE)
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

class GetPolicyView(APIView):
    '''
    api/v1/portal/wrap_action
    {
    "action": 0          //     0,get policy, 1 set audit log
    "package_name":"com.example.android.apprestrictionschema",  //android may not have this field
    "version":"1.0",    //android may not have this field
    "token":xxxxxx,
    "log":xxxxxxxxxxxxxxx,
    "os": 0   // 0,ios  1,android
    "username":*********
    }

    '''
    def post(self, request, *args, **kargs):
        try:
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            original_username = data.get("username", None)
            action = data["action"]
            package_name = data.get("package_name", None)  # ios only
            loc_token = data["token"]
            os_type = data["os"]

            _, username = parse_username(original_username)
            user = User.objects.get(username=username)
            policy = get_policy_by_user(user)
            #android client use vmi token to verify
            if os_type == 1:
                token = decode_with_user(user, loc_token, None)
                if not verifyToken(user, token):
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            else:   #ios client use original loctoken to verify
                if LocAppToken.objects.filter(loc_token = loc_token).count() == 0:
                    logger.exception('%s cannot find token' % package_name)
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
            app = None
            if os_type == 0:
                apps = policy.local_apps.filter(package = package_name)
                if len(apps) == 0:
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                app = apps[0]
                if app is None or app.enable == 0:
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)

            if action == 1:
                log = data["log"]
                if request.META.has_key('HTTP_USER_AGENT'):
                    device = urllib.unquote(request.META['HTTP_USER_AGENT'])
                else:
                    device = ""
                reldevice = device
                if deviceCode.has_key(device):
                    reldevice = deviceCode[device]
                loc = LocAppToken.objects.get(loc_token = loc_token)
                username = loc.user.username

                EventLog.objects.create(datetime= datetime.datetime.utcnow().replace(tzinfo=utc), username= username, description= log, device=reldevice, type= 0)
                return Response(status=status.HTTP_200_OK)
            elif action == 0:
                version = data.get("version", None)  #android may not have this field
                xml = None
                if os_type == 0:
                    if version is not None:
                        newversion_list = app.version.split(".")
                        version_list = version.split(".")
                        if len(version_list) > 1:
                            for i in range(len(newversion_list)):
                                if i >= len(version_list):
                                    break
                                if version_list[i] < newversion_list[i]:
                                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                        else:
                            if int(version_list[0]) != int(app.version_code):
                                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
                    xml = app.pre_config

                security_setting = policy.sandbox_security_setting
                if policy.profile_type != USERTYPE.SANDBOX_USER or security_setting is None:
                    return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.NOT_EXISTED, aes_cipher=aes_cipher)

                dom = Document()
                roots = dom.createElement('Policy')
                root = dom.createElement('Security')

                restrict = dom.createElement('restrict_cut')
                restrict.setAttribute("value",str(security_setting.restrict_cut))
                root.appendChild(restrict)
                block = dom.createElement("block_clipboard")   #add for android
                block.setAttribute("value", str(security_setting.restrict_cut))
                root.appendChild(block)
                restrict_s = dom.createElement('restrict_share')
                restrict_s.setAttribute("value",str(security_setting.restrict_share))
                root.appendChild(restrict_s)
                restrict_c = dom.createElement('restrict_capture')
                restrict_c.setAttribute("value",str(security_setting.restrict_capture))
                root.appendChild(restrict_c)
                enforce = dom.createElement('enforce_encryption')
                enforce.setAttribute("value",str(security_setting.enforce_encryption))
                root.appendChild(enforce)
                encrypt_f = dom.createElement("encrypt_file")
                encrypt_f.setAttribute("value", str(security_setting.encrypt_file))
                root.appendChild(encrypt_f)

                offline = dom.createElement('offline_period')
                offline.setAttribute("value",str(security_setting.offline_period))
                root.appendChild(offline)

                root_c = dom.createElement('root_check')
                root_c.setAttribute("value",str(security_setting.root_check))
                root.appendChild(root_c)

                #wipe action
                wipe = dom.createElement('wipe')
                wipe.setAttribute("value", str(user.userex.wipe))
                root.appendChild(wipe)
                #just wipe once
                if user.userex.wipe:
                    user.userex.wipe = False
                    user.userex.save()

                dom.appendChild(roots)
                roots.appendChild(root)
                if os_type == 1:  #android
                    resp = GetPolicyResponse(dom.toxml(encoding="utf-8")[:-9] + "</Policy>")
                    #resp = GetPolicyResponse(dom.toxml(encoding="utf-8")[:-9]+xml[22:] + "</Policy>")
                else:
                    resp = GetPolicyResponse(dom.toxml(encoding="utf-8")[:-9]+ "<plist>" + base64.encodestring(xml) +"</plist>" + "</Policy>")
                se = GetPolicyResponseSerializer(resp)
                return JSONResponse(se.data, aes_cipher, status=status.HTTP_200_OK)
            return Response(status=status.HTTP_200_OK)
        except Exception as e:
            logger.error(str(e))
            return Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class GetLocPlistView(APIView):
    def get(self, request, *args, **kargs):
        plist = '''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>items</key>
    <array>
        <dict>
            <key>assets</key>
            <array>
                <dict>
                    <key>kind</key>
                    <string>software-package</string>
                    <key>url</key>
                    <string>%(host)s/%(download_url)s</string>
                </dict>
            </array>
            <key>metadata</key>
            <dict>
                <key>bundle-identifier</key>
                <string>%(package)s</string>
                <key>bundle-version</key>
                <string>1.0</string>
                <key>kind</key>
                <string>software</string>
                <key>title</key>
                <string>%(appname)s</string>
            </dict>
        </dict>
    </array>
</dict>
</plist>
'''
        appname = request.query_params.get("appname", None)
        package = request.query_params.get("package", None)
        app = LocAppWrapper.objects.get(package = package)
        conf = Configuration.objects.get(group="access",name="ip")
        if settings.USE_HTTP:
            host = "http://" + conf.value
        else:
            host = "https://" + conf.value
        return HttpResponse(plist % {"host":host, "appname": appname, "package":package, "download_url":app.file.url}, content_type="application/x-plist")

class GetWaterMarkView(APIView):
    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        logger.debug('begin get watermark...')
        try:
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            _, username = parse_username(data["username"])
        except Exception as e:
            logger.debug(str(e))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

        try:
            user, username = getUserByName(username)
            policy = get_policy_by_user(user)
            watermark_text = policy.watermark_text.strip()
            if policy.watermark_enable:
                if len(watermark_text) == 0:
                    now = user.userex.login_time
                    to_zone = tz.tzlocal()
                    now = now.astimezone(to_zone)
                    watermark_text = "%s %s" % (username, datetime.datetime.strftime(now,"%Y/%m/%d %H:%M:00"))
            resp = GetWaterMarkResponse(policy.watermark_enable, watermark_text)
            respSerializer = GetWaterMarkResponseSerializer(resp)
            return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            logger.exception('%s not exist.' % username)
            return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        except Exception, e:
            logger.exception('%s get app info  got exception: %s ' % (username, str(e)))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)


class GetMdmView(APIView):
    def post(self, request, *args, **kargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        logger.debug('begin get mdm_enable...')
        try:
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            _, username = parse_username(data["username"])
        except Exception as e:
            logger.debug(str(e))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

        try:
            user, username = getUserByName(username)
            policy = get_policy_by_user(user)
            resp = GetMdmResponse(policy.mdm_enable)
            respSerializer = GetMdmResponseSerializer(resp)
            return JSONResponse(respSerializer.data, aes_cipher, status=status.HTTP_200_OK)
        except User.DoesNotExist:
            logger.exception('%s not exist.' % username)
            return generalResponseCRC(status.HTTP_401_UNAUTHORIZED, ErrorCode.AUTHENTICATION_FAIL, aes_cipher=aes_cipher)
        except Exception, e:
            logger.exception('%s get mdm_enable info  got exception: %s ' % (username, str(e)))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

class DeviceInfoView(generics.UpdateAPIView):
    serializer_class = AndroidSerializer
    queryset = Android.objects.all()

    def post(self, request, *args, **kwargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        data, aes_cipher = decrypt_data_from_client(request.data)
        if data is None:
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher)
        uuid = data.get('uuid', None)
        username = data.get('username', None)
        _, username = parse_username(username)
        is_created = False
        if uuid is None or username is None:
            logger.error('not contain uuid=%s or username=%s in device info' % (uuid, username))
            return JSONResponse({'status_code':status.HTTP_400_BAD_REQUEST, 'user_modify':False}, aes_cipher, status=status.HTTP_400_BAD_REQUEST)

        if self.queryset.filter(uuid=uuid):
            #logger.info('update device info')
            self.object = self.queryset.get(uuid=uuid)
            serializer = self.get_serializer(self.object, data=data, files=request.FILES, partial=True)
        else:
            try:
                user = User.objects.get(username=username)
                policy = get_policy_by_user(user)
                if not policy.mdm_enable:
                    return JSONResponse({'status_code': status.HTTP_200_OK, 'user_modify': False}, aes_cipher,
                                        status=status.HTTP_200_OK)
            except Exception as e:
                logger.error('check mdm error %s' % str(e))
            logger.info('create device info for user=%s uuid=%s' % (username, uuid))
            serializer = self.get_serializer(data=data, files=request.FILES)
            is_created = True
        if serializer.is_valid():
            self.object = serializer.save()
            self.object.last_seen = datetime.datetime.utcnow().replace(tzinfo=utc)
            if self.object.admin_device_name is not None:
                self.object.device_name = self.object.admin_device_name
            else:
                logger.info('save client_device_name')
                self.object.device_name = data.get('client_device_name')
            self.object.save()
        else:
            logger.error('serializer is not valid')
            return JSONResponse({'status_code':status.HTTP_500_INTERNAL_SERVER_ERROR, 'user_modify':False}, aes_cipher, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        response_body = {'status_code':status.HTTP_200_OK, 'user_modify':None}
        if username is not None:
            try:
                user_now = User.objects.get(username=username)
                if self.object.user != user_now:
                    self.object.user = user_now
                    self.object.save()
                    response_body['user_modify'] = True
            except:
                response_body['status_code'] = status.HTTP_400_BAD_REQUEST
                response_body['user_modify'] = False
        #mdm_policy apply
        if is_created:
            #check whether need to bind policy to this device
            logger.info('create new device success......')
            try:
                bind_mdm_policy_to_device(self.object)
                logger.info('apply mdm policy to this device......')
                android_policy = get_mdmpolicy_by_device(self.object)
                result = install_profile(android_policy, [self.object.uuid])
            except Exception as e:
                logger.error('apply mdm policy error for %s' % str(e))
        return JSONResponse(response_body, aes_cipher, status=response_body['status_code'])


class SandboxEncryptionView(APIView):
    def post(self, request, *args, **kwargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        try:
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            _, username = parse_username(data["username"])
            user = User.objects.get(username=username)
            userex = user.userex
            userex.sandbox_encryption_key = data["sandbox_encryption_key"]
            userex.save()
            return Response(status=status.HTTP_200_OK)
        except Exception as e:
            logger.debug(str(e))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

class PingUniaView(APIView):
    def post(self, request, *args, **kwargs):
        result, response = handle_ntlm_auth(request)
        if not result:
            return response
        try:
            data, aes_cipher = decrypt_data_from_client(request.data)
            if data is None:
                return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.TAG_INVALID, aes_cipher=aes_cipher)
            _, username = parse_username(data["username"])
            user = User.objects.get(username=username)
            ret = 0
            unia_server_manager = UniaServerManager()
            session = unia_server_manager.findActiveUniaSession(user)
            if session is not None and session.server is not None:
                ret = 1
            return JSONResponse({'status':ret}, aes_cipher, status=status.HTTP_200_OK)
        except Exception as e:
            logger.debug(str(e))
            return generalResponseCRC(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, aes_cipher=aes_cipher)

import requests
        
class FcmPushView(APIView):
    authentication_classes = ()
    permission_classes = ()
    def post(self, request, *args, **kwargs):
        try:
            device_token = request.data.get('device_token', None)
            payload = request.data.get('payload', None)
            package = request.data.get('package', None)
            title = request.data.get('title', None)
            self.acipher = AesCipher("#$vmi4trendtrend")
    
            if device_token is not None and payload is not None:
                android_auth = None
                android_proxies = None
                session = requests.Session()
                session.headers.update({"Content-Type": "application/json"})
                session.headers.update({"Authorization": "key=%s" % self.acipher.decrypt(settings.NOTIFICATION_KEY)})
                session.verify = False
                android_url = "https://fcm.googleapis.com/fcm/send"
                
                content = {
                        'data' : {
                            'title' : title,
                            'body' : payload,
                            'packageName' : package,
                            'badge' : 1,

                            },
                        'notification' : {
                            'title' : title,
                            'body' : payload,
                            'packageName' : package,
                            'content-available' : 1,
                            'sound' : 'Default',
                            'badge' : 1                            
                        }}

                content['to'] = device_token
                content['priority'] = 'high'

                response = session.post(android_url, data=json.dumps(content), auth=android_auth, proxies=android_proxies, timeout = 10)
                logger.debug("status=%d,content=%s" % (response.status_code, response.content))
                
                if response.status_code == 200:
                    return Response(status=status.HTTP_200_OK)
                else:
                    return generalJsonResponse(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE, data = {"error" : response.content})
            else:
                return generalJsonResponse(status.HTTP_400_BAD_REQUEST, ErrorCode.INVALID_INPUT)

        except Exception as e:
            logger.debug(str(e))
            return generalJsonResponse(status.HTTP_400_BAD_REQUEST, ErrorCode.FAILURE)        

class AppVersionView(APIView):
    authentication_classes = ()
    permission_classes = ()
    def get(self, request, *args, **kargs):
        try:
            device = request.query_params.get("osType", "all").lower()
            if device == "android":
                version = AppVersion.objects.get(id=1)
            elif device == "ios":
                version = AppVersion.objects.get(id=2)
            elif device == "all":
                try:
                    and_appversion = AppVersion.objects.get(device="Android")
                except AppVersion.DoesNotExist:
                    and_appversion = None
                    
                try:
                    ios_appversion = AppVersion.objects.get(device="IOS")
                except AppVersion.DoesNotExist:
                    ios_appversion = None
                
                try:
                    download = Configuration.objects.get(name="download_url")
                    download_url = download.value
                    download_url_update = download.last_modified_time
                except:
                    download_url = None
                    download_url_update = None
            
                android_version = and_appversion.version if and_appversion else None
                android_updated = and_appversion.updated if and_appversion else None

                ios_version = ios_appversion.version if ios_appversion else None
                ios_updated = ios_appversion.updated if ios_appversion else None           
                
                data = {
                    'android_version' : android_version,
                    'android_updated' : android_updated,
                    'ios_version' : ios_version,
                    'ios_updated' : ios_updated,
                    'download_url' : download_url,
                    'download_url_update' : download_url_update
                }
                return Response(data,status=status.HTTP_200_OK)
            serializer = AppVersionSerializer(version)
            
            return Response(serializer.data,status=status.HTTP_200_OK)

        except Exception as e:
            logger.debug(e) 
            return Response(status=status.HTTP_404_NOT_FOUND)    
        
import json
import sys

if __name__ == '__main__':
    payload={"username":"2222"}
    response = requests.get("http://127.0.0.1:8000/api/v1/portal/get_watermark",data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print response.content
    sys.exit()
    '''
    payload={"username":"1234","locale":"en"}
    response = requests.post("http://127.0.0.1:8000/api/v1/portal/get_app_info", data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print json.loads(response.content)
    response = requests.get("http://127.0.0.1:8000/api/v1/portal/locapp.plist?appname=123&package=1234.ipa", proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print response.content
    sys.exit()
    '''
    payload={"username":"aaa","locale":"en"}
    response = requests.post("https://10.64.91.230/api/v1/portal/get_app_info", data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print response.content
    print json.loads(response.content)
    sys.exit()
    payload={"username":"1234","password":"1111", "app_id":"com.trendmicro.mdminhouse.entsecurity","app_version":"2.0.1294"}
    response = requests.post("http://10.64.91.230:8443/api/v1/portal/loc_app_login", data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print response.content
    token = json.loads(response.content)
    sys.exit()

    payload={"action":0,"package_name":"com.trendmicro.mdminhouse.entsecurity","version":"2.0.1294", "token":token["token"]}
    response = requests.post("http://127.0.0.1:8000/api/v1/portal/wrap_action", data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print json.loads(response.content)
    sys.exit()

    payload={"action":1,"package_name":"com.tencent.xin","version":"6.0.2", "token":token["token"],"log":"this is test!"}
    response = requests.post("http://127.0.0.1:8000/api/v1/portal/wrap_action", data=json.dumps(payload), proxies=None, auth=None, timeout = 10,verify=False)
    print response
    print response.content
    #print response.content
    sys.exit()
    user = User.objects.get(username="test")
    app_info, wallpaper = get_app_wallpaper_info(user)
    resp = GetWallPaperResponse(wallpaper)
    respSerializer = GetWallPaperResponseSerializer(resp)
    print respSerializer.data

    # set_block_user()


