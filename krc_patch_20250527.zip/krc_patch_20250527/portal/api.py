from django.conf import settings
from util.general_helper import enabled_ldap, get_android_client_version, \
    get_manager_version, get_unia_version, check_fake_ldap, is_true_value, get_system_version
from util.const import VMI
from django.utils.crypto import get_random_string
from util.redis_helper import get_redis, REDIS
import urllib
from configuration.models import Configuration
class LoginRequest(object):
    def __init__(self, username, password=None, locale=None, display=None, token=None, device_token=None, opengl=0, render=0, demo_flag=None, os_info=None, device_info = None, device_udid = None, vnc_token = None, login_type=0):
        self.username = username
        self.password = password
        self.locale = locale
        self.display = display
        self.token = token
        self.device_token = device_token
        self.opengl = opengl
        self.render = render
        self.demo_flag = demo_flag
        self.os_info = os_info
        self.device_info = device_info
        self.device_udid = device_udid
        self.login_type = login_type
        self.vnc_token = vnc_token
        
class LoginResponse(object):
    def __init__(self, token, expire_date, startUniaResp = None, app_info=None, lock_pw_type=None,lock_pw_hash=None,wall_paper=None, loc_token=None, watermark_enable=None, watermark_text= None,sa_server = None, mdm_enable=None, device_mdm_status=None, sandbox_user=None, ac_expire=False, sandbox_encryption_key=None, bt_info=None, use_wallpaper=False):
        self.token = token
        self.expire_date = expire_date
        self.app_info = app_info
        self.lock_pw_type = lock_pw_type
        self.lock_pw_hash = lock_pw_hash
        self.wall_paper = wall_paper
        self.loc_token = loc_token
        if startUniaResp is None:
            self.unia = None
            self.display = None
            self.vnc_token = None
        else:
            self.unia = startUniaResp.unia
            self.display = startUniaResp.display
            self.vnc_token = startUniaResp.vnc_token
        self.watermark_enable = watermark_enable
        self.watermark_text = watermark_text
        self.sa_server = sa_server
        self.mdm_enable = mdm_enable
        self.device_mdm_status = device_mdm_status
        self.sandbox_user = sandbox_user
        self.ac_expire = ac_expire
        self.sandbox_encryption_key = sandbox_encryption_key if sandbox_encryption_key is not None else ""
        self.bt_info = bt_info
        self.use_wallpaper = use_wallpaper

class Display(object):
    MAX_FRAME_X = 4096
    MAX_FRAME_Y = 4096
    MAX_DENSITY = settings.MAX_DENSITY
    MIN_DENSITY = settings.MIN_DENSITY
    MODE_HD = 0
    MODE_FAST = 1

    def __init__(self, x, y, density, mode, maxdst=settings.MAX_DENSITY, mindst=settings.MIN_DENSITY):
        self.x = x
        self.y = y
        self.density = density
        self.mode = mode
        self.maxdst = maxdst
        self.mindst = mindst

    @classmethod
    def calcTargetDisplay(cls, display):
        maxDensity = display.maxdst
        if display.density < display.maxdst:
            maxDensity = display.density
        displayHd = Display.convertDisplay(display, maxDensity)
        displayFast = Display.convertDisplay(display, Display.MIN_DENSITY)
        if Display.MODE_HD == display.mode:
            dsp = Display(displayHd[0], displayHd[1], displayHd[2], display.mode, displayHd[2], Display.MIN_DENSITY)
        else:
            dsp = Display(displayFast[0], displayFast[1], displayFast[2], display.mode, displayHd[2], Display.MIN_DENSITY)
        print "---- Display calcuated Mode:%d ---- \n ----x:%d y:%d density:%d ---> x:%d y:%d density:%d ----" % (display.mode, display.x, display.y, display.density, dsp.x, dsp.y, dsp.density)
        return dsp


    @classmethod
    def convertDisplay(cls, display, newDensity):
        factor = newDensity/(1.0*display.density)#math.sqrt(Display.MAX_DENSITY/display.density)
        newX = display.x * factor
        newY = display.y * factor
        if newX > Display.MAX_FRAME_X or newY > Display.MAX_FRAME_Y:
            if newX < newY:
                scale = Display.MAX_FRAME_Y / (newY*1.0)
                newY = Display.MAX_FRAME_Y
                newX *= scale
            else:
                scale = Display.MAX_FRAME_X / (newX*1.0)
                newX = Display.MAX_FRAME_X
                newY *= scale
            newDensity *= scale
        if newDensity < Display.MIN_DENSITY:
            newDensity = Display.MIN_DENSITY
        newX = int(newX)
        newY = int(newY)
        if 0 != newX % 2:
            newX = newX - 1
#        if 0 != newY % 2:
#            newY = newY - 1
        return [newX, newY, newDensity]

class StartUniaRequest(object):
    def __init__(self, username, token, locale, display, opengl=0, render=0, demo_flag=None):
        self.username = username
        self.token = token
        self.locale = locale
        self.display = display
        self.opengl = opengl
        self.render = render
        self.demo_flag = demo_flag

class StartUniaResponse(object):
    def __init__(self, unia, display, vnc_token=None):
        self.unia = unia
        self.display = display
        self.vnc_token = vnc_token
        
class GetIOSNotificationResponse(object):
    def __init__(self, msg):
        self.status = int(msg['status'])
        if self.status != 0:
            self.voice = int(msg['voice'])
            self.ticker = msg['ticker']
            self.name = msg['name']
            self.packagename = msg['packagename']
        else:
            self.voice = 0
            self.ticker = None
            self.name = None
            self.packagename = None

class GetAppInfoResponse(object):
    def __init__(self, appinfo):
        self.app_info = appinfo

class GetWallPaperResponse(object):
    def __init__(self, wall_paper, use_wallpaper):
        self.wall_paper = wall_paper
        self.use_wallpaper = use_wallpaper
        
class GetIOSNotificationRequest(object):
    def __init__(self, username):
        self.username = username
        
class CheckUniaRequest(object):
    def __init__(self, username, token, demo_flag=None):
        self.username = username
        self.token = token
        self.demo_flag = demo_flag

class ChModeRequest(object):
    def __init__(self, username, token, display):
        self.username = username
        self.token = token
        self.display = display

class ChModeResponse(object):
    def __init__(self, unia, display):
        self.unia = unia
        self.display = display

class ChPwdRequest(object):
    def __init__(self, username, oldpasswd, newpasswd):
        self.username = username
        self.oldpasswd = oldpasswd
        self.newpasswd = newpasswd

class ChPwdResponse(object):
    def __init__(self, token, salt, timestamp):
        self.token = token
        self.salt = salt
        self.timestamp = timestamp
    pass

class GeneralUniaRequest(object):
    def __init__(self, username, token, demo_flag=None):
        self.username = username
        self.token = token
        self.demo_flag = demo_flag
        
class UploadDeviceTokenRequest(object):
    def __init__(self, username, token, device_token, demo_flag=None, udid=None):
        self.username = username
        self.token = token
        self.device_token = device_token
        self.demo_flag = demo_flag
        self.udid = udid

class GetCfgRequest(object):
    def __init__(self, username=None, demo_flag=None, version_flag=None):
        self.username = username
        self.demo_flag = demo_flag
        self.version_flag = version_flag
        
class AuthParameters(object):
    def __init__(self, auth_type):
        if auth_type == VMI.AUTH_OAUTH:
            params = settings.VMIM["auth_parameters"]
            
            state = get_random_string(32)
            salt = get_random_string(32)
            state_key = "%s%s" % (REDIS.OAUTH_STAT_PREFIX, state)
            redis = get_redis()
            redis.set(state_key, salt)
            redis.expire(state_key, params["timeout"])
            client = Configuration.objects.get(group="oauth",name="client_id")
            client_id = client.value
            redirect = Configuration.objects.get(group="oauth",name="redirect_uri")
            redirect_uri = redirect.value
            authorize = Configuration.objects.get(group="oauth",name="authorize_uri")
            authorize_uri = authorize.value
            d = {
                 'response_type': 'code', 
                 'scope': params["scope"], 
                 'client_id' : client_id, 
                 'redirect_uri' : redirect_uri, 
                 'state': state,
            }
            self.authorize_uri = "%s?%s" % (authorize_uri, str(urllib.urlencode(d)))
            self.state = state
            self.salt = salt
        else:
            self.authorize_uri = None
            self.state = None
            self.salt = None
    
class GetCfgResponse(object):
    def __init__(self, url, salt, timestamp, encryption, server, last_boot_time, remember_passwd, anti_screen, \
                 auth_type, customize, single_app, package, codelist, change_password,guid, password_level, \
                 sha, root_or_jailbreak, custom_auth, custom_auth_url, is_native_dpi, version_flag, \
                 ui_script, client_img, graphic_quality, device_bind, enable_csr, client_license_url,tag, wifi_block, security_keypad_key):
        self.manager_version = get_system_version()
        self.url = url
        self.salt = salt
        self.timestamp = timestamp
        self.encryption = encryption
        self.heart_beat = settings.HEART_BEAT_BETWEEN_AGENT_UNIA
        self.connection_timeout = settings.CONNECTION_TIMEOUT_BETWEEN_AGENT_UNIA
        self.min_android_client_version = get_android_client_version()
        self.current_android_client_version = get_android_client_version() if version_flag == 5 else "9.9.9999"
        self.min_ios_client_version = settings.VMIM['min_ios_client_version']
        self.server = server
        self.last_boot_time = last_boot_time
        self.remember_passwd = remember_passwd
        self.anti_screen = anti_screen
        self.current_ios_client_version = settings.VMIM['current_ios_client_version'] if version_flag == 5 else "9.9.9999"
        self.current_win_client_version = settings.VMIM['current_win_client_version']
        #self.min_ios_client_version  = settings.VMIM['current_ios_client_version']
        self.min_win_client_version =  settings.VMIM['current_win_client_version']
        self.auth_type = auth_type
        self.auth_parameters = AuthParameters(self.auth_type)
        self.enabled_ldap = enabled_ldap() if self.auth_type != VMI.AUTH_OAUTH and not check_fake_ldap() else False
        self.customize = customize
        self.single_app = single_app
        self.package=package
        self.codelist=codelist
        self.change_password= change_password
        self.server_guid = guid
        self.password_level = password_level
        self.sa_http_port = settings.SA_HTTP_PORT
        self.wrap_sha1 = sha
        self.root_or_jailbreak = root_or_jailbreak
        self.custom_auth = custom_auth 
        self.custom_auth_url = custom_auth_url
        self.is_native_dpi = is_native_dpi
        self.ui_script = ui_script
        self.client_img = client_img
        self.graphic_quality = graphic_quality
        self.device_bind = device_bind
        self.enable_csr = enable_csr
        self.license_url = client_license_url
        self.tag = tag
        self.wifi_block = wifi_block
        self.security_keypad_key = security_keypad_key
        
class LocLoginResponse(object):
    def __init__(self, token, error_code, app_info):
        self.token = token
        self.error_code = error_code
        self.app_info = app_info

class LocLoginRequest(object):
    def __init__(self, username, app_id, app_version, token= None, password = None,device_info = None,os_info=None):
        self.username = username
        self.password = password
        self.token = token
        self.app_id = app_id
        self.app_version = app_version
        self.device_info = device_info
        self.os_info = os_info 
        
class GetPolicyResponse(object):
    def __init__(self, xml):
        self.xml = xml

class GetWaterMarkResponse(object):
    def __init__(self, watermark_enable, watermark_text):
        self.watermark_enable = watermark_enable
        self.watermark_text = watermark_text
        
class GetMdmResponse(object):
    def __init__(self, mdm_enable):
        self.mdm_enable = mdm_enable

