from portal.api import LoginRequest, StartUniaRequest, Display, \
    ChPwdRequest, ChModeRequest, GeneralUniaRequest, GetCfgRequest, CheckUniaRequest, \
    GetIOSNotificationRequest, GetIOSNotificationResponse,\
    UploadDeviceTokenRequest, LocLoginRequest
from rest_framework import serializers
from configuration.models import Configuration

class SInfoSerialier(serializers.Serializer):
    className = serializers.CharField()
    parameter = serializers.CharField()
    method = serializers.CharField()
    
class GetIOSNotificationResponseSerializer(serializers.Serializer):
    status = serializers.IntegerField()
    voice = serializers.IntegerField()
    ticker = serializers.CharField()
    name = serializers.CharField()
    packagename = serializers.CharField()

    def create(self, validated_data):
        return GetIOSNotificationResponse(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     """
    #     Create or update a new LoginRequest instance.
    #     """
    #
    #     if instance is not None:
    #         instance.status = attrs['status']
    #         instance.voice = attrs['voice']
    #         instance.ticker = attrs['ticker']
    #         instance.name = attrs['name']
    #         return instance
    #     return GetIOSNotificationResponse(**attrs)

class GetIOSNotificationRequestSerializer(serializers.Serializer):
    username = serializers.CharField()

    def create(self, validated_data):
        return GetIOSNotificationRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     """
    #     Create or update a new LoginRequest instance.
    #     """
    #
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         return instance
    #     return GetIOSNotificationRequest(**attrs)


class DisplaySerialier(serializers.Serializer):
    x = serializers.FloatField()
    y = serializers.FloatField()
    density = serializers.FloatField(required=False)
    mode = serializers.IntegerField(required=False)
    maxdst = serializers.IntegerField(required=False)
    mindst = serializers.IntegerField(required=False)

    def create(self, validated_data):
        return Display(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     if instance is not None:
    #         instance.x = attrs['x']
    #         instance.y = attrs['y']
    #         instance.density = attrs['density']
    #         instance.mode = attrs['mode']
    #         return instance
    #     return Display(**attrs)

    # TODO: need further investigated for deserialization
#     def field_from_native(self, data, files, field_name, into):
#         try:
# #            if self._use_files:
# #                files = files or {}
# #                native = files[field_name]
# #            else:
#             native = data[field_name]
#         except KeyError:
#             return
#
#         value = self.restore_object(native)
#         print value
#         if self.source == '*':
#             if value:
#                 into.update(value)
#         else:
#             self.validate(value)
#             into[self.source or field_name] = value

class SinglePackageSerialier(serializers.Serializer):
    package_name = serializers.CharField()
    class_name = serializers.CharField()
    extras = serializers.CharField(required=False, allow_blank=True)
    
class GeneralUniaRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    token = serializers.CharField()
    demo_flag = serializers.IntegerField(required=False)

    def create(self, validated_data):
        return GeneralUniaRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         instance.token = attrs['token']
    #         instance.demo_flag = attrs['demo_flag']
    #         return instance
    #     return GeneralUniaRequest(**attrs)
    
class LoginRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(required=False, allow_blank=True)
    locale = serializers.CharField(required=False, allow_blank=True)
    display = DisplaySerialier(required=False)
    token = serializers.CharField(required=False, allow_blank=True)
    opengl = serializers.IntegerField(required=False)
    render = serializers.IntegerField(required=False)
    device_token = serializers.CharField(required=False, allow_blank=True)
    demo_flag = serializers.IntegerField(required=False)
    os_info = serializers.CharField(required=False, allow_blank=True)
    device_info = serializers.CharField(required=False, allow_blank=True)
    device_udid = serializers.CharField(required=False, allow_blank=True)
    login_type = serializers.IntegerField(required=False)
    vnc_token = serializers.CharField(required=False, allow_blank=True)

    def update(self, instance, validated_data):
        instance.username = validated_data.get('username', instance.username)
        instance.password = validated_data.get('password', instance.password)
        instance.locale = validated_data.get('locale', instance.locale)
        instance.display = validated_data.get('display', instance.display)
        instance.token = validated_data.get('token', instance.token)
        instance.device_token = validated_data.get('device_token', instance.device_token)
        instance.opengl = validated_data.get('opengl', instance.opengl)
        instance.render = validated_data.get('render', instance.render)
        instance.demo_flag = validated_data.get('demo_flag', instance.demo_flag)
        instance.os_info = validated_data.get('os_info', instance.os_info)
        instance.device_info = validated_data.get('device_info', instance.device_info)
        instance.device_udid = validated_data.get('device_udid', instance.device_udid)
        instance.login_type = validated_data.get('login_type', instance.login_type)
        instance.vnc_token = validated_data.get('vnc_token', instance.vnc_token)
        return instance

    def create(self, validated_data):
        return LoginRequest(**validated_data)

class AppInfoSerialier(serializers.Serializer):
    icon = serializers.CharField()
    id = serializers.IntegerField()
    name = serializers.CharField()
    package = serializers.CharField()
    type = serializers.IntegerField()
    download_url = serializers.CharField(required=False, allow_blank=True)
    open_url = serializers.CharField(required=False, allow_blank=True)
    version_code = serializers.IntegerField(required=False)
    size = serializers.IntegerField()
    version = serializers.CharField()
    sso_enable = serializers.CharField()
    
class BtInfoSerialier(serializers.Serializer):
    device_uuid = serializers.CharField()
    service_uuid = serializers.CharField()
    out_channel = serializers.CharField()
    in_channel = serializers.CharField()
    
class LoginResponseSerializer(serializers.Serializer):
    token = serializers.CharField(max_length=64)
    expire_date = serializers.DateField()
    
    unia = serializers.CharField()
    display = DisplaySerialier()
    vnc_token = serializers.CharField()
    app_info = AppInfoSerialier(many=True)
    lock_pw_type = serializers.IntegerField()
    lock_pw_hash = serializers.CharField(max_length=256)
    wall_paper = serializers.CharField()
    loc_token = serializers.CharField()
    watermark_enable = serializers.BooleanField()
    watermark_text = serializers.CharField()
    sa_server = serializers.CharField()
    mdm_enable = serializers.BooleanField()
    device_mdm_status = serializers.IntegerField()
    sandbox_user = serializers.BooleanField()
    ac_expire = serializers.BooleanField()
    sandbox_encryption_key = serializers.CharField()
    bt_info = BtInfoSerialier(many=True)
    use_wallpaper = serializers.BooleanField()
    
class StartUniaRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    token = serializers.CharField()
    locale = serializers.CharField()
    display = DisplaySerialier()
    opengl = serializers.IntegerField(required=False)
    render = serializers.IntegerField(required=False)
    demo_flag = serializers.IntegerField(required=False)

    def update(self, instance, validated_data):
        instance.username = validated_data.get('username', instance.username)
        instance.token = validated_data.get('token', instance.token)
        instance.locale = validated_data.get('locale', instance.locale)
        instance.display = validated_data.get('display', instance.display)
        instance.opengl = validated_data.get('opengl', instance.opengl)
        instance.render = validated_data.get('render', instance.render)
        instance.demo_flag = validated_data.get('demo_flag', instance.demo_flag)
        return instance

    def create(self, validated_data):
        return StartUniaRequest(**validated_data)

class StartUniaResponseSerializer(serializers.Serializer):
    unia = serializers.CharField()
    display = DisplaySerialier()
    vnc_token = serializers.CharField()
    
class CheckUniaRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    token = serializers.CharField()
    demo_flag = serializers.IntegerField(required=False)


    def update(self, instance, validated_data):
        instance.username = validated_data.get('username', instance.username)
        instance.token = validated_data.get('token', instance.token)
        instance.demo_flag = validated_data.get('demo_flag', instance.demo_flag)
        return instance

    def create(self, validated_data):
        return CheckUniaRequest(**validated_data)


class ChPwdRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    oldpasswd = serializers.CharField()
    newpasswd = serializers.CharField()

    def update(self, instance, validated_data):
        instance.username = validated_data.get('username', instance.username)
        instance.oldpasswd = validated_data.get('oldpasswd', instance.oldpasswd)
        instance.newpasswd = validated_data.get('newpasswd', instance.newpasswd)
        return instance

    def create(self, validated_data):
        return ChPwdRequest(**validated_data)

class ChPwdResponseSerializer(serializers.Serializer):
    token = serializers.CharField()
    salt = serializers.CharField()
    timestamp = serializers.DateTimeField()

class ChModeRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    token = serializers.CharField()
    display = DisplaySerialier()


    def create(self, validated_data):
        return ChModeRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         instance.token = attrs['token']
    #         instance.display = attrs['display']
    #         return instance
    #     return ChModeRequest(**attrs)

class ChModeResponseSerializer(serializers.Serializer):
    unia = serializers.CharField()
    display = DisplaySerialier()

class GetCfgRequestSerializer(serializers.Serializer):
    username = serializers.CharField(required=False, allow_blank=True)
    demo_flag = serializers.IntegerField(required=False)
    version_flag = serializers.IntegerField(required=False)
    
    def create(self, validated_data):
        return GetCfgRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         instance.demo_flag = attrs['demo_flag']
    #         return instance
    #     return GetCfgRequest(**attrs)

class AuthParametersSerializer(serializers.Serializer):
    authorize_uri = serializers.CharField(required=False, allow_blank=True)
    state = serializers.CharField(required=False, allow_blank=True)
    salt = serializers.CharField(required=False, allow_blank=True)
    
class ClientParameterSerializer(serializers.Serializer):
    banner_image = serializers.CharField()
    banner_text = serializers.CharField()
    logo_image = serializers.CharField()
    product_name = serializers.CharField()
    banner_image_sha = serializers.CharField()
    logo_image_sha = serializers.CharField()
    download_apk = serializers.CharField()
    tp_logo_img = serializers.CharField()
    tp_logo_image_sha = serializers.CharField()
        
class GetCfgResponseSerializer(serializers.Serializer):
    manager_version = serializers.CharField()
    url = serializers.CharField()
    salt = serializers.CharField()
    timestamp = serializers.DateTimeField()
    enabled_ldap = serializers.BooleanField()
    encryption = serializers.IntegerField()
    
    min_android_client_version = serializers.CharField()
    current_android_client_version = serializers.CharField()
    heart_beat = serializers.IntegerField()
    connection_timeout = serializers.IntegerField()
    
    server = serializers.CharField()
    last_boot_time = serializers.IntegerField()
    remember_passwd = serializers.BooleanField()
    anti_screen = serializers.CharField()
    auth_type = serializers.IntegerField()
    auth_parameters = AuthParametersSerializer()
    current_ios_client_version = serializers.CharField()
    current_win_client_version = serializers.CharField()    
    min_ios_client_version = serializers.CharField()
    min_win_client_version = serializers.CharField()
    customize = serializers.IntegerField()
    single_app = serializers.IntegerField()
    package=SinglePackageSerialier()
    codelist=serializers.CharField()
    change_password=serializers.BooleanField()
    server_guid=serializers.CharField()
    password_level = serializers.IntegerField()
    sa_http_port = serializers.IntegerField()
    wrap_sha1 = serializers.CharField()
    root_or_jailbreak = serializers.IntegerField()
    custom_auth = serializers.IntegerField()
    custom_auth_url = serializers.CharField()
    is_native_dpi = serializers.BooleanField()
    ui_script = SInfoSerialier(many=True)
    client_img = ClientParameterSerializer()
    graphic_quality = serializers.IntegerField()
    device_bind = serializers.BooleanField()
    enable_csr = serializers.BooleanField()
    license_url = serializers.CharField()
    tag = serializers.CharField()
    wifi_block = serializers.BooleanField()
    security_keypad_key = serializers.CharField()
    
class GetAppInfoRequestSerializer(serializers.Serializer):
    username = serializers.CharField()

class GetAppInfoResponseSerializer(serializers.Serializer):
    app_info = AppInfoSerialier(many=True)
    
class GetWallPaperResponseSerializer(serializers.Serializer):
    wall_paper = serializers.CharField()
    use_wallpaper = serializers.BooleanField()
    
class SyncPasswordRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    pw = serializers.CharField(required=False, allow_blank=True)
    lock_pw_type=serializers.IntegerField()
    lock_pw_hash = serializers.CharField()
    token = serializers.CharField(required=False, allow_blank=True)
    demo_flag = serializers.IntegerField(required=False)

class CaptureScreenRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
        
class UploadDeviceTokenRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    token = serializers.CharField()
    device_token = serializers.CharField()
    demo_flag = serializers.IntegerField(required=False)
    udid = serializers.CharField(required=False, allow_blank=True)

    def create(self, validated_data):
        return UploadDeviceTokenRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         instance.token = attrs['token']
    #         instance.device_token = attrs['device_token']
    #         instance.demo_flag = attrs['demo_flag']
    #         instance.udid = attrs['udid']
    #         return instance
    #     return UploadDeviceTokenRequest(**attrs)
    
class LocAppLoginRequestSerializer(serializers.Serializer):
    username = serializers.CharField()
    app_id = serializers.CharField(required=False, allow_blank=True)
    app_version = serializers.CharField(required=False, allow_blank=True)
    token = serializers.CharField(required=False, allow_blank=True)
    password = serializers.CharField(required=False, allow_blank=True)
    device_info = serializers.CharField(required=False, allow_blank=True)
    os_info = serializers.CharField(required=False, allow_blank=True)

    def create(self, validated_data):
        return LocLoginRequest(**validated_data)
    # def restore_object(self, attrs, instance=None):
    #     """
    #     Create or update a new LocAppLoginRequest instance.
    #     """
    #
    #     if instance is not None:
    #         instance.username = attrs['username']
    #         instance.password = attrs['password']
    #         instance.token = attrs['token']
    #         instance.app_id = attrs['app_id']
    #         instance.app_version = attrs['app_version']
    #         instance.device_info = attrs['device_info']
    #         instance.os_info = attrs['os_info']
    #         return instance
    #     return LocLoginRequest(**attrs)

class LocAppLoginResponseSerializer(serializers.Serializer):
    token = serializers.CharField(max_length=64)
    error_code = serializers.IntegerField()
    app_info = AppInfoSerialier()
    
class GetPolicyResponseSerializer(serializers.Serializer):
    xml = serializers.CharField()

class GetWaterMarkResponseSerializer(serializers.Serializer):
    watermark_enable = serializers.BooleanField()
    watermark_text = serializers.CharField()
    
class GetMdmResponseSerializer(serializers.Serializer):
    mdm_enable = serializers.BooleanField()

class AppVersionSerializer(serializers.Serializer):
    device = serializers.CharField()
    version = serializers.CharField()
    updated = serializers.DateTimeField()
    updateLink = serializers.SerializerMethodField()

    def get_updateLink(self, obj):
        try:
            download = Configuration.objects.get(name="download_url")
            download_url = download.value
        except:
            download_url = None
        return download_url
        #return "https://m.mobile.go.kr"
        #return "https://mt.mobile.go.kr"