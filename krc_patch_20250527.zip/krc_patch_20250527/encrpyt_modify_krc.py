import os
import django


if __name__ == "__main__":
    # os.environ.setdefault("DJANGO_SETTINGS_MODULE", "web_console.settings")
    os.environ['DJANGO_SETTINGS_MODULE'] = 'web_console.settings'
    django.setup()

    from util.cipher import parse_encrypt_key_from_apk
    from configuration.models import Configuration
    from configuration.serializers import ConfigurationSerializer
    
    keys = Configuration.objects.filter(group='encrypt_key')
    if keys and len(keys):
        for k in keys:
            if k.pk == 237 or k.pk == 238: # ios
                k.name = "E378B3346398053D"
                k.value = "4SwClwtzFwF8MuzIgRKtulAZTfk7u/jBebxRAmVvvxg="
            if k.pk == 239 or k.pk == 240: # android
                k.name = "F15FD96EB3070D34"
                k.value = "whTIIA5mNzaCMuvtlkygwAwKEqla6p1WUiuJWvzsrVY="

            k.save()
